﻿#pragma once

struct ClientBits
{
	int array[7];
};

struct NameEntry
{
	uint32_t index;
	char name[36];
	uint8_t pad[92];
	int32_t health;
	uint8_t pad2[70];
};

struct velocityInfo_t
{
	FVector lastPos;
	FVector delta;
};

struct LootEntry
{
	char name[100];
	char text[50];
	bool* show = NULL;
};

enum BONE_INDEX : unsigned long
{
	BONE_POS_HELMET = 8,

	BONE_POS_HEAD = 7,
	BONE_POS_NECK = 6,
	BONE_POS_CHEST = 5,
	BONE_POS_MID = 4,
	BONE_POS_TUMMY = 3,
	BONE_POS_PELVIS = 2,

	BONE_POS_RIGHT_FOOT_1 = 21,
	BONE_POS_RIGHT_FOOT_2 = 22,
	BONE_POS_RIGHT_FOOT_3 = 23,
	BONE_POS_RIGHT_FOOT_4 = 24,

	BONE_POS_LEFT_FOOT_1 = 17,
	BONE_POS_LEFT_FOOT_2 = 18,
	BONE_POS_LEFT_FOOT_3 = 19,
	BONE_POS_LEFT_FOOT_4 = 20,

	BONE_POS_LEFT_HAND_1 = 13,
	BONE_POS_LEFT_HAND_2 = 14,
	BONE_POS_LEFT_HAND_3 = 15,
	BONE_POS_LEFT_HAND_4 = 16,

	BONE_POS_RIGHT_HAND_1 = 9,
	BONE_POS_RIGHT_HAND_2 = 10,
	BONE_POS_RIGHT_HAND_3 = 11,
	BONE_POS_RIGHT_HAND_4 = 12
};

struct Scoreboard {
	int index;
	int status; //2 is dead, 0 is alive, 5 knocked
	int points;
	int networkPing;
	int deaths;
	int teamId;
	int isBot; // 1 is bot, 0 otherwise
	int kills; // <---------- tested up to here
	//int rank;
	//int prestige;
	//int rankLevel;
	//int assists; <-------- these values seemed reasonable but I didn't inspect closely, so I replace with char[0x10] temporarily incase they are incorrect.
	char unk1[0x10];

	char unk2[0xC];
	int damageDealt; //seems to increment by on the order of ~30 pts per shot connected with enemies -> damageDealt. Tested this one.
	char unk3[0x38];
};

