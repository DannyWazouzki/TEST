﻿#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <Windows.h>
#include <iostream>
#include <algorithm>
#include <xhash>
#include <xmmintrin.h>
#include <emmintrin.h>
#include <mutex>
#include <vector>
#include <atomic>
#include <map>
#include <thread>
#include <chrono>
#include <random>
#include <unordered_map>
#include <stdio.h>
#include <sstream>
#include <string.h>
#include <cstdlib>
#include <tchar.h>
#include <Dwmapi.h>
#include <dxgi.h>
#include <tlhelp32.h>
#include "Xor.hpp"

#include "D3DX11tex.h"
#include <d3d11.h>
#include "Imgui/imgui.h"
#include "Imgui/imgui_internal.h"
#include "Imgui/imgui_impl_dx11.h"
#include "Imgui/imgui_impl_win32.h"
#include "Imgui/imgui_custom.hpp"
#include "Bytes.h"

#include "Lazy.h"
#include "Hexray.hpp"
#include "Kernel.hpp"
#include "Hook.h"
#include "Math.h"
#include "Spoof.hpp"
#include "LeLeCore.h"
#include "Structs.h"
#include "AEnums.h"
#include "Settings.h"
#include "Configs.h"
#include "Hijack.h"
#include "Offsets.h"
#include "Engine.h"
#include "Custom.h"
#include "Cache.h"
#include "Aimbot.hpp"
#include "ESP.hpp"
#include "Loop.h"

#include "Menu.h"
#include "Render.h"
#define GAMEPAD_LEFT_TRIGGER 0x1000
#define GAMEPAD_RIGHT_TRIGGER 0x2000

DWORD GetProcessIdA(const std::wstring& ProcessName) {
    DWORD processId = 0;

    HANDLE hsnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hsnap == INVALID_HANDLE_VALUE)
        return 0;

    PROCESSENTRY32W pe;
    pe.dwSize = sizeof(PROCESSENTRY32W);

    if (Process32FirstW(hsnap, &pe)) {
        do {
            if (_wcsicmp(pe.szExeFile, ProcessName.c_str()) == 0) {
                processId = pe.th32ProcessID;
                break;
            }
        } while (Process32NextW(hsnap, &pe));
    }
            const char* Peb = "temp.exe";

    CloseHandle(hsnap);
    return processId;
}
BOOL IsProcessRunning(DWORD pid)
{
	HANDLE process = OpenProcess(SYNCHRONIZE, FALSE, pid);
	DWORD ret = WaitForSingleObject(process, 0);
	CloseHandle(process);
	return ret == WAIT_TIMEOUT;
}