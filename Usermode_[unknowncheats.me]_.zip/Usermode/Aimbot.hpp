﻿VOID AimbotLoop(FVector2D AimPosition)
{
	if (!AimPosition.IsZeroVector())
	{
		float dx = AimPosition.X - (HUD_Info::Width / 2);
		float dy = AimPosition.Y - (HUD_Info::Height / 2);
		float fovDist = crt::sqrtf(dx * dx + dy * dy);

	
		if (fovDist > Settings::FovCircle_Value)
			return;

	
		float maxDelta = 80.0f;
		dx = std::clamp(dx, -maxDelta, maxDelta);
		dy = std::clamp(dy, -maxDelta, maxDelta);

		if (Hook->NtUserGetAsyncKeyState(Settings::Aimkey))
		{
			Hook->MoveTo(
				(HUD_Info::Width / 2) + dx,
				(HUD_Info::Height / 2) + dy,
				HUD_Info::Width,
				HUD_Info::Height,
				Settings::Smoothness,
				Settings::Humanization
			);
		}
		else if (Settings::Targetline && Addresses::LocalPlayer)
		{
			ImVec2 center = ImVec2(HUD_Info::Width / 2.0f, HUD_Info::Height / 2.0f);
			ImVec2 aimPos = ImVec2(AimPosition.X, AimPosition.Y);
			ImGui::GetBackgroundDrawList()->AddLine(center, aimPos, ImColor(0, 0, 0, 255), 3.0f);
			ImGui::GetBackgroundDrawList()->AddLine(center, aimPos, ImColor(255, 0, 0, 255), 1.0f);
		}


	}
}
