#pragma once

std::mutex ActorMutex;
void __cdecl PlayerCache(void*) {
	std::vector<Entities_> ActorList_tmp;
	ActorList_tmp.reserve(100);

	while (true) {
		if (!Engine::Game::IsInGame()) continue;

		DecryptRefDef->ref_def_nn = Memory->Read<RefDef_T>(DecryptRefDef->GetRefDef());

		int PlayerCount = Engine::Game::PlayerCount();

		Addresses::LocalPlayer = Engine::Player::GetLocalPlayer();

		if (!Memory->IsValidPointer(Addresses::LocalPlayer))return;

		auto LocalIndex = Engine::Player::GetIndex(Addresses::LocalPlayer);
		auto LocalTeamIndex = Engine::Player::TeamIndex(Addresses::LocalPlayer);

		for (int i = 0; i < PlayerCount; ++i)
		{
			if (LocalIndex == i) continue;
			auto Player = Engine::Player::GetPlayer(i);
			if (!Player) continue;
			if (Engine::Player::TeamIndex(Player) == LocalTeamIndex) continue;
			if (!Engine::Player::IsValid(Player)) continue;

			ActorList_tmp.emplace_back(Entities_{ Player, i });
		}

		{
			std::lock_guard<std::mutex> lock(ActorMutex);
			std::swap(EntityList, ActorList_tmp);
		}

		ActorList_tmp.clear();
		//std::this_thread::sleep_for(std::chrono::milliseconds(100));
	}
}