#pragma once
#include <Windows.h>
//#include <vector>
#include <xstring>
#include <tlhelp32.h>
#include "WinUser.h"
#include <vector>


#define HJWND_PROGRAM L"winver.exe"
#define MAX_CLASSNAME 255
#define MAX_WNDNAME 255
struct WindowsFinderParams {
    DWORD pidOwner = NULL;
    std::wstring wndClassName = L"";
    std::wstring wndName = L"";
    RECT pos = { 0, 0, 0, 0 };
    POINT res = { 0, 0 };
    float percentAllScreens = 0.0f;
    float percentMainScreen = 0.0f;
    DWORD style = NULL;
    DWORD styleEx = NULL;
    bool satisfyAllCriteria = false;
    std::vector<HWND> hwnds;
};
HWND HiJackwinverWindow();
std::vector<DWORD> GetPIDs(std::wstring targetProcessName);
std::vector<HWND> WindowsFinder(WindowsFinderParams params);
BOOL CALLBACK EnumWindowsCallback(HWND hwnd, LPARAM lParam);
void Terminatewinver();
HWND HiJackwinverWindow()
{
    SPOOF;
    HWND hwndHiHjacked = NULL;
    std::vector<DWORD> existingwinvers = GetPIDs(HJWND_PROGRAM);
    if (!existingwinvers.empty()) {
        for (int i(0); i < existingwinvers.size(); ++i) {
            HANDLE hOldProcess = OpenProcess(PROCESS_TERMINATE, FALSE, existingwinvers[i]);
            TerminateProcess(hOldProcess, 0);
            CloseHandle(hOldProcess);
        }
    }
    std::vector<DWORD> winvers = GetPIDs(HJWND_PROGRAM);
    if (winvers.empty() || winvers.size() > 1)
    {
        return hwndHiHjacked;
    }
    WindowsFinderParams params;
    params.pidOwner = winvers[0];
    params.style = WS_VISIBLE;
    params.satisfyAllCriteria = true;
    std::vector<HWND> hwnds;
    int attempt = 0;
    while (hwndHiHjacked == NULL || attempt > 50000) {
        (Sleep)(100);
        hwnds = WindowsFinder(params);
        if (hwnds.size() > 1)
        {
            return hwndHiHjacked;
        }
        hwndHiHjacked = hwnds[0];
        ++attempt;
    }
    if (!hwndHiHjacked)
    {
        return hwndHiHjacked;
    }
    SetMenu(hwndHiHjacked, NULL);
    return hwndHiHjacked;
}
void Terminatewinver()
{
    SPOOF;
    std::vector<DWORD> existingwinvers = GetPIDs(HJWND_PROGRAM);
    if (!existingwinvers.empty()) {
        for (int i(0); i < existingwinvers.size(); ++i) {
            HANDLE hOldProcess = OpenProcess(PROCESS_TERMINATE, FALSE, existingwinvers[i]);
            TerminateProcess(hOldProcess, 0);
            CloseHandle(hOldProcess);
        }
    }
}
std::vector<DWORD> GetPIDs(std::wstring targetProcessName) {
    SPOOF;
    std::vector<DWORD> pids;
    if (targetProcessName == L"")
        return pids;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32W entry;
    entry.dwSize = sizeof entry;
    if (!Process32FirstW(snap, &entry)) {
        CloseHandle(snap);
        return pids;
    }
    do {
        if (std::wstring(entry.szExeFile) == targetProcessName) {
            pids.emplace_back(entry.th32ProcessID);
        }
    } while (Process32NextW(snap, &entry));
    CloseHandle(snap);
    return pids;
}
std::vector<HWND> WindowsFinder(WindowsFinderParams params) {
    SPOOF;
    EnumWindows(EnumWindowsCallback, (LPARAM)&params);
    return params.hwnds;
}
BOOL CALLBACK EnumWindowsCallback(HWND hwnd, LPARAM lParam) {
    SPOOF;
    WindowsFinderParams& params = *(WindowsFinderParams*)lParam;

    unsigned char satisfiedCriteria = 0, unSatisfiedCriteria = 0;

    // If looking for windows of a specific PID
    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (params.pidOwner != NULL)
        if (params.pidOwner == pid)
            ++satisfiedCriteria; // Doesn't belong to the process targeted
        else
            ++unSatisfiedCriteria;

    // If looking for windows of a specific class
    wchar_t className[MAX_CLASSNAME] = L"";
    GetClassNameW(hwnd, className, MAX_CLASSNAME);
    std::wstring classNameWstr = className;
    if (params.wndClassName != L"")
        if (params.wndClassName == classNameWstr)
            ++satisfiedCriteria; // Not the class targeted
        else
            ++unSatisfiedCriteria;

    // If looking for windows with a specific name
    wchar_t windowName[MAX_WNDNAME] = L"";
    GetWindowTextW(hwnd, windowName, MAX_CLASSNAME);
    std::wstring windowNameWstr = windowName;
    if (params.wndName != L"")
        if (params.wndName == windowNameWstr)
            ++satisfiedCriteria; // Not the class targeted
        else
            ++unSatisfiedCriteria;

    // If looking for window at a specific position
    RECT pos;
    GetWindowRect(hwnd, &pos);
    if (params.pos.left || params.pos.top || params.pos.right || params.pos.bottom)
        if (params.pos.left == pos.left && params.pos.top == pos.top && params.pos.right == pos.right && params.pos.bottom == pos.bottom)
            ++satisfiedCriteria;
        else
            ++unSatisfiedCriteria;

    // If looking for window of a specific size
    POINT res = { pos.right - pos.left, pos.bottom - pos.top };
    if (params.res.x || params.res.y)
        if (res.x == params.res.x && res.y == params.res.y)
            ++satisfiedCriteria;
        else
            ++unSatisfiedCriteria;

    // If looking for windows taking more than a specific percentage of all the screens
    LONG ratioAllScreensX = res.x / SpoofCall->GetSystemMetrics(SM_CXSCREEN);
    LONG ratioAllScreensY = res.y / SpoofCall->GetSystemMetrics(SM_CYSCREEN);
    float percentAllScreens = (float)ratioAllScreensX * (float)ratioAllScreensY * 100;
    if (params.percentAllScreens != 0.0f)
        if (percentAllScreens >= params.percentAllScreens)
            ++satisfiedCriteria;
        else
            ++unSatisfiedCriteria;

    // If looking for windows taking more than a specific percentage or the main screen
    RECT desktopRect;
    GetWindowRect(GetDesktopWindow(), &desktopRect);
    POINT desktopRes = { desktopRect.right - desktopRect.left, desktopRect.bottom - desktopRect.top };
    LONG ratioMainScreenX = res.x / desktopRes.x;
    LONG ratioMainScreenY = res.y / desktopRes.y;
    float percentMainScreen = (float)ratioMainScreenX * (float)ratioMainScreenY * 100;
    if (params.percentMainScreen != 0.0f)
        if (percentAllScreens >= params.percentMainScreen)
            ++satisfiedCriteria;
        else
            ++unSatisfiedCriteria;

    // Looking for windows with specific styles
    LONG_PTR style = GetWindowLongPtr(hwnd, GWL_STYLE);
    if (params.style)
        if (params.style & style)
            ++satisfiedCriteria;
        else
            ++unSatisfiedCriteria;

    // Looking for windows with specific extended styles
    LONG_PTR styleEx = GetWindowLongPtr(hwnd, GWL_EXSTYLE);
    if (params.styleEx)
        if (params.styleEx & styleEx)
            ++satisfiedCriteria;
        else
            ++unSatisfiedCriteria;

    if (satisfiedCriteria == 0)
    {
        return TRUE;

    }

    if (params.satisfyAllCriteria == 1 && unSatisfiedCriteria > 0)
    {
        return TRUE;
    }

    // If looking for multiple windows
    params.hwnds.push_back(hwnd);
    return TRUE;
}

namespace SetUp {

    HWND gWnd{}, DrawWnd{};

#define MAX_CLASSNAME 255
#define MAX_WNDNAME 255
#define TRANSPARENCY_COLOR RGB(0, 254, 0)

    struct WindowsFinderParams {
        DWORD pidOwner = NULL;
        std::string wndClassName = "";
        std::string wndName = "";
        RECT pos = { 0, 0, 0, 0 };
        POINT res = { 0, 0 };
        float percentAllScreens = 0.0f;
        float percentMainScreen = 0.0f;
        DWORD style = NULL;
        DWORD styleEx = NULL;
        bool satisfyAllCriteria = false;
        std::vector<HWND> hwnds;
    };

    // Prototypes
    inline std::vector<HWND> WindowsFinder(WindowsFinderParams params);
    inline BOOL CALLBACK EnumWindowsCallback(HWND hwnd, LPARAM lParam);
    inline HWND HiJackwinverWindow();
    inline std::vector<DWORD> GetPIDs(std::wstring targetProcessName);

    inline int amain() {
        SPOOF;
        HWND hwnd = HiJackwinverWindow();
        if (!hwnd) {

            return EXIT_FAILURE;
        }

        HDC hdc = GetDC(hwnd);

        // Getting settings of back buffer bitmap
        DEVMODE devMode;
        devMode.dmSize = sizeof(devMode);
        EnumDisplaySettings(NULL, ENUM_CURRENT_SETTINGS, &devMode);
        BITMAPINFO backBufferBmpInfo;
        backBufferBmpInfo = { 0 };
        backBufferBmpInfo.bmiHeader.biBitCount = devMode.dmBitsPerPel;
        backBufferBmpInfo.bmiHeader.biHeight = SpoofCall->GetSystemMetrics(SM_CYSCREEN);
        backBufferBmpInfo.bmiHeader.biWidth = SpoofCall->GetSystemMetrics(SM_CXSCREEN);
        backBufferBmpInfo.bmiHeader.biPlanes = 1;
        backBufferBmpInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);

        void* backBufferPixels = nullptr;
        POINT res = { SpoofCall->GetSystemMetrics(SM_CXSCREEN), SpoofCall->GetSystemMetrics(SM_CYSCREEN) };
        HBRUSH bgTransparencyColor = CreateSolidBrush(TRANSPARENCY_COLOR);

        int i = -1;

        while (true) {

            i = (i > res.x) ? 0 : ++i; // To simulate movement

            // Frame preparation
            HDC hdcBackBuffer = CreateCompatibleDC(hdc); // Create back buffer
            HBITMAP hbmBackBuffer = CreateDIBSection(hdcBackBuffer, (BITMAPINFO*)&backBufferBmpInfo, DIB_RGB_COLORS, (void**)&backBufferPixels, NULL, 0); // Create back buffer bitmap
            DeleteObject(SelectObject(hdcBackBuffer, hbmBackBuffer));
            DeleteObject(SelectObject(hdcBackBuffer, bgTransparencyColor));
            Rectangle(hdcBackBuffer, 0, 0, res.x, res.y);


            // Frame presentation
            BitBlt(hdc, 0, 0, res.x, res.y, hdcBackBuffer, 0, 0, SRCCOPY);

            // Cleanup
            DeleteDC(hdcBackBuffer); // Delete back buffer device context
            DeleteObject(hbmBackBuffer); // Delete back buffer bitmap
            backBufferPixels = nullptr;
        }

        return EXIT_SUCCESS;
    }


    inline HWND HiJackwinverWindow() {
        HWND hwnd = NULL;

        // Remove previous windows
        std::vector<DWORD> existingwinvers = GetPIDs(_(L"winver.exe"));
        if (!existingwinvers.empty()) {
            for (int i(0); i < existingwinvers.size(); ++i) {
                // Terminating processes
                HANDLE hOldProcess = OpenProcess(PROCESS_TERMINATE, FALSE, existingwinvers[i]);
                TerminateProcess(hOldProcess, 0);
                CloseHandle(hOldProcess);
            }
        }

        system(_("start winver")); // Start winver, and not as child process, so easy :)

        // Finding winver's window (we could just use FindWindow but then it would be OS language dependent)
        std::vector<DWORD> winvers = GetPIDs(_(L"winver.exe"));
        if (winvers.empty() || winvers.size() > 1) // Should check if more than one to be more strict
            return hwnd;
        WindowsFinderParams params;
        params.pidOwner = winvers[0];
        params.style = WS_VISIBLE;
        params.satisfyAllCriteria = true;
        std::vector<HWND> hwnds;
        int attempt = 0; // The process takes a bit of time to initialise and spawn the window, will try during 5 sec before time out
        while (hwnd == NULL || attempt > 50) {
            Sleep(1500);
            hwnds = WindowsFinder(params);
            if (hwnds.size() > 1)
                return hwnd;
            hwnd = hwnds[0];
            ++attempt;
        }
        if (!hwnd)
            return hwnd;

        // Making the window usable for overlay puposes

        SetMenu(hwnd, NULL);
        SpoofCall->SetWindowLongA(hwnd, GWL_STYLE, WS_VISIBLE);
        SpoofCall->SetWindowLongA(hwnd, GWL_EXSTYLE, WS_EX_LAYERED | WS_EX_TRANSPARENT); // WS_EX_NOACTIVATE  and WS_EX_TOOLWINDOW removes it from taskbar

        SpoofCall->SetWindowPos(hwnd, NULL, 0, 0, HUD_Info::Width, HUD_Info::Height, SWP_SHOWWINDOW);

        SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE);
        return hwnd;
    }

    inline std::vector<DWORD> GetPIDs(std::wstring targetProcessName) {
        SPOOF;
        std::vector<DWORD> pids;
        if (targetProcessName == L"")
            return pids;
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        PROCESSENTRY32W entry;
        entry.dwSize = sizeof entry;
        if (!Process32FirstW(snap, &entry)) {
            CloseHandle(snap);
            return pids;
        }
        do {
            if (std::wstring(entry.szExeFile) == targetProcessName) {
                pids.emplace_back(entry.th32ProcessID);
            }
        } while (Process32NextW(snap, &entry));
        CloseHandle(snap);
        return pids;
    }

    inline BOOL CALLBACK EnumWindowsCallback(HWND hwnd, LPARAM lParam) {
        SPOOF;
        WindowsFinderParams& params = *(WindowsFinderParams*)lParam;

        unsigned char satisfiedCriteria = 0, unSatisfiedCriteria = 0;

        // If looking for windows of a specific PDI
        DWORD pid = 0;
        GetWindowThreadProcessId(hwnd, &pid);
        if (params.pidOwner != NULL)
            if (params.pidOwner == pid)
                ++satisfiedCriteria; // Doesn't belong to the process targeted
            else
                ++unSatisfiedCriteria;

        // If looking for windows of a specific class
        char className[MAX_CLASSNAME] = "";
        GetClassNameA(hwnd, className, MAX_CLASSNAME);
        std::string classNameWstr = className;
        if (params.wndClassName != "")
            if (params.wndClassName == classNameWstr)
                ++satisfiedCriteria; // Not the class targeted
            else
                ++unSatisfiedCriteria;

        // If looking for windows with a specific name
        char windowName[MAX_WNDNAME] = "";
        GetClassNameA(hwnd, windowName, MAX_CLASSNAME);
        std::string windowNameWstr = windowName;
        if (params.wndName != "")
            if (params.wndName == windowNameWstr)
                ++satisfiedCriteria; // Not the class targeted
            else
                ++unSatisfiedCriteria;

        // If looking for window at a specific position
        RECT pos;
        GetWindowRect(hwnd, &pos);
        if (params.pos.left || params.pos.top || params.pos.right || params.pos.bottom)
            if (params.pos.left == pos.left && params.pos.top == pos.top && params.pos.right == pos.right && params.pos.bottom == pos.bottom)
                ++satisfiedCriteria;
            else
                ++unSatisfiedCriteria;

        // If looking for window of a specific size
        POINT res = { pos.right - pos.left, pos.bottom - pos.top };
        if (params.res.x || params.res.y)
            if (res.x == params.res.x && res.y == params.res.y)
                ++satisfiedCriteria;
            else
                ++unSatisfiedCriteria;

        // If looking for windows taking more than a specific percentage of all the screens
        float ratioAllScreensX = res.x / SpoofCall->GetSystemMetrics(SM_CXSCREEN);
        float ratioAllScreensY = res.y / SpoofCall->GetSystemMetrics(SM_CYSCREEN);
        float percentAllScreens = ratioAllScreensX * ratioAllScreensY * 100;
        if (params.percentAllScreens != 0.0f)
            if (percentAllScreens >= params.percentAllScreens)
                ++satisfiedCriteria;
            else
                ++unSatisfiedCriteria;

        // If looking for windows taking more than a specific percentage or the main screen
        RECT desktopRect;
        GetWindowRect(GetDesktopWindow(), &desktopRect);
        POINT desktopRes = { desktopRect.right - desktopRect.left, desktopRect.bottom - desktopRect.top };
        float ratioMainScreenX = res.x / desktopRes.x;
        float ratioMainScreenY = res.y / desktopRes.y;
        float percentMainScreen = ratioMainScreenX * ratioMainScreenY * 100;
        if (params.percentMainScreen != 0.0f)
            if (percentAllScreens >= params.percentMainScreen)
                ++satisfiedCriteria;
            else
                ++unSatisfiedCriteria;

        // Looking for windows with specific styles
        LONG_PTR style = SpoofCall->GetWindowLongA(hwnd, GWL_STYLE);
        if (params.style)
            if (params.style & style)
                ++satisfiedCriteria;
            else
                ++unSatisfiedCriteria;

        // Looking for windows with specific extended styles
        LONG_PTR styleEx = SpoofCall->GetWindowLongA(hwnd, GWL_EXSTYLE);
        if (params.styleEx)
            if (params.styleEx & styleEx)
                ++satisfiedCriteria;
            else
                ++unSatisfiedCriteria;

        if (!satisfiedCriteria)
            return TRUE;

        if (params.satisfyAllCriteria && unSatisfiedCriteria)
            return TRUE;

        // If looking for multiple windows
        params.hwnds.push_back(hwnd);
        return TRUE;
    }

    inline std::vector<HWND> WindowsFinder(WindowsFinderParams params) {
        SPOOF;
        EnumWindows(EnumWindowsCallback, (LPARAM)&params);
        return params.hwnds;
    }
}