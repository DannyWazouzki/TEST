﻿#pragma once

std::wstring StringToWString(const std::string& str) {
	return std::wstring(str.begin(), str.end());
}
std::string WideToNarrow(const std::wstring& wideStr) {
	return std::string(wideStr.begin(), wideStr.end());
}
static auto string_To_UTF8(const std::string& str) -> std::string
{
	int nwLen = ::MultiByteToWideChar(CP_ACP, 0, str.c_str(), -1, NULL, 0);

	wchar_t* pwBuf = new wchar_t[nwLen + 1];
	ZeroMemory(pwBuf, nwLen * 2 + 2);

	::MultiByteToWideChar(CP_ACP, 0, str.c_str(), str.length(), pwBuf, nwLen);

	int nLen = ::WideCharToMultiByte(CP_UTF8, 0, pwBuf, -1, NULL, NULL, NULL, NULL);

	char* pBuf = new char[nLen + 1];
	ZeroMemory(pBuf, nLen + 1);

	::WideCharToMultiByte(CP_UTF8, 0, pwBuf, nwLen, pBuf, nLen, NULL, NULL);

	std::string retStr(pBuf);

	delete[]pwBuf;
	delete[]pBuf;

	pwBuf = NULL;
	pBuf = NULL;

	return retStr;
}
static auto WStringToUTF8(const wchar_t* lpwcszWString) -> std::string
{
	char* pElementText;
	int iTextLen = ::WideCharToMultiByte(CP_UTF8, 0, (LPWSTR)lpwcszWString, -1, NULL, 0, NULL, NULL);
	pElementText = new char[iTextLen + 1];
	memset((void*)pElementText, 0, (iTextLen + 1) * sizeof(char));
	::WideCharToMultiByte(CP_UTF8, 0, (LPWSTR)lpwcszWString, -1, pElementText, iTextLen, NULL, NULL);
	std::string strReturn(pElementText);
	delete[] pElementText;
	return strReturn;
}
static auto MBytesToWString(const char* lpcszString) -> std::wstring
{
	int len = strlen(lpcszString);
	int unicodeLen = ::MultiByteToWideChar(CP_ACP, 0, lpcszString, -1, NULL, 0);
	wchar_t* pUnicode = new wchar_t[unicodeLen + 1];
	memset(pUnicode, 0, (unicodeLen + 1) * sizeof(wchar_t));
	::MultiByteToWideChar(CP_ACP, 0, lpcszString, -1, (LPWSTR)pUnicode, unicodeLen);
	std::wstring wString = (wchar_t*)pUnicode;
	delete[] pUnicode;
	return wString;
}

static auto DrawString(float fontSize, ImVec2 position, ImColor color, bool bCenter, bool stroke, const char* pText, ...) -> void
{
	va_list va_alist;
	char buf[1024] = { 0 };
	va_start(va_alist, pText);
	_vsnprintf_s(buf, sizeof(buf), pText, va_alist);
	va_end(va_alist);
	std::string text = WStringToUTF8(MBytesToWString(buf).c_str());
	if (bCenter)
	{
		ImVec2 textSize = ImGui::CalcTextSize(text.c_str());
		position.x = position.x - textSize.x / 2;
		position.y = position.y - textSize.y;
	}
	if (stroke)
	{
		ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(), fontSize, ImVec2(position.x + 1, position.y + 1), ImColor(0, 0, 0), text.c_str());
		ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(), fontSize, ImVec2(position.x - 1, position.y - 1), ImColor(0, 0, 0), text.c_str());
		ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(), fontSize, ImVec2(position.x + 1, position.y - 1), ImColor(0, 0, 0), text.c_str());
		ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(), fontSize, ImVec2(position.x - 1, position.y + 1), ImColor(0, 0, 0), text.c_str());
	}
	ImGui::GetBackgroundDrawList()->AddText(ImGui::GetFont(), fontSize, ImVec2(position.x, position.y), color, text.c_str());
}

namespace GaGui
{
	namespace CustomControls
	{
		struct tab_state
		{
			ImVec4 text_col, icon_col;
		};

		 ImFont* icons;
		static std::map<ImGuiID, tab_state> tab_anim;
		ImColor main_color = { 1.00f, 0.00f, 0.00f, 1.00f };

		bool Tabs(const char* label, const char* icon, const ImVec2& size_arg, bool selected, ImGuiButtonFlags flags)
		{
			ImGuiWindow* window = ImGui::GetCurrentWindow();
			if (window->SkipItems)
				return false;

			ImGuiContext& g = *GImGui;
			const ImGuiStyle& style = g.Style;
			const ImGuiID id = window->GetID(label);
			const ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);

			ImVec2 pos = window->DC.CursorPos;
			if ((flags & ImGuiButtonFlags_AlignTextBaseLine) && style.FramePadding.y < window->DC.CurrLineTextBaseOffset)
				pos.y += window->DC.CurrLineTextBaseOffset - style.FramePadding.y;
			ImVec2 size = ImGui::CalcItemSize(size_arg, label_size.x + style.FramePadding.x * 2.0f, label_size.y + style.FramePadding.y * 2.0f);

			const ImRect bb(pos, ImVec2(pos.x + size.x, pos.y + size.y));
			ImGui::ItemSize(size, style.FramePadding.y);
			if (!ImGui::ItemAdd(bb, id))
				return false;

			if (g.LastItemData.InFlags & ImGuiItemFlags_ButtonRepeat)
				flags |= ImGuiButtonFlags_Repeat;

			bool hovered, held;
			bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held, flags);

			auto it_anim = tab_anim.find(id);
			if (it_anim == tab_anim.end())
			{
				tab_anim.insert({ id, tab_state() });
				it_anim = tab_anim.find(id);
			}

			it_anim->second.text_col = ImLerp(it_anim->second.text_col, selected ? ImColor(255, 255, 255, 255) : ImColor(123, 123, 136, 255), g.IO.DeltaTime * 6.f);
			it_anim->second.icon_col = ImLerp(it_anim->second.icon_col, selected ? main_color : ImColor(123, 123, 136, 255), g.IO.DeltaTime * 6.f);

			// Render the navigation highlight.
			ImGui::RenderNavHighlight(bb, id);

			if (g.LogEnabled)
				ImGui::LogSetNextTextDecoration("[", "]");

			// Render the icon based on its value.
			ImGui::PushFont(icons);
			if (icon == std::string("A"))
				ImGui::GetWindowDrawList()->AddText(0, 20, ImVec2(bb.Min.x + 38, bb.Max.y + style.FramePadding.y - 80), ImGui::GetColorU32(it_anim->second.icon_col), icon);
			else if (icon == std::string("C"))
				ImGui::GetWindowDrawList()->AddText(0, 20, ImVec2(bb.Min.x + 38, bb.Max.y + style.FramePadding.y - 80), ImGui::GetColorU32(it_anim->second.icon_col), icon);
			else if (icon == std::string("E"))
				ImGui::GetWindowDrawList()->AddText(0, 20, ImVec2(bb.Min.x + 39, bb.Max.y + style.FramePadding.y - 80), ImGui::GetColorU32(it_anim->second.icon_col), icon);
			else
				ImGui::GetWindowDrawList()->AddText(0, 20, ImVec2(bb.Min.x + 39, bb.Max.y + style.FramePadding.y - 80), ImGui::GetColorU32(it_anim->second.icon_col), icon);


			ImGui::PopFont();
			// Compute positions manually to avoid unsupported arithmetic operators.
			ImVec2 text_clip_min(bb.Min.x + style.FramePadding.x, bb.Min.y + style.FramePadding.y);
			ImVec2 text_clip_max(bb.Max.x - style.FramePadding.x, bb.Max.y - style.FramePadding.y);

			ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetColorU32(it_anim->second.text_col));
			ImGui::RenderTextClipped(text_clip_min, text_clip_max, label, NULL, &label_size, ImVec2(0.5f, 0.75f), &bb);
			ImGui::PopStyleColor();

			IMGUI_TEST_ENGINE_ITEM_INFO(id, label, g.LastItemData.StatusFlags);
			return pressed;
		}



		struct check_state
		{
			ImVec4 background, background_gradient, text, rect_col;
			float alpha_mark;
		};

		static std::map<ImGuiID, check_state> checkbox_anim;

		bool Checkbox(const char* label, bool* v)
		{
			ImGuiWindow* window = ImGui::GetCurrentWindow();
			if (window->SkipItems)
				return false;

			ImGuiContext& g = *GImGui;
			const ImGuiStyle& style = g.Style;
			const ImGuiID id = window->GetID(label);
			const ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);

			const float square_sz = 20, y_size = 20;
			const ImVec2 pos = window->DC.CursorPos;
			const float w = ImGui::GetContentRegionMax().x - style.WindowPadding.x - 25;

			ImRect total_bb(
				ImVec2(pos.x, pos.y),
				ImVec2(pos.x + w, pos.y + y_size)
			);
			ImGui::ItemSize(total_bb, 0.f);
			if (!ImGui::ItemAdd(total_bb, id))
				return false;

			bool hovered, held;
			bool pressed = ImGui::ButtonBehavior(total_bb, id, &hovered, &held);

			// Initialize state if necessary
			auto it_anim = checkbox_anim.find(id);
			if (it_anim == checkbox_anim.end())
			{
				check_state newState;
				newState.background = *v ? main_color : ImColor(25, 25, 31, 255);
				newState.background_gradient = *v ? ImColor(66, 63, 74, 255) : ImColor(25, 25, 31, 255);
				newState.text = *v ? ImColor(255, 255, 255) : ImColor(63, 63, 80);
				newState.rect_col = *v ? ImColor(178, 209, 255, 255) : ImColor(30, 30, 39, 255);
				newState.alpha_mark = *v ? 1.f : 0.f;
				checkbox_anim.insert({ id, newState });
				it_anim = checkbox_anim.find(id);
			}

			// Animate the state (this assumes ImLerp is defined for ImVec4 and float)
			it_anim->second.background = ImLerp(it_anim->second.background, *v ? main_color : ImColor(25, 25, 31, 255), g.IO.DeltaTime * 6.f);
			it_anim->second.background_gradient = ImLerp(it_anim->second.background_gradient, *v ? ImColor(66, 63, 74, 255) : ImColor(25, 25, 31, 255), g.IO.DeltaTime * 6.f);
			it_anim->second.text = ImLerp(it_anim->second.text, *v ? ImColor(255, 255, 255) : ImColor(63, 63, 80), g.IO.DeltaTime * 6.f);
			it_anim->second.rect_col = ImLerp(it_anim->second.rect_col, *v ? ImColor(178, 209, 255, 255) : ImColor(30, 30, 39, 255), g.IO.DeltaTime * 6.f);
			it_anim->second.alpha_mark = ImLerp(it_anim->second.alpha_mark, *v ? 1.f : 0.f, g.IO.DeltaTime * 6.f);

			if (ImGui::IsItemClicked())
			{
				*v = !(*v);
				ImGui::MarkItemEdited(id);
			}

			// Calculate checkbox rectangle
			ImRect check_bb(
				ImVec2(pos.x + w - square_sz, pos.y + (y_size - square_sz) / 2),
				ImVec2(pos.x + w, pos.y + (y_size + square_sz) / 2)
			);

			// Draw the checkbox background with gradient
			// (For versions that do not support additional rounding parameters, use this call)
			ImGui::GetWindowDrawList()->AddRectFilledMultiColor(
				check_bb.Min,
				check_bb.Max,
				ImGui::GetColorU32(it_anim->second.background),
				ImGui::GetColorU32(it_anim->second.background),
				ImGui::GetColorU32(it_anim->second.background_gradient),
				ImGui::GetColorU32(it_anim->second.background_gradient)
			);

			// Optionally, test a simple colored rectangle instead:
			// ImGui::GetWindowDrawList()->AddRectFilled(check_bb.Min, check_bb.Max, IM_COL32(255, 0, 0, 255));

			// Draw the checkmark using an adjusted position
			ImVec2 checkmark_pos(
				check_bb.Min.x + square_sz / 4.0f,
				check_bb.Min.y + square_sz / 4.0f
			);
			ImVec4 textColor = ImGui::GetStyleColorVec4(ImGuiCol_Text);
			textColor.w *= it_anim->second.alpha_mark;
			ImU32 checkmarkColor = ImGui::GetColorU32(textColor);
			ImGui::RenderCheckMark(ImGui::GetWindowDrawList(), checkmark_pos, checkmarkColor, square_sz / 2);

			// Draw the label text
			ImVec2 text_pos(
				pos.x,
				pos.y + (y_size - ImGui::CalcTextSize(label).y) / 2 - 1
			);
			ImGui::GetWindowDrawList()->AddText(text_pos, ImGui::GetColorU32(it_anim->second.text), label);

			return pressed;
		}

		// Note: p_data, p_min and p_max are _pointers_ to a memory address holding the data. For a slider, they are all required.
// Read code of e.g. SliderFloat(), SliderInt() etc. or examples in 'Demo->Widgets->Data Types' to understand how to use this function directly.

		//static const char* PatchFormatStringFloatToInt(const char* fmt)
		//{
		//	if (fmt[0] == '%' && fmt[1] == '.' && fmt[2] == '0' && fmt[3] == 'f' && fmt[4] == 0) // Fast legacy path for "%.0f" which is expected to be the most common case.
		//		return "%d";
		//	const char* fmt_start = ImParseFormatFindStart(fmt);    // Find % (if any, and ignore %%)
		//	const char* fmt_end = ImParseFormatFindEnd(fmt_start);  // Find end of format specifier, which itself is an exercise of confidence/recklessness (because snprintf is dependent on libc or user).
		//	if (fmt_end > fmt_start && fmt_end[-1] == 'f')
		//	{
		//	#ifndef IMGUI_DISABLE_OBSOLETE_FUNCTIONS
		//		if (fmt_start == fmt && fmt_end[0] == 0)
		//			return "%d";
		//		ImGuiContext& g = *GImGui;
		//		ImFormatString(g.TempBuffer, IM_ARRAYSIZE(g.TempBuffer), "%.*s%%d%s", (int)(fmt_start - fmt), fmt, fmt_end); // Honor leading and trailing decorations, but lose alignment/precision.
		//		return g.TempBuffer;
		//	#else
		//		IM_ASSERT(0 && "DragInt(): Invalid format string!"); // Old versions used a default parameter of "%.0f", please replace with e.g. "%d"
		//	#endif
		//	}
		//	return fmt;
		//}


	}
	namespace Input
	{
		static bool mouseDown[5];
		static bool mouseDownAlready[256];

		static bool keysDown[256];
		static bool keysDownAlready[256];

		static bool IsAnyMouseDown()
		{
			if (mouseDown[0]) return true;
			if (mouseDown[1]) return true;
			if (mouseDown[2]) return true;
			if (mouseDown[3]) return true;
			if (mouseDown[4]) return true;

			return false;
		}

		static bool IsMouseClicked(int button, int element_id, bool repeat)
		{
			if (mouseDown[button])
			{
				if (!mouseDownAlready[element_id])
				{
					mouseDownAlready[element_id] = true;
					return true;
				}
				if (repeat)
					return true;
			}
			else
			{
				mouseDownAlready[element_id] = false;
			}
			return false;
		}
		static bool IsKeyPressed(int key, bool repeat)
		{
			if (keysDown[key])
			{
				if (!keysDownAlready[key])
				{
					keysDownAlready[key] = true;
					return true;
				}
				if (repeat)
					return true;
			}
			else
			{
				keysDownAlready[key] = false;
			}
			return false;
		}

		static void Handle()
		{
			if (Hook->NtUserGetAsyncKeyState(0x01))
				mouseDown[0] = true;
			else
				mouseDown[0] = false;
		}
	}
	namespace Colors
	{
		static ImColor Text{ 1.0f, 1.0f, 1.0f, 1.0f };
		static ImColor Text_Shadow{ 0.0f, 0.0f, 0.0f, 0.0f };
		static ImColor Text_Outline{ 0.0f, 0.0f, 0.0f, 0.30f };

		static ImColor Window_Background{ 32, 32, 32, 255 };
		static ImColor Window_Header{ 51, 51, 51, 255 };

		static ImColor Button_Idle{ 51, 51, 51, 255 };
		static ImColor Button_Hovered{ 51, 51, 51, 255 };
		static ImColor Button_Active{ 51, 51, 51, 255 };

		static ImColor Checkbox_Idle{ 51, 51, 51, 255 };
		static ImColor Checkbox_Hovered{ 51, 51, 51, 255 };
		static ImColor Checkbox_Enabled{ 255, 0, 0, 255 };

		static ImColor Combobox_Idle{ 51, 51, 51, 255 };
		static ImColor Combobox_Hovered{ 51, 51, 51, 255 };
		static ImColor Combobox_Elements{ 255, 0, 0, 255 };

		static ImColor Slider_Idle{ 51, 51, 51, 255 };
		static ImColor Slider_Hovered{ 51, 51, 51, 255 };
		static ImColor Slider_Progress{ 255, 0, 0, 255 };
		static ImColor Slider_Button{ 51, 51, 51, 255 };

		static ImColor ColorPicker_Background{ 0.006f, 0.006f, 0.006f, 1.0f };
	}

	namespace ReceiveDrawHud
	{
		struct DrawList
		{
			int type = -1; //1 = FilledRect, 2 = TextLeft, 3 = TextCenter, 4 = Draw_Line
			FVector2D pos;
			FVector2D size;
			ImColor color;
			char* name;
			bool outline;

			FVector2D from;
			FVector2D to;
			int thickness;
		};
		static DrawList drawlist[128];

		static void drawFilledRect(FVector2D pos, float w, float h, ImColor color)
		{
			for (int i = 0; i < 128; i++)
			{
				if (drawlist[i].type == -1)
				{
					drawlist[i].type = 1;
					drawlist[i].pos = pos;
					drawlist[i].size = FVector2D{ w, h };
					drawlist[i].color = color;
					return;
				}
			}
		}
		static void TextLeft(char* name, FVector2D pos, ImColor color, bool outline)
		{
			for (int i = 0; i < 128; i++)
			{
				if (drawlist[i].type == -1)
				{
					drawlist[i].type = 2;
					drawlist[i].name = name;
					drawlist[i].pos = pos;
					drawlist[i].outline = outline;
					drawlist[i].color = color;
					return;
				}
			}
		}
		static void TextCenter(char* name, FVector2D pos, ImColor color, bool outline)
		{
			for (int i = 0; i < 128; i++)
			{
				if (drawlist[i].type == -1)
				{
					drawlist[i].type = 3;
					drawlist[i].name = name;
					drawlist[i].pos = pos;
					drawlist[i].outline = outline;
					drawlist[i].color = color;
					return;
				}
			}
		}
		static void Draw_Line(FVector2D from, FVector2D to, int thickness, ImColor color)
		{
			for (int i = 0; i < 128; i++)
			{
				if (drawlist[i].type == -1)
				{
					drawlist[i].type = 4;
					drawlist[i].from = from;
					drawlist[i].to = to;
					drawlist[i].thickness = thickness;
					drawlist[i].color = color;
					return;
				}
			}
		}
	}

	static bool hover_element = false;
	static FVector2D menu_pos = FVector2D{ 0, 0 };
	static float offset_x = 0.0f;
	static float offset_y = 0.0f;

	static FVector2D first_element_pos = FVector2D{ 0, 0 };

	static FVector2D last_element_pos = FVector2D{ 0, 0 };
	static FVector2D last_element_size = FVector2D{ 0, 0 };

	static int current_element = -1;
	static FVector2D current_element_pos = FVector2D{ 0, 0 };
	static FVector2D current_element_size = FVector2D{ 0, 0 };
	static int elements_count = 0;

	static bool sameLine = false;

	static bool pushY = false;
	static float pushYvalue = 0.0f;

	static FVector2D CursorPos()
	{
		POINT cursorPos;
		SpoofCall->GetCursorPosA(&cursorPos);
		return FVector2D{ (float)cursorPos.x, (float)cursorPos.y };
	}
	static bool MouseInZone(FVector2D pos, FVector2D size)
	{
		FVector2D cursor_pos = CursorPos();

		if (cursor_pos.X > pos.X && cursor_pos.Y > pos.Y)
			if (cursor_pos.X < pos.X + size.X && cursor_pos.Y < pos.Y + size.Y)
				return true;

		return false;
	}

	void Draw_Cursor(bool toogle)
	{
		if (toogle)
		{
			FVector2D cursorPos = CursorPos();
			ImGui::GetForegroundDrawList()->AddLine(ImVec2(cursorPos.X - 11, cursorPos.Y), ImVec2(cursorPos.X + 11, cursorPos.Y), ImColor(1.f, 1.f, 1.f, 1.f), 1);
			ImGui::GetForegroundDrawList()->AddLine(ImVec2(cursorPos.X, cursorPos.Y - 11), ImVec2(cursorPos.X, cursorPos.Y + 11), ImColor(1.f, 1.f, 1.f, 1.f), 1);
			ImGui::GetForegroundDrawList()->AddLine(ImVec2(cursorPos.X - 10, cursorPos.Y), ImVec2(cursorPos.X + 10, cursorPos.Y), ImColor(1.f, 1.f, 1.f, 1.f), 1);
			ImGui::GetForegroundDrawList()->AddLine(ImVec2(cursorPos.X, cursorPos.Y - 10), ImVec2(cursorPos.X, cursorPos.Y + 10), ImColor(1.f, 1.f, 1.f, 1.f), 1);
		}
	}

	static wchar_t* s2wc(const char* c)
	{
		const size_t cSize = strlen(c) + 1;
		wchar_t* wc = new wchar_t[cSize];
		mbstowcs(wc, c, cSize);
		return wc;
	}

	static void SameLine()
	{
		sameLine = true;
	}
	static void PushNextElementY(float y, bool from_last_element = true)
	{
		pushY = true;
		if (from_last_element)
			pushYvalue = last_element_pos.Y + last_element_size.Y + y;
		else
			pushYvalue = y;
	}
	static void NextColumn(float x)
	{
		offset_x = x;
		PushNextElementY(first_element_pos.Y, false);
	}
	static void PushElementX(float value)
	{
		offset_x = value;
	}
	static void PushElementY(float value)
	{
		pushY = true;
		pushYvalue = menu_pos.Y + value - 10;
	}
	static void ClearFirstPos()
	{
		first_element_pos = FVector2D{ 0, 0 };
	}

	static void TextLeft(const char* name, FVector2D pos, ImColor color, bool outline)
	{
		ImVec2 DistanceTextSize = ImGui::CalcTextSize(name);
		//ImVec2 Pos = ImVec2(pos.X, pos.Y - DistanceTextSize.y / 2);
		//DrawString(14, Pos, color, false, true, name);
		ImGui::GetBackgroundDrawList()->AddText(ImVec2(pos.X, pos.Y - DistanceTextSize.y / 2), color, std::string(name).c_str());
	}
	static void TextCenter(const char* name, FVector2D pos, ImColor color, bool outline)
	{
		ImVec2 DistanceTextSize = ImGui::CalcTextSize(name);
		//ImVec2 Pos = ImVec2(pos.X + 1 - DistanceTextSize.x / 2, pos.Y + 1 - DistanceTextSize.y / 2);
		//DrawString(14, Pos, color, false, true, name);
		ImGui::GetBackgroundDrawList()->AddText(ImVec2(pos.X + 1 - DistanceTextSize.x / 2, pos.Y + 1 - DistanceTextSize.y / 2), color, std::string(name).c_str());
	}

	static UINT32 GetColorUINT(int r, int g, int b, int a)
	{
		UINT32 result = (BYTE(a) << 24) + (BYTE(r) << 16) + (BYTE(g) << 8) + BYTE(b);
		return result;
	}

	static void Draw_Line(FVector2D from, FVector2D to, int thickness, ImColor color)
	{
		ImGui::GetBackgroundDrawList()->AddLine(ImVec2(from.X, from.Y), ImVec2(to.X, to.Y), color, thickness);
	}
	static void drawFilledRect(FVector2D initial_pos, float w, float h, ImColor color)
	{
		for (float i = 0.0f; i < h; i += 1.0f)
			ImGui::GetBackgroundDrawList()->AddLine(ImVec2(initial_pos.X, initial_pos.Y + i), ImVec2(initial_pos.X + w, initial_pos.Y + i), color, 1.0f);
	}
	static void DrawFilledCircle(FVector2D pos, float r, ImColor color)
	{
		float smooth = 0.07f;

		double PI = 3.14159265359;
		int size = (int)(2.0f * PI / smooth) + 1;

		float angle = 0.0f;
		int i = 0;

		for (; angle < 2 * PI; angle += smooth, i++)
		{
			Draw_Line(FVector2D{ pos.X, pos.Y }, FVector2D{ pos.X + cosf(angle) * r, pos.Y + sinf(angle) * r }, 1.0f, color);
		}
	}

	static FVector2D dragPos;
	static 	bool Window(const char* name, FVector2D* pos, FVector2D size, bool isOpen)
	{
		elements_count = 0;

		if (!isOpen)
			return false;

		bool isHovered = MouseInZone(FVector2D{ pos->X, pos->Y }, size);

		//Drop last element
		if (current_element != -1 && !Hook->NtUserGetAsyncKeyState(0x1))
		{
			current_element = -1;
		}

		//Drag
		if (hover_element && Hook->NtUserGetAsyncKeyState(0x1))
		{

		}
		else if ((isHovered || dragPos.X != 0) && !hover_element)
		{
			if (Input::IsMouseClicked(0, elements_count, true))
			{
				FVector2D cursorPos = CursorPos();

				cursorPos.X -= size.X;
				cursorPos.Y -= size.Y;

				if (dragPos.X == 0)
				{
					dragPos.X = (cursorPos.X - pos->X);
					dragPos.Y = (cursorPos.Y - pos->Y);
				}
				pos->X = cursorPos.X - dragPos.X;
				pos->Y = cursorPos.Y - dragPos.Y;
			}
			else
			{
				dragPos = FVector2D{ 0, 0 };
			}
		}
		else
		{
			hover_element = false;
		}


		offset_x = 0.0f; offset_y = 0.0f;
		menu_pos = FVector2D{ pos->X, pos->Y };
		first_element_pos = FVector2D{ 0, 0 };
		current_element_pos = FVector2D{ 0, 0 };
		current_element_size = FVector2D{ 0, 0 };

		//Bg
		drawFilledRect(FVector2D{ pos->X, pos->Y }, size.X, size.Y, Colors::Window_Background);
		//drawFilledRect(FVector2D{ pos->X, pos->Y }, 122, size.Y, FLinearColor{ 0.006f, 0.006f, 0.006f, 1.0f });//My tabs bg

		//Header
		drawFilledRect(FVector2D{ pos->X, pos->Y }, size.X, 25.0f, Colors::Window_Header);

		offset_y += 25.0f;

		//Title
		FVector2D titlePos = FVector2D{ pos->X + size.X / 2, pos->Y + 25 / 2 };
		TextCenter(name, titlePos, ImColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);

		return true;
	}

	static void Text(const char* text, bool center = false, bool outline = false)
	{
		elements_count++;

		float size = 25;
		FVector2D padding = FVector2D{ 10, 10 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}

		if (!sameLine)
			offset_y += size + padding.Y;

		//Text
		FVector2D textPos = FVector2D{ pos.X + 5.0f, pos.Y + size / 2 };
		if (center)
			TextCenter(text, textPos, ImColor{ 1.0f, 1.0f, 1.0f, 1.0f }, outline);
		else
			TextLeft(text, textPos, ImColor{ 1.0f, 1.0f, 1.0f, 1.0f }, outline);

		sameLine = false;
		last_element_pos = pos;
		//last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;
	}
	static bool ButtonTab(const char* name, FVector2D size, bool active)
	{
		elements_count++;

		FVector2D padding = FVector2D{ 5, 10 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y }, size);

		//Bg
		if (active)
		{
			drawFilledRect(FVector2D{ pos.X, pos.Y }, size.X, size.Y, Colors::Button_Active);
		}
		else if (isHovered)
		{
			drawFilledRect(FVector2D{ pos.X, pos.Y }, size.X, size.Y, Colors::Button_Hovered);
			hover_element = true;
		}
		else
		{
			drawFilledRect(FVector2D{ pos.X, pos.Y }, size.X, size.Y, Colors::Button_Idle);
		}

		if (!sameLine)
			offset_y += size.Y + padding.Y;

		//Text
		FVector2D textPos = FVector2D{ pos.X + size.X / 2, pos.Y + size.Y / 2 };
		TextCenter(name, textPos, ImColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);


		sameLine = false;
		last_element_pos = pos;
		last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;

		if (isHovered && Input::IsMouseClicked(0, elements_count, false))
			return true;

		return false;
	}
	static bool Button(const char* name, FVector2D size)
	{
		elements_count++;

		FVector2D padding = FVector2D{ 5, 10 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y }, size);

		//Bg
		if (isHovered)
		{
			drawFilledRect(FVector2D{ pos.X, pos.Y }, size.X, size.Y, Colors::Button_Hovered);
			hover_element = true;
		}
		else
		{
			drawFilledRect(FVector2D{ pos.X, pos.Y }, size.X, size.Y, Colors::Button_Idle);
		}

		if (!sameLine)
			offset_y += size.Y + padding.Y;

		//Text
		FVector2D textPos = FVector2D{ pos.X + size.X / 2, pos.Y + size.Y / 2 };
		//if (!TextOverlapedFromActiveElement(textPos))
		TextCenter(name, textPos, ImColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);


		sameLine = false;
		last_element_pos = pos;
		last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;

		if (isHovered && Input::IsMouseClicked(0, elements_count, false))
			return true;

		return false;
	}

	static bool InvisibleButton(char* name, FVector2D size)
	{
		elements_count++;

		FVector2D padding = FVector2D{ 5, 10 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y }, size);

		if (!sameLine)
			offset_y += size.Y + padding.Y;

		sameLine = false;
		last_element_pos = pos;
		last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;

		if (isHovered && Input::IsMouseClicked(0, elements_count, false))
			return true;

		return false;
	}

	static void FakeElement()
	{
		FVector2D size = FVector2D(1, 1);
		elements_count++;

		FVector2D padding = FVector2D{ 1, 1 };

		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };


		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}



		if (!sameLine)
			offset_y += size.Y + padding.Y;


		sameLine = false;
		last_element_pos = pos;
		last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;

		return;
	}

	void Checkbox(char* name, bool* value)
	{
		elements_count++;

		float size = 18;
		FVector2D padding = FVector2D{ 10, 10 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y }, FVector2D{ size, size });

		//Bg
		if (isHovered)
		{
			drawFilledRect(FVector2D{ pos.X, pos.Y }, size, size, Colors::Checkbox_Hovered);
			hover_element = true;
		}
		else
		{
			drawFilledRect(FVector2D{ pos.X, pos.Y }, size, size, Colors::Checkbox_Idle);
		}

		if (!sameLine)
			offset_y += size + padding.Y;

		if (*value)
		{
			drawFilledRect(FVector2D{ pos.X + 3, pos.Y + 3 }, size - 6, size - 6, Colors::Checkbox_Enabled);
		}



		//Text
		FVector2D textPos = FVector2D{ pos.X + size + 5.0f, pos.Y + size / 2 };
		//if (!TextOverlapedFromActiveElement(textPos))
		TextLeft(name, textPos, ImColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);


		sameLine = false;
		last_element_pos = pos;
		//last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;

		if (isHovered && Input::IsMouseClicked(0, elements_count, false))
			*value = !*value;
	}


	void SliderInt(char* name, int* value, int min, int max)
	{
		elements_count++;

		FVector2D size = FVector2D{ 240, 50 };
		FVector2D slider_size = FVector2D{ 200, 10 };
		FVector2D padding = FVector2D{ 10, 15 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y }, slider_size);

		if (!sameLine)
			offset_y += size.Y + padding.Y;

		//Bg
		if (isHovered || current_element == elements_count)
		{
			//Drag
			if (Input::IsMouseClicked(0, elements_count, true))
			{
				current_element = elements_count;

				FVector2D cursorPos = CursorPos();
				*value = ((cursorPos.X - pos.X) * ((max - min) / slider_size.X)) + min;
				if (*value < min) *value = min;
				if (*value > max) *value = max;
			}

			drawFilledRect(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y }, slider_size.X, slider_size.Y, Colors::Slider_Hovered);
			drawFilledRect(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y + 5.0f }, 5.0f, 5.0f, Colors::Slider_Progress);

			hover_element = true;
		}
		else
		{
			drawFilledRect(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y }, slider_size.X, slider_size.Y, Colors::Slider_Idle);
			drawFilledRect(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y + 5.0f }, 5.0f, 5.0f, Colors::Slider_Progress);
		}


		//Value
		float oneP = slider_size.X / (max - min);
		drawFilledRect(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y }, oneP * (*value - min), slider_size.Y, Colors::Slider_Progress);
		//drawFilledRect(FVector2D{ pos.X + oneP * (*value - min) - 10.0f, pos.Y + slider_size.Y - 5.0f + padding.Y }, 20.0f, 20.0f, Colors::Slider_Button);
		DrawFilledCircle(FVector2D{ pos.X + oneP * (*value - min), pos.Y + slider_size.Y + 3.3f + padding.Y }, 10.0f, Colors::Slider_Button);
		DrawFilledCircle(FVector2D{ pos.X + oneP * (*value - min), pos.Y + slider_size.Y + 3.3f + padding.Y }, 5.0f, Colors::Slider_Progress);

		char buffer[32];
		sprintf(buffer, _("%i"), *value);
		FVector2D valuePos = FVector2D{ pos.X + oneP * (*value - min), pos.Y + slider_size.Y + 25 + padding.Y };
		TextCenter(buffer, valuePos, ImColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);

		//Text
		FVector2D textPos = FVector2D{ pos.X + 5, pos.Y + 10 };
		TextLeft(name, textPos, ImColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);


		sameLine = false;
		last_element_pos = pos;
		last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;
	}
	void SliderFloat(char* name, float* value, float min, float max, char* format = _("%.0f"))
	{
		elements_count++;

		FVector2D size = FVector2D{ 210, 40 };
		FVector2D slider_size = FVector2D{ 170, 7 };
		FVector2D adjust_zone = FVector2D{ 0, 20 };
		FVector2D padding = FVector2D{ 10, 15 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y - adjust_zone.Y }, FVector2D{ slider_size.X, slider_size.Y + adjust_zone.Y * 1.5f });

		if (!sameLine)
			offset_y += size.Y + padding.Y;

		//Bg
		if (isHovered || current_element == elements_count)
		{
			//Drag
			if (Input::IsMouseClicked(0, elements_count, true))
			{
				current_element = elements_count;

				FVector2D cursorPos = CursorPos();
				*value = ((cursorPos.X - pos.X) * ((max - min) / slider_size.X)) + min;
				if (*value < min) *value = min;
				if (*value > max) *value = max;
			}

			drawFilledRect(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y }, slider_size.X, slider_size.Y, Colors::Slider_Hovered);
			DrawFilledCircle(FVector2D{ pos.X, pos.Y + padding.Y + 9.3f }, 3.1f, Colors::Slider_Progress);
			DrawFilledCircle(FVector2D{ pos.X + slider_size.X, pos.Y + padding.Y + 9.3f }, 3.1f, Colors::Slider_Hovered);

			hover_element = true;
		}
		else
		{
			drawFilledRect(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y }, slider_size.X, slider_size.Y, Colors::Slider_Idle);
			DrawFilledCircle(FVector2D{ pos.X, pos.Y + padding.Y + 9.3f }, 3.1f, Colors::Slider_Progress);
			DrawFilledCircle(FVector2D{ pos.X + slider_size.X, pos.Y + padding.Y + 9.3f }, 3.1f, Colors::Slider_Idle);
		}


		//Text
		FVector2D textPos = FVector2D{ pos.X, pos.Y + 5 };
		TextLeft(name, textPos, Colors::Text, false);

		//Value
		float oneP = slider_size.X / (max - min);
		drawFilledRect(FVector2D{ pos.X, pos.Y + slider_size.Y + padding.Y }, oneP * (*value - min), slider_size.Y, Colors::Slider_Progress);
		DrawFilledCircle(FVector2D{ pos.X + oneP * (*value - min), pos.Y + slider_size.Y + 2.66f + padding.Y }, 8.0f, Colors::Slider_Button);
		DrawFilledCircle(FVector2D{ pos.X + oneP * (*value - min), pos.Y + slider_size.Y + 2.66f + padding.Y }, 4.0f, Colors::Slider_Progress);

		char buffer[32];
		sprintf_s(buffer, format, *value);
		FVector2D valuePos = FVector2D{ pos.X + oneP * (*value - min), pos.Y + slider_size.Y + 20 + padding.Y };
		TextCenter(buffer, valuePos, Colors::Text, false);


		sameLine = false;
		last_element_pos = pos;
		last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;
	}

	static bool checkbox_enabled[256];
	static void Combobox(const char* name, FVector2D size, int* value, const char* arg, ...)
	{
		elements_count++;

		FVector2D padding = FVector2D{ 5, 10 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}

		FVector2D textPos = FVector2D{ pos.X, pos.Y };
		TextLeft(name, textPos, ImColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);

		pos.Y += 15.0f;

		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y }, size);

		if (isHovered || checkbox_enabled[elements_count])
		{
			drawFilledRect(FVector2D{ pos.X, pos.Y }, size.X, size.Y, Colors::Combobox_Hovered);
			hover_element = true;
		}
		else
		{
			drawFilledRect(FVector2D{ pos.X, pos.Y }, size.X, size.Y, Colors::Combobox_Idle);
		}

		if (!sameLine)
			offset_y += size.Y + padding.Y + 15.0f;

		bool isHovered2 = false;
		FVector2D element_pos = pos;
		int num = 0;

		if (checkbox_enabled[elements_count])
		{
			current_element_size.X = element_pos.X - 5.0f;
			current_element_size.Y = element_pos.Y - 5.0f;
		}

		va_list arguments;
		for (va_start(arguments, arg); arg != NULL; arg = va_arg(arguments, const char*))
		{
			if (num == *value)
			{
				FVector2D _textPos = FVector2D{ pos.X + size.X / 2, pos.Y + size.Y / 2 };
				TextCenter((char*)arg, _textPos, ImColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);
			}
			if (checkbox_enabled[elements_count])
			{
				element_pos.Y += 25.0f;

				isHovered2 = MouseInZone(FVector2D{ element_pos.X, element_pos.Y }, FVector2D{ size.X, 25.0f });
				if (isHovered2)
				{
					hover_element = true;
					ReceiveDrawHud::drawFilledRect(FVector2D{ element_pos.X, element_pos.Y }, size.X, 25.0f, Colors::Combobox_Hovered);
					ReceiveDrawHud::TextLeft((char*)arg, FVector2D{ element_pos.X + 5.0f, element_pos.Y + 15.0f }, ImColor{ 1.0f, 0.0f, 0.0f, 1.0f }, false);
					if (Input::IsMouseClicked(0, elements_count, false))
					{
						*value = num;
						checkbox_enabled[elements_count] = false;
					}
				}
				else
				{
					ReceiveDrawHud::drawFilledRect(FVector2D{ element_pos.X, element_pos.Y }, size.X, 25.0f, Colors::Combobox_Idle);
				}

				ReceiveDrawHud::TextLeft((char*)arg, FVector2D{ element_pos.X + 5.0f, element_pos.Y + 15.0f }, ImColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);
			}
			num++;
		}
		va_end(arguments);
		if (checkbox_enabled[elements_count])
		{
			current_element_size.X = element_pos.X + 5.0f;
			current_element_size.Y = element_pos.Y + 5.0f;
		}

		sameLine = false;
		last_element_pos = pos;
		last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;

		if (isHovered && Input::IsMouseClicked(0, elements_count, false))
		{
			checkbox_enabled[elements_count] = !checkbox_enabled[elements_count];
		}
		if (!isHovered && !isHovered2 && Input::IsMouseClicked(0, elements_count, false))
		{
			checkbox_enabled[elements_count] = false;
		}
	}

	static int active_hotkey = -1;
	static bool already_pressed = false;
	static std::string VirtualKeyCodeToString(UCHAR virtualKey)
	{
		UINT scanCode = MapVirtualKey(virtualKey, MAPVK_VK_TO_VSC);

		if (virtualKey == VK_LBUTTON)
		{
			return _("LBUTTOM");
		}
		if (virtualKey == VK_RBUTTON)
		{
			return _("RBUTTON");
		}
		if (virtualKey == VK_MBUTTON)
		{
			return _("MBUTTON");
		}
		if (virtualKey == VK_XBUTTON1)
		{
			return _("M4");
		}
		if (virtualKey == VK_XBUTTON2)
		{
			return _("M5");
		}

		CHAR szName[128];
		int result = 0;
		switch (virtualKey)
		{
		case VK_LEFT: case VK_UP: case VK_RIGHT: case VK_DOWN:
		case VK_RCONTROL: case VK_RMENU:
		case VK_LWIN: case VK_RWIN: case VK_APPS:
		case VK_PRIOR: case VK_NEXT:
		case VK_END: case VK_HOME:
		case VK_INSERT: case VK_DELETE:
		case VK_DIVIDE:
		case VK_NUMLOCK:
			scanCode |= KF_EXTENDED;
		default:
			result = GetKeyNameTextA(scanCode << 16, szName, 128);
		}

		return szName;
	}
	static void Hotkey(const char* name, FVector2D size, int* key)
	{
		elements_count++;

		FVector2D padding = FVector2D{ 5, 10 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y + (last_element_size.Y / 2) - size.Y / 2;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y }, size);

		//Bg
		if (isHovered)
		{
			drawFilledRect(FVector2D{ pos.X, pos.Y }, size.X, size.Y, Colors::Button_Hovered);
			hover_element = true;
		}
		else
		{
			drawFilledRect(FVector2D{ pos.X, pos.Y }, size.X, size.Y, Colors::Button_Idle);
		}

		if (!sameLine)
			offset_y += size.Y + padding.Y;

		if (active_hotkey == elements_count)
		{
			//Text
			FVector2D textPos = FVector2D{ pos.X + size.X / 2, pos.Y + size.Y / 2 };
			TextCenter("[Press Key]", textPos, ImColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);

			if (!GaGui::Input::IsAnyMouseDown())
			{
				already_pressed = false;
			}

			if (!already_pressed)
			{
				for (int code = 0; code < 255; code++)
				{
					if (Hook->NtUserGetAsyncKeyState(code))
					{
						*key = code;
						active_hotkey = -1;
					}
				}
			}
		}
		else
		{
			//Text
			FVector2D textPos = FVector2D{ pos.X + size.X / 2, pos.Y + size.Y / 2 };
			TextCenter((char*)VirtualKeyCodeToString(*key).c_str(), textPos, ImColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);

			if (isHovered)
			{
				if (Input::IsMouseClicked(0, elements_count, false))
				{
					already_pressed = true;
					active_hotkey = elements_count;

					//Queue Fix
					for (int code = 0; code < 255; code++)
						if (Hook->NtUserGetAsyncKeyState(code)) {}
				}
			}
			else
			{
				if (Input::IsMouseClicked(0, elements_count, false))
				{
					active_hotkey = -1;
				}
			}
		}

		sameLine = false;
		last_element_pos = pos;
		last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;
	}

	static int active_picker = -1;
	static ImColor saved_color;
	static bool ColorPixel(FVector2D pos, FVector2D size, ImColor* original, ImColor color)
	{
		ReceiveDrawHud::drawFilledRect(FVector2D{ pos.X, pos.Y }, size.X, size.Y, color);

		//Смена цвета
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y }, size);
		if (isHovered)
		{
			if (Input::IsMouseClicked(0, elements_count, false))
				*original = color;
		}

		return true;
	}
	static void ColorPicker(const char* name, ImColor* color)
	{
		elements_count++;

		float size = 25;
		FVector2D padding = FVector2D{ 10, 10 };
		FVector2D pos = FVector2D{ menu_pos.X + padding.X + offset_x, menu_pos.Y + padding.Y + offset_y };
		if (sameLine)
		{
			pos.X = last_element_pos.X + last_element_size.X + padding.X;
			pos.Y = last_element_pos.Y;
		}
		if (pushY)
		{
			pos.Y = pushYvalue;
			pushY = false;
			pushYvalue = 0.0f;
			offset_y = pos.Y - menu_pos.Y;
		}
		bool isHovered = MouseInZone(FVector2D{ pos.X, pos.Y }, FVector2D{ size, size });

		if (!sameLine)
			offset_y += size + padding.Y;

		if (active_picker == elements_count)
		{
			hover_element = true;

			float sizePickerX = 250;
			float sizePickerY = 250;
			bool isHoveredPicker = MouseInZone(FVector2D{ pos.X, pos.Y }, FVector2D{ sizePickerX, sizePickerY - 60 });
			ReceiveDrawHud::drawFilledRect(FVector2D{ pos.X, pos.Y }, sizePickerX, sizePickerY - 65, Colors::ColorPicker_Background);

			FVector2D pixelSize = FVector2D{ sizePickerX / 12, sizePickerY / 12 };
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 0 }, pixelSize, color, ImColor{ 174 / 255.f, 235 / 255.f, 253 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 1 }, pixelSize, color, ImColor{ 136 / 255.f, 225 / 255.f, 251 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 2 }, pixelSize, color, ImColor{ 108 / 255.f, 213 / 255.f, 250 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 3 }, pixelSize, color, ImColor{ 89 / 255.f, 175 / 255.f, 213 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 4 }, pixelSize, color, ImColor{ 76 / 255.f, 151 / 255.f, 177 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 5 }, pixelSize, color, ImColor{ 60 / 255.f, 118 / 255.f, 140 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 6 }, pixelSize, color, ImColor{ 43 / 255.f, 85 / 255.f, 100 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 7 }, pixelSize, color, ImColor{ 32 / 255.f, 62 / 255.f, 74 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 0, pos.Y + pixelSize.Y * 8 }, pixelSize, color, ImColor{ 255 / 255.f, 255 / 255.f, 255 / 255.f, 1.0f });
			}
			//1
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 0 }, pixelSize, color, ImColor{ 175 / 255.f, 205 / 255.f, 252 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 1 }, pixelSize, color, ImColor{ 132 / 255.f, 179 / 255.f, 252 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 2 }, pixelSize, color, ImColor{ 90 / 255.f, 152 / 255.f, 250 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 3 }, pixelSize, color, ImColor{ 55 / 255.f, 120 / 255.f, 250 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 4 }, pixelSize, color, ImColor{ 49 / 255.f, 105 / 255.f, 209 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 5 }, pixelSize, color, ImColor{ 38 / 255.f, 83 / 255.f, 165 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 6 }, pixelSize, color, ImColor{ 28 / 255.f, 61 / 255.f, 120 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 7 }, pixelSize, color, ImColor{ 20 / 255.f, 43 / 255.f, 86 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 1, pos.Y + pixelSize.Y * 8 }, pixelSize, color, ImColor{ 247 / 255.f, 247 / 255.f, 247 / 255.f, 1.0f });
			}
			//2
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 0 }, pixelSize, color, ImColor{ 153 / 255.f, 139 / 255.f, 250 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 1 }, pixelSize, color, ImColor{ 101 / 255.f, 79 / 255.f, 249 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 2 }, pixelSize, color, ImColor{ 64 / 255.f, 50 / 255.f, 230 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 3 }, pixelSize, color, ImColor{ 54 / 255.f, 38 / 255.f, 175 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 4 }, pixelSize, color, ImColor{ 39 / 255.f, 31 / 255.f, 144 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 5 }, pixelSize, color, ImColor{ 32 / 255.f, 25 / 255.f, 116 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 6 }, pixelSize, color, ImColor{ 21 / 255.f, 18 / 255.f, 82 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 7 }, pixelSize, color, ImColor{ 16 / 255.f, 13 / 255.f, 61 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 2, pos.Y + pixelSize.Y * 8 }, pixelSize, color, ImColor{ 228 / 255.f, 228 / 255.f, 228 / 255.f, 1.0f });
			}
			//3
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 0 }, pixelSize, color, ImColor{ 194 / 255.f, 144 / 255.f, 251 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 1 }, pixelSize, color, ImColor{ 165 / 255.f, 87 / 255.f, 249 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 2 }, pixelSize, color, ImColor{ 142 / 255.f, 57 / 255.f, 239 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 3 }, pixelSize, color, ImColor{ 116 / 255.f, 45 / 255.f, 184 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 4 }, pixelSize, color, ImColor{ 92 / 255.f, 37 / 255.f, 154 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 5 }, pixelSize, color, ImColor{ 73 / 255.f, 29 / 255.f, 121 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 6 }, pixelSize, color, ImColor{ 53 / 255.f, 21 / 255.f, 88 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 7 }, pixelSize, color, ImColor{ 37 / 255.f, 15 / 255.f, 63 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 3, pos.Y + pixelSize.Y * 8 }, pixelSize, color, ImColor{ 203 / 255.f, 203 / 255.f, 203 / 255.f, 1.0f });
			}
			//4
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 0 }, pixelSize, color, ImColor{ 224 / 255.f, 162 / 255.f, 197 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 1 }, pixelSize, color, ImColor{ 210 / 255.f, 112 / 255.f, 166 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 2 }, pixelSize, color, ImColor{ 199 / 255.f, 62 / 255.f, 135 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 3 }, pixelSize, color, ImColor{ 159 / 255.f, 49 / 255.f, 105 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 4 }, pixelSize, color, ImColor{ 132 / 255.f, 41 / 255.f, 89 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 5 }, pixelSize, color, ImColor{ 104 / 255.f, 32 / 255.f, 71 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 6 }, pixelSize, color, ImColor{ 75 / 255.f, 24 / 255.f, 51 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 7 }, pixelSize, color, ImColor{ 54 / 255.f, 14 / 255.f, 36 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 4, pos.Y + pixelSize.Y * 8 }, pixelSize, color, ImColor{ 175 / 255.f, 175 / 255.f, 175 / 255.f, 1.0f });
			}
			//5
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 0 }, pixelSize, color, ImColor{ 235 / 255.f, 175 / 255.f, 176 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 1 }, pixelSize, color, ImColor{ 227 / 255.f, 133 / 255.f, 135 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 2 }, pixelSize, color, ImColor{ 219 / 255.f, 87 / 255.f, 88 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 3 }, pixelSize, color, ImColor{ 215 / 255.f, 50 / 255.f, 36 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 4 }, pixelSize, color, ImColor{ 187 / 255.f, 25 / 255.f, 7 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 5 }, pixelSize, color, ImColor{ 149 / 255.f, 20 / 255.f, 6 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 6 }, pixelSize, color, ImColor{ 107 / 255.f, 14 / 255.f, 4 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 7 }, pixelSize, color, ImColor{ 77 / 255.f, 9 / 255.f, 3 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 5, pos.Y + pixelSize.Y * 8 }, pixelSize, color, ImColor{ 144 / 255.f, 144 / 255.f, 144 / 255.f, 1.0f });
			}
			//6
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 0 }, pixelSize, color, ImColor{ 241 / 255.f, 187 / 255.f, 171 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 1 }, pixelSize, color, ImColor{ 234 / 255.f, 151 / 255.f, 126 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 2 }, pixelSize, color, ImColor{ 229 / 255.f, 115 / 255.f, 76 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 3 }, pixelSize, color, ImColor{ 227 / 255.f, 82 / 255.f, 24 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 4 }, pixelSize, color, ImColor{ 190 / 255.f, 61 / 255.f, 15 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 5 }, pixelSize, color, ImColor{ 150 / 255.f, 48 / 255.f, 12 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 6 }, pixelSize, color, ImColor{ 107 / 255.f, 34 / 255.f, 8 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 7 }, pixelSize, color, ImColor{ 79 / 255.f, 25 / 255.f, 6 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 6, pos.Y + pixelSize.Y * 8 }, pixelSize, color, ImColor{ 113 / 255.f, 113 / 255.f, 113 / 255.f, 1.0f });
			}
			//7
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 0 }, pixelSize, color, ImColor{ 245 / 255.f, 207 / 255.f, 169 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 1 }, pixelSize, color, ImColor{ 240 / 255.f, 183 / 255.f, 122 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 2 }, pixelSize, color, ImColor{ 236 / 255.f, 159 / 255.f, 74 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 3 }, pixelSize, color, ImColor{ 234 / 255.f, 146 / 255.f, 37 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 4 }, pixelSize, color, ImColor{ 193 / 255.f, 111 / 255.f, 28 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 5 }, pixelSize, color, ImColor{ 152 / 255.f, 89 / 255.f, 22 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 6 }, pixelSize, color, ImColor{ 110 / 255.f, 64 / 255.f, 16 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 7 }, pixelSize, color, ImColor{ 80 / 255.f, 47 / 255.f, 12 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 7, pos.Y + pixelSize.Y * 8 }, pixelSize, color, ImColor{ 82 / 255.f, 82 / 255.f, 82 / 255.f, 1.0f });
			}
			//8
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 0 }, pixelSize, color, ImColor{ 247 / 255.f, 218 / 255.f, 170 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 1 }, pixelSize, color, ImColor{ 244 / 255.f, 200 / 255.f, 124 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 2 }, pixelSize, color, ImColor{ 241 / 255.f, 182 / 255.f, 77 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 3 }, pixelSize, color, ImColor{ 239 / 255.f, 174 / 255.f, 44 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 4 }, pixelSize, color, ImColor{ 196 / 255.f, 137 / 255.f, 34 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 5 }, pixelSize, color, ImColor{ 154 / 255.f, 108 / 255.f, 27 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 6 }, pixelSize, color, ImColor{ 111 / 255.f, 77 / 255.f, 19 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 7 }, pixelSize, color, ImColor{ 80 / 255.f, 56 / 255.f, 14 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 8, pos.Y + pixelSize.Y * 8 }, pixelSize, color, ImColor{ 54 / 255.f, 54 / 255.f, 54 / 255.f, 1.0f });
			}
			//9
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 0 }, pixelSize, color, ImColor{ 254 / 255.f, 243 / 255.f, 187 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 1 }, pixelSize, color, ImColor{ 253 / 255.f, 237 / 255.f, 153 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 2 }, pixelSize, color, ImColor{ 253 / 255.f, 231 / 255.f, 117 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 3 }, pixelSize, color, ImColor{ 254 / 255.f, 232 / 255.f, 85 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 4 }, pixelSize, color, ImColor{ 242 / 255.f, 212 / 255.f, 53 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 5 }, pixelSize, color, ImColor{ 192 / 255.f, 169 / 255.f, 42 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 6 }, pixelSize, color, ImColor{ 138 / 255.f, 120 / 255.f, 30 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 7 }, pixelSize, color, ImColor{ 101 / 255.f, 87 / 255.f, 22 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 9, pos.Y + pixelSize.Y * 8 }, pixelSize, color, ImColor{ 29 / 255.f, 29 / 255.f, 29 / 255.f, 1.0f });
			}
			//10
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 0 }, pixelSize, color, ImColor{ 247 / 255.f, 243 / 255.f, 185 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 1 }, pixelSize, color, ImColor{ 243 / 255.f, 239 / 255.f, 148 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 2 }, pixelSize, color, ImColor{ 239 / 255.f, 232 / 255.f, 111 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 3 }, pixelSize, color, ImColor{ 235 / 255.f, 229 / 255.f, 76 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 4 }, pixelSize, color, ImColor{ 208 / 255.f, 200 / 255.f, 55 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 5 }, pixelSize, color, ImColor{ 164 / 255.f, 157 / 255.f, 43 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 6 }, pixelSize, color, ImColor{ 118 / 255.f, 114 / 255.f, 31 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 7 }, pixelSize, color, ImColor{ 86 / 255.f, 82 / 255.f, 21 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 10, pos.Y + pixelSize.Y * 8 }, pixelSize, color, ImColor{ 9 / 255.f, 9 / 255.f, 9 / 255.f, 1.0f });
			}
			//11
			{
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 0 }, pixelSize, color, ImColor{ 218 / 255.f, 232 / 255.f, 182 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 1 }, pixelSize, color, ImColor{ 198 / 255.f, 221 / 255.f, 143 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 2 }, pixelSize, color, ImColor{ 181 / 255.f, 210 / 255.f, 103 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 3 }, pixelSize, color, ImColor{ 154 / 255.f, 186 / 255.f, 76 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 4 }, pixelSize, color, ImColor{ 130 / 255.f, 155 / 255.f, 64 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 5 }, pixelSize, color, ImColor{ 102 / 255.f, 121 / 255.f, 50 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 6 }, pixelSize, color, ImColor{ 74 / 255.f, 88 / 255.f, 36 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 7 }, pixelSize, color, ImColor{ 54 / 255.f, 64 / 255.f, 26 / 255.f, 1.0f });
				ColorPixel(FVector2D{ pos.X + pixelSize.X * 11, pos.Y + pixelSize.Y * 8 }, pixelSize, color, ImColor{ 0 / 255.f, 0 / 255.f, 0 / 255.f, 1.0f });
			}


			if (isHoveredPicker)
			{
				if (Input::IsMouseClicked(0, elements_count, false))
				{

				}
			}
			else
			{
				if (Input::IsMouseClicked(0, elements_count, false))
				{
					active_picker = -1;
					//hover_element = false;
				}
			}
		}
		else
		{

			//Color
			drawFilledRect(FVector2D{ pos.X + 4, pos.Y + 4 }, size - 8, size - 8, *color);

			//Text
			FVector2D textPos = FVector2D{ pos.X + size + 5.0f, pos.Y + size / 2 };
			TextLeft(name, textPos, ImColor{ 1.0f, 1.0f, 1.0f, 1.0f }, false);

			if (isHovered && Input::IsMouseClicked(0, elements_count, false))
			{
				saved_color = *color;
				active_picker = elements_count;
			}
		}


		sameLine = false;
		last_element_pos = pos;
		//last_element_size = size;
		if (first_element_pos.X == 0.0f)
			first_element_pos = pos;
	}


	static void Render()
	{
		for (int i = 0; i < 128; i++)
		{
			if (ReceiveDrawHud::drawlist[i].type != -1)
			{
				//Filled Rect
				if (ReceiveDrawHud::drawlist[i].type == 1)
				{
					GaGui::drawFilledRect(ReceiveDrawHud::drawlist[i].pos, ReceiveDrawHud::drawlist[i].size.X, ReceiveDrawHud::drawlist[i].size.Y, ReceiveDrawHud::drawlist[i].color);
				}
				//TextLeft
				else if (ReceiveDrawHud::drawlist[i].type == 2)
				{
					GaGui::TextLeft(ReceiveDrawHud::drawlist[i].name, ReceiveDrawHud::drawlist[i].pos, ReceiveDrawHud::drawlist[i].color, ReceiveDrawHud::drawlist[i].outline);
				}
				//TextCenter
				else if (ReceiveDrawHud::drawlist[i].type == 3)
				{
					GaGui::TextCenter(ReceiveDrawHud::drawlist[i].name, ReceiveDrawHud::drawlist[i].pos, ReceiveDrawHud::drawlist[i].color, ReceiveDrawHud::drawlist[i].outline);
				}
				//Draw_Line
				else if (ReceiveDrawHud::drawlist[i].type == 4)
				{
					Draw_Line(ReceiveDrawHud::drawlist[i].from, ReceiveDrawHud::drawlist[i].to, ReceiveDrawHud::drawlist[i].thickness, ReceiveDrawHud::drawlist[i].color);
				}

				ReceiveDrawHud::drawlist[i].type = -1;
			}
		}
	}
}

void DrawArrow(float x, float y, float angle, float size, ImColor color)
{
	float arrow_half_size = size / 2.0f;
	FVector2D points[3];
	points[0] = FVector2D(x + crt::cosf(angle) * size, y + crt::sinf(angle) * size);
	points[1] = FVector2D(x + crt::cosf(angle + 1.5f) * arrow_half_size, y + crt::sinf(angle + 1.5f) * arrow_half_size);
	points[2] = FVector2D(x + crt::cosf(angle - 1.5f) * arrow_half_size, y + crt::sinf(angle - 1.5f) * arrow_half_size);
	if (points[0].Y > points[1].Y) std::swap(points[0], points[1]);
	if (points[1].Y > points[2].Y) std::swap(points[1], points[2]);
	if (points[0].Y > points[1].Y) std::swap(points[0], points[1]);
	auto interpolateX = [](const FVector2D& p1, const FVector2D& p2, float y) -> float {
		if (p1.Y == p2.Y) return p1.X;
		return p1.X + (y - p1.Y) * (p2.X - p1.X) / (p2.Y - p1.Y);
		};
	for (float y = points[0].Y; y <= points[2].Y; y += 1.0f)
	{
		float startX, endX;
		if (y < points[1].Y)
		{
			startX = interpolateX(points[0], points[1], y);
			endX = interpolateX(points[0], points[2], y);
		}
		else
		{
			startX = interpolateX(points[1], points[2], y);
			endX = interpolateX(points[0], points[2], y);
		}
		if (startX > endX) std::swap(startX, endX);
		ImGui::GetBackgroundDrawList()->AddLine(ImVec2(startX, y), ImVec2(endX, y), color, 1.0f);
	}
}

static auto DrawOutlinedText(const std::string& text, const ImVec2& pos, float size, ImColor color, bool center) -> VOID
{
	std::stringstream stream(text);
	std::string line;

	float y = 0.0f;
	int index = 0;

	while (std::getline(stream, line))
	{
		ImVec2 textSize = ImGui::CalcTextSize(line.c_str(), 0, size, 0.0f);

		if (center)
		{
			ImGui::GetBackgroundDrawList()->AddText(ImVec2((pos.x - textSize.x / 2.0f) + 1, (pos.y + textSize.y * index) + 1), ImGui::GetColorU32(ImVec4(0, 0, 0, 255)), line.c_str());
			ImGui::GetBackgroundDrawList()->AddText(ImVec2((pos.x - textSize.x / 2.0f) - 1, (pos.y + textSize.y * index) - 1), ImGui::GetColorU32(ImVec4(0, 0, 0, 255)), line.c_str());
			ImGui::GetBackgroundDrawList()->AddText(ImVec2(pos.x - textSize.x / 2.0f, pos.y + textSize.y * index), color, line.c_str());
		}
		else
		{
			ImGui::GetBackgroundDrawList()->AddText(ImVec2((pos.x) + 1, (pos.y + textSize.y * index) + 1), ImGui::GetColorU32(ImVec4(0, 0, 0, 255)), line.c_str());
			ImGui::GetBackgroundDrawList()->AddText(ImVec2((pos.x) - 1, (pos.y + textSize.y * index) - 1), ImGui::GetColorU32(ImVec4(0, 0, 0, 255)), line.c_str());
			ImGui::GetBackgroundDrawList()->AddText(ImVec2(pos.x, pos.y + textSize.y * index), color, line.c_str());
		}

		y = pos.y + textSize.y * (index + 1);
		index++;
	}
	ImGui::PopFont();
}

static void DrawFilledRect(const FVector2D& initial_pos, float w, float h, const ImColor& color)
{
	for (float i = 0.f; i < h; i += 1.f)
		ImGui::GetBackgroundDrawList()->AddLine(ImVec2(initial_pos.X, initial_pos.Y + i), ImVec2(initial_pos.X + w, initial_pos.Y + i), color, 1.0f);
}
static void DrawFilledRectWithBorder(const FVector2D& initial_pos, float w, float h, const ImColor& fillColor, const ImColor& borderColor, float borderThickness = 1.0f)
{
	for (float i = 0.f; i < h; i += 1.f)
		ImGui::GetBackgroundDrawList()->AddLine(ImVec2(initial_pos.X, initial_pos.Y + i), ImVec2(initial_pos.X + w, initial_pos.Y + i), fillColor, 1.0f);
	ImGui::GetBackgroundDrawList()->AddRect(ImVec2(initial_pos.X, initial_pos.Y), ImVec2(initial_pos.X + w, initial_pos.Y + h), borderColor, 0.0f, ImDrawFlags_None, borderThickness);
}

static bool isChangingKey = false;
static bool isTrigChangingKey = false;
static const char* keyNames[] =
{
	(""),
	("LButton"),
	("RButton"),
	("Cancel"),
	("MMouse"),
	("M4"),
	("M5"),
	(""),
	("Backspace"),
	("Tab"),
	(""),
	(""),
	("Clear"),
	("Enter"),
	(""),
	(""),
	("Shift"),
	("Control"),
	("Alt"),
	("Pause"),
	("Caps"),
	(""),
	(""),
	(""),
	(""),
	(""),
	(""),
	("Escape"),
	(""),
	(""),
	(""),
	(""),
	("Space"),
	("Page Up"),
	("Page Down"),
	("End"),
	("Home"),
	("Left"),
	("Up"),
	("Right"),
	("Down"),
	(""),
	(""),
	(""),
	("Print"),
	("Insert"),
	("Delete"),
	(""),
	("0"),
	("1"),
	("2"),
	("3"),
	("4"),
	("5"),
	("6"),
	("7"),
	("8"),
	("9"),
	(""),
	(""),
	(""),
	(""),
	(""),
	(""),
	(""),
	("A"),
	("B"),
	("C"),
	("D"),
	("E"),
	("F"),
	("G"),
	("H"),
	("I"),
	("J"),
	("K"),
	("L"),
	("M"),
	("N"),
	("O"),
	("P"),
	("Q"),
	("R"),
	("S"),
	("T"),
	("U"),
	("V"),
	("W"),
	("X"),
	("Y"),
	("Z"),
	(""),
	(""),
	(""),
	(""),
	(""),
	("Numpad 0"),
	("Numpad 1"),
	("Numpad 2"),
	("Numpad 3"),
	("Numpad 4"),
	("Numpad 5"),
	("Numpad 6"),
	("Numpad 7"),
	("Numpad 8"),
	("Numpad 9"),
	("Multiply"),
	("Add"),
	(""),
	("Subtract"),
	("Decimal"),
	("Divide"),
	("F1"),
	("F2"),
	("F3"),
	("F4"),
	("F5"),
	("F6"),
	("F7"),
	("F8"),
	("F9"),
	("F10"),
	("F11"),
	("F12")
};

static bool Items_ArrayGetter(void* data, int idx, const char** out_text)
{
	const char* const* items = (const char* const*)data;
	if (out_text)
	{
		*out_text = items[idx];
	}
	return true;
}

class UControl
{
public:

	FVector2D Origin;
	FVector2D Size;
	bool* BoundBool = nullptr;
	bool bIsMenuTabControl;
	bool bIsRangeSlider;
	int RangeValueMin;
	int RangeValueMax;
	int* pBoundRangeValue;
	int BoundMenuTabIndex;

	bool ContainsPoint(FVector2D pt)
	{
		auto extent = Origin + Size;
		return (pt.X > Origin.X && pt.Y > Origin.Y && pt.X < extent.X && pt.Y < extent.Y);
	}
};

static std::vector<UControl>* g_ControlBoundsList;
static bool isInteracting = false;

namespace Color
{
	static ImColor Header = ImColor(0, 0, 0, 255);
	static ImColor HeaderText = ImColor(255, 255, 255, 255);

	static ImColor TabsActive = ImColor(179, 179, 179, 255);
	static ImColor TabsIdle = ImColor(212, 212, 212, 255);
	static ImColor TabsText = ImColor(0, 0, 0, 255);

	static ImColor WindowColor = ImColor(255, 255, 255, 255);
	static ImColor MenuText = ImColor(0, 0, 0, 255);

	static ImColor CheckboxBG = ImColor(199, 199, 199, 255);
	static ImColor Checkbox = ImColor(0, 0, 0, 255);
	static ImColor CheckboxText = ImColor(0, 0, 0, 255);

	static ImColor SliderRect = ImColor(0, 0, 0, 255);
	static ImColor SliderLine = ImColor(181, 181, 181, 255);
	static ImColor SliderText = ImColor(0, 0, 0, 255);
}

static void RegisterButtonControl(const FVector2D initial_pos, float w, float h, const ImColor color, int tabIndex = -1, bool* boundBool = nullptr)
{
	DrawFilledRectWithBorder(initial_pos, w, h, color, ImColor(51, 51, 51));
	UControl bounds;
	bounds.Origin = initial_pos;
	bounds.Size = { w, h };
	if (tabIndex != -1)
	{
		bounds.bIsMenuTabControl = true;
		bounds.BoundMenuTabIndex = tabIndex;
	}
	else
	{
		bounds.BoundBool = boundBool;
		bounds.bIsMenuTabControl = false;
	}
	g_ControlBoundsList->push_back(bounds);
}
static void Render_MenuText(const char* text, ImColor col, FVector2D loc, bool centered)
{
	DrawString(14, ImVec2(loc.X, loc.Y), col, false, false, text);
}
static void Render_Toggle(FVector2D& loc_ref, const char* name, bool* on)
{
	auto loc = &loc_ref;
	float rectWidth = 15.0f;
	float rectHeight = 15.0f;
	float rectOffset = 5.0f;
	bool hover = GaGui::CursorPos().X > loc->X + rectOffset &&
		GaGui::CursorPos().Y > loc->Y + rectOffset &&
		GaGui::CursorPos().X < loc->X + rectOffset + rectWidth &&
		GaGui::CursorPos().Y < loc->Y + rectOffset + rectHeight;
	if (hover && GaGui::Input::IsMouseClicked(0, GaGui::elements_count, false)) {
		*on = !*on;
		isInteracting = true;
	}
	DrawFilledRect(FVector2D(loc->X + rectOffset, loc->Y + rectOffset), rectWidth, rectHeight, Color::CheckboxBG);
	if (*on) {
		float innerOffset = rectOffset + 3.0f;
		float innerSize = rectWidth - 6.0f;
		DrawFilledRect(FVector2D(loc->X + innerOffset, loc->Y + innerOffset), innerSize, innerSize, ImColor(0, 0, 0, 255));
	}
	Render_MenuText(name, Color::CheckboxText, FVector2D(loc->X + 30, loc->Y + rectOffset), false);
	loc->Y += 20.0f;
}
static void Render_Slider(const char* name, float minimum, float maximum, float* val, FVector2D* loc)
{
	constexpr float _width = 135;
	bool hover = GaGui::CursorPos().X > loc->X && GaGui::CursorPos().X < (loc->X + _width) &&
		GaGui::CursorPos().Y > loc->Y && GaGui::CursorPos().Y < (loc->Y + 30);
	if (hover && Hook->NtUserGetAsyncKeyState(Keys::LeftMouseButton)) {
		float ratio = (GaGui::CursorPos().X - loc->X) / _width;
		ratio = std::clamp(ratio, 0.0f, 1.0f);
		*val = minimum + ((maximum - minimum) * ratio);
		*val = roundf(*val * 100.0f) / 100.0f;
	}
	int xpos = static_cast<int>(((*val - minimum) / (maximum - minimum)) * _width);
	loc->Y += 24.f;
	DrawFilledRect(*loc, _width, 3, Color::SliderRect);
	DrawFilledRect(FVector2D(loc->X, loc->Y), _width, 3, Color::SliderLine);
	DrawFilledRect(FVector2D(loc->X + xpos, loc->Y - 5), 5, 12, Color::SliderRect);
	loc->Y -= 24.f;
	char valueStr[16] = {};
	snprintf(valueStr, sizeof(valueStr), _("%.1f"), *val);
	Render_MenuText(valueStr, Color::SliderText, FVector2D(loc->X + xpos, loc->Y + 35), false);
	Render_MenuText(name, Color::SliderText, FVector2D(loc->X + 6, loc->Y), false);
	loc->Y += 30.0f;
	loc->Y += 13.0f;
}
void Render_HotkeyButton(FVector2D& loc, const char* label, int* aimkey, bool* isChangingKey)
{
	static int lastKey = 0;
	Render_MenuText(label, Color::MenuText, FVector2D(loc.X, loc.Y), false);
	loc.Y += 15;
	std::string buttonLabel = *isChangingKey ? _("[ X ]") : keyNames[*aimkey];
	bool hover = GaGui::CursorPos().X > loc.X && GaGui::CursorPos().X < (loc.X + 100) &&
		GaGui::CursorPos().Y > loc.Y && GaGui::CursorPos().Y < (loc.Y + 20);
	if (hover && GaGui::Input::IsMouseClicked(0, GaGui::elements_count, false))
	{
		*isChangingKey = true;
		lastKey = Keys::LeftMouseButton;
	}
	DrawFilledRectWithBorder(loc, 100, 20, Color::TabsIdle, ImColor(51, 51, 51));
	Render_MenuText(buttonLabel.c_str(), Color::MenuText, FVector2D(loc.X + 30, loc.Y + 5), false);
	if (*isChangingKey)
	{
		for (int i = 1; i < 0x87; i++)
		{
			if ((Hook->NtUserGetAsyncKeyState(i) & 0x8000) && i != lastKey)
			{
				*aimkey = i;
				*isChangingKey = false;
				break;
			}
		}
	}

	loc.Y += 20;
}

void DrawTriangle(const FVector2D& point1, const FVector2D& point2, const FVector2D& point3, const ImColor& color, bool isFilled)
{
	ImGui::GetBackgroundDrawList()->AddLine(ImVec2(point1.X, point1.Y), ImVec2(point2.X, point2.Y), color, 1.0f);
	ImGui::GetBackgroundDrawList()->AddLine(ImVec2(point1.X, point1.Y), ImVec2(point3.X, point3.Y), color, 1.0f);
	ImGui::GetBackgroundDrawList()->AddLine(ImVec2(point2.X, point2.Y), ImVec2(point3.X, point3.Y), color, 1.0f);
	if (isFilled) {
		float addX = 0.5f;
		float addY = 1;
		for (int i = point1.Y; i < point3.Y; i++) {
			ImGui::GetBackgroundDrawList()->AddLine(ImVec2(point1.X + addX, point1.Y + addY), ImVec2(point2.X - addX, point2.Y + addY), color, 1.0f);
			addY++;
			addX += 0.5f;
		}
	}
}
auto RectFilled(float x0, float y0, float x1, float y1, ImColor color, float rounding, int rounding_corners_flags) -> VOID
{
	auto vList = ImGui::GetBackgroundDrawList();
	vList->AddRectFilled(ImVec2(x0, y0), ImVec2(x1, y1), color, rounding, rounding_corners_flags);
}
auto HealthBar(float x, float y, float w, float h, int phealth, bool Outlined) -> VOID
{
	if (phealth != 0)
	{
		auto vList = ImGui::GetBackgroundDrawList();
		int healthValue = max(0, min(phealth, 100));
		ImColor barColor = ImColor(min(510 * (100 - healthValue) / 100, 255), min(510 * healthValue / 100, 255), 25, 255);
		if (Outlined)
			vList->AddRect(ImVec2(x - 1, y - 1), ImVec2(x + w + 1, y + h + 1), ImColor(145, 145, 145, 255), 0.0f, 0, 1.0f);

		float filledHeight = ((float)h / 100.0f) * (float)healthValue;
		RectFilled(x, y, x + w, y + (int)(((float)h / 100.0f) * (float)phealth), barColor, 0.0f, 0);

		char healthText[16];
		sprintf_s(healthText, _("%d"), healthValue);
		ImVec2 textSize = ImGui::CalcTextSize(healthText);
		float textX = x + (w / 2) - (textSize.x / 2);
		float textY = y + filledHeight - (textSize.y / 2);
		if (textY < y)
			textY = y;
		if (phealth < 100)
			DrawString(10, ImVec2(textX, textY), ImColor(255, 255, 255, 255), false, true, healthText);
	}
}
auto ShieldBar(float x, float y, float w, float h, int phealth, int ShieldType, bool Outlined) -> VOID
{
	if (phealth != 0)
	{
		auto vList = ImGui::GetBackgroundDrawList();
		int healthValue = max(0, min(phealth, 100));
		ImColor barColor = ImColor(247, 247, 247, 255);
		switch (ShieldType) {
		case 1:
			barColor = ImColor(247, 247, 247);
			break;
		case 2:
			barColor = ImColor(39, 178, 255);
			break;
		case 3:
			barColor = ImColor(206, 59, 255);
			break;
		case 4:
			barColor = ImColor(255, 255, 79);
			break;
		case 5:
			barColor = ImColor(219, 2, 2);
			break;
		default:
			barColor = ImColor(247, 247, 247);
		}
		if (Outlined)
			vList->AddRect(ImVec2(x - 1, y - 1), ImVec2(x + w + 1, y + h + 1), ImColor(145, 145, 145, 255), 0.0f, 0, 1.0f);

		float filledHeight = ((float)h / 100.0f) * (float)healthValue;
		RectFilled(x, y, x + w, y + (int)(((float)h / 100.0f) * (float)phealth), barColor, 0.0f, 0);

		char healthText[16];
		sprintf_s(healthText, _("%d"), healthValue);
		ImVec2 textSize = ImGui::CalcTextSize(healthText);
		float textX = x + (w / 2) - (textSize.x / 2);
		float textY = y + filledHeight - (textSize.y / 2);
		if (textY < y)
			textY = y;
		if (phealth < 100)
			DrawString(10, ImVec2(textX, textY), ImColor(255, 255, 255, 255), false, true, healthText);
	}
}

void SpectatorList(std::string Name, float Offset)
{
	DrawString(13, ImVec2(15, Offset), ImColor(255, 255, 255, 255), false, true, Name.c_str());
	Offset += 15;
}
