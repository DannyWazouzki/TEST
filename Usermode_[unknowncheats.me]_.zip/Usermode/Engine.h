﻿#pragma once
namespace API
{
    auto IsInScreen(FVector2D Screen) -> bool {
        if (Screen.X > 0 && Screen.X < DecryptRefDef->ref_def_nn.width && Screen.Y > 0 && Screen.Y < DecryptRefDef->ref_def_nn.height) return true;
        else return false;
    }

}
namespace Engine {
    std::map<DWORD, velocityInfo_t> Velocity;
    namespace Player {
        CodPTR GetPlayer(int i)
        {
            uint64_t DecryptedPointer = decrypt_client_info();
            if (Memory->IsValidPointer(DecryptedPointer))
            {
                uint64_t ClientInfo = decrypt_client_base(DecryptedPointer);
                if (Memory->IsValidPointer(ClientInfo))
                {
                    return ClientInfo + (i * Offsets::Player::size);
                }
            }

            return NULL;
        }
        CodPTR GetLocalPlayer()
        {
            uint64_t DecryptedPointer = decrypt_client_info();
            if (Memory->IsValidPointer(DecryptedPointer))
            {
                CodPTR LocalIndex = Memory->Read<CodPTR>(DecryptedPointer + Offsets::local_index);
                if (Memory->IsValidPointer(LocalIndex))
                {
                    auto Index = Memory->Read<int>(LocalIndex + Offsets::local_index_pos);
                    return GetPlayer(Index);
                }
            }

            return NULL;
        }
        FVector2D CameraAngles()
        {
            auto CameraBase = Memory->Read<CodPTR>(Addresses::base + Offsets::camera_base);
            if (!Memory->IsValidPointer(CameraBase)) return {};
            return Memory->Read<FVector2D>(CameraBase + Offsets::camera_pos + 0xC); 
        }
        float GetYaw(CodPTR player)
        {
            auto pos = Memory->Read<CodPTR>(player + Offsets::Player::pos);
            if (!Memory->IsValidPointer(pos)) return 0.0f;

            return Memory->Read<float>(pos + 0x70 + 0x10);
        }

        uint32_t GetIndex(uintptr_t Player)
        {
            if (!Memory->IsValidPointer(Player)) return 0;
            auto cl_info_base = decrypt_client_info();
            if (!Memory->IsValidPointer(cl_info_base)) return 0;
            return (Player - cl_info_base) / Offsets::Player::size;
        }

        inline bool IsValid(QWORD player_address)
        {
            return Memory->Read<bool>(player_address + Offsets::Player::valid);
        }

        inline FVector GetPosition(QWORD player_address)
        {
            auto Pos = Memory->Read<CodPTR>(player_address + Offsets::Player::pos);
            if (!Memory->IsValidPointer(Pos)) return {};
            return Memory->Read<FVector>(Pos + 0x70);
        }

        uint8_t TeamIndex(CodPTR player) {
            return Memory->Read<uint8_t>(player + Offsets::Player::team);
        }

        char* GetPlayerName(int Index)
        {
            uint64_t NameListBase = Memory->Read<uint64_t>(Addresses::base + Offsets::name_array);
            NameEntry entry = Memory->Read<NameEntry>(NameListBase + Offsets::name_array_pos + (Index * Offsets::name_size));
            return _strdup(entry.name);
        }

       
        int dex(int Index)
        {
            uint64_t client_info = decrypt_client_info();
            if (!Memory->IsValidPointer(client_info))
                return 0;

            Scoreboard entry = Memory->Read<Scoreboard>(
                client_info + Offsets::scoreboard + (Index * Offsets::scoreboard_size)
            );

            return entry.networkPing;
        }

        bool IsBot(int Index)
        {
            uint64_t client_info = decrypt_client_info();
            if (!Memory->IsValidPointer(client_info))
                return false;

            Scoreboard sb = Memory->Read<Scoreboard>(
                client_info + Offsets::scoreboard + (Index * Offsets::scoreboard_size)
            );

            return sb.isBot == 1;
        }
        NameEntry GetPlayerEntry(int Index)
        {
            uint64_t NameListBase = Memory->Read<uint64_t>(Addresses::base + Offsets::name_array);
            return Memory->Read<NameEntry>(NameListBase + Offsets::name_array_pos + (Index * Offsets::name_size));
        }

        FVector GetSpeed(int index)
        {
            return Velocity[index].delta;
        }
        FVector GetPrediction(int index, FVector source, FVector destination, uintptr_t LocalPlayer)
        {
            if (!Settings::PredictionEnabled)
                return destination;

            auto local_velocity = GetSpeed(Engine::Player::GetIndex(LocalPlayer));
            auto target_velocity = GetSpeed(index);

            const auto distance = source.Distance(destination);
            const auto travel_time = distance / Settings::ProjectileSpeed;

            auto pred_destination = destination + (target_velocity - local_velocity) * travel_time;

            if (Settings::VerticalFix)
                pred_destination.Z += 0.5f * std::fabsf(Settings::Gravity) * travel_time;

            return pred_destination;
        }
    }
    namespace Game {
    
        inline bool IsInGame()
        {
            return Memory->Read<int>(Addresses::base + Offsets::game_mode) > 1;
        }

        inline int PlayerCount()
        {
            return Memory->Read<int>(Addresses::base + Offsets::game_mode);
        }

        FVector CameraPosition()
        {
            auto Camera = Memory->Read<CodPTR>(Addresses::base + Offsets::camera_base);
            if (!Memory->IsValidPointer(Camera)) return {};
            return Memory->Read<FVector>(Camera + Offsets::camera_pos);
        }
        FVector2D GetAngles()
        {
            auto Agnle = Memory->Read<CodPTR>(Addresses::base + Offsets::camera_base);
            if (!Memory->IsValidPointer(Agnle)) return {};
            return Memory->Read<FVector2D>(Agnle + Offsets::camera_pos + 0xC);
        }
        bool W2S(FVector world_location, FVector2D& out, FVector camera_pos, int screen_width, int screen_height, FVector2D fov, FVector matricies[3])
        {
            auto local = world_location - camera_pos;
            auto trans = FVector{
                local.Dot(matricies[1]),
                local.Dot(matricies[2]),
                local.Dot(matricies[0])
            };

            if (trans.Z < 0.01f) {
                return false;
            }

            out.X = ((float)screen_width / 2.0) * (1.0 - (trans.X / fov.X / trans.Z));
            out.Y = ((float)screen_height / 2.0) * (1.0 - (trans.Y / fov.Y / trans.Z));

            if (out.X < 1 || out.Y < 1 || (out.X > DecryptRefDef->ref_def_nn.width) || (out.Y > DecryptRefDef->ref_def_nn.height)) {
                return false;
            }

            return true;
        }
        bool WorldToScreen(FVector world_position, FVector2D& screen_position)
        {
            return W2S(world_position, screen_position, CameraPosition(), DecryptRefDef->ref_def_nn.width, DecryptRefDef->ref_def_nn.height, DecryptRefDef->ref_def_nn.tan_half_fov, DecryptRefDef->ref_def_nn.axis);
        }  
        bool IsVisible(int index)
        {
            auto sighted_enemy_fools = Memory->Read<ClientBits>((CodPTR)decrypt_client_info() + Offsets::visible_bit);//VisibleBit aka sighted enemy fools
            auto bitmask = 0x80000000 >> (index & 0x1F);

            return sighted_enemy_fools.array[index >> 5] & bitmask;
        }
    }
    namespace Bones {
        bool GetBone(int i, const int Bone, FVector* Out)
        {
            auto DecryptedPointer = decrypt_bone_base();
            if (!Memory->IsValidPointer(DecryptedPointer)) return false;
            unsigned short Index = get_bone_index(i);
            if (Index != 0)
            {
                uint64_t BonePointer = Memory->Read<uint64_t>(DecryptedPointer + (Index * Offsets::Bone::size) + Offsets::Bone::offset);
                if (!Memory->IsValidPointer(BonePointer)) return false;

                FVector BonePosition = Memory->Read<FVector>(BonePointer + (Bone * 0x20) + 0x10);
                if (BonePosition.Empty()) return false;

                uint64_t ClientInfo = decrypt_client_info();
                if (!Memory->IsValidPointer(ClientInfo)) return false;

                FVector BasePos = Memory->Read<FVector>(ClientInfo + Offsets::Bone::bone_base);
                if (BasePos.Empty()) return false;

                BonePosition.X += BasePos.X;
                BonePosition.Y += BasePos.Y;
                BonePosition.Z += BasePos.Z;

                *Out = BonePosition;
                return Out;
            }
            return {};
        }

        FVector GetBonePositionVector(const CodPTR Client_Information)
        {
            return Memory->Read<FVector>(Client_Information + Offsets::Bone::bone_base);
        }

        _QWORD BonePointer(_QWORD base, _QWORD index)
        {
            return Memory->Read<CodPTR>(base + (index * Offsets::Bone::size) + Offsets::Bone::offset);
        }

        bool BonesToScreen(const FVector* BonePosArray, FVector2D* ScreenPosArray, const long Count)
        {
            for (long i = 0; i < Count; ++i)
            {
                if (!Game::W2S(BonePosArray[i], ScreenPosArray[i], Game::CameraPosition(), DecryptRefDef->ref_def_nn.width, DecryptRefDef->ref_def_nn.height, DecryptRefDef->ref_def_nn.tan_half_fov, DecryptRefDef->ref_def_nn.axis))continue;
                if (!Game::WorldToScreen(BonePosArray[i], ScreenPosArray[i]))
                    return false;
            }
            return true;
        }

        bool IsBoneValid(FVector* bone, const long Count, FVector origin)
        {
            for (long i = 0; i < Count; ++i)
            {
                if (bone[i].DistTo(bone[i + 1]) > 38 && origin.DistTo(bone[i]) > 500)
                    return false;
            }
            return true;
        }
    }


    namespace Utils {
        float UnitsToMeters(float Units) {
            return Units * 0.0254;
        }
    }

}
typedef struct Entities_
{
    CodPTR Player;
    int i;
} Entities_;
std::vector<Entities_> EntityList;