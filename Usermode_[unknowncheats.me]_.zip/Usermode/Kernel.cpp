#include <Windows.h>
#include <iostream>
#include <TlHelp32.h>
#include <stdio.h>
#include <string_view>
#include <iostream>
#include <chrono>
#include "Kernel.hpp"

const std::uint32_t Kernel::Communications::GetPIDForProcess(const std::wstring& Process)
{
	PROCESSENTRY32 proc_info;
	proc_info.dwSize = sizeof(proc_info);
	HANDLE proc_snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
	if (proc_snapshot == INVALID_HANDLE_VALUE) {
		return 0;
	}
	Process32First(proc_snapshot, &proc_info);
	if (!wcscmp(proc_info.szExeFile, Process.c_str()))
	{
		CloseHandle(proc_snapshot);
		return proc_info.th32ProcessID;
	}
	while (Process32Next(proc_snapshot, &proc_info))
	{
		if (!wcscmp(proc_info.szExeFile, Process.c_str()))
		{
			CloseHandle(proc_snapshot);
			return proc_info.th32ProcessID;
		}
	}
	CloseHandle(proc_snapshot);
	return 0;
}

BOOL Kernel::Communications::SendToKernel(void* data, requests code)
{
	if (!data || !code)
		return false;
	IO_STATUS_BLOCK block;
	invoke_data request{ 0 };
	request.unique = requests::invoke_unique;
	request.data = data;
	request.code = code;
	auto result = direct_device_control(this->Handle, nullptr, nullptr, nullptr, &block, 0, &request, sizeof(request), &request, sizeof(request));
	return result;
}

BOOL Kernel::Communications::Setup()
{
	this->Handle = CreateFileA(device_name, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, 0, 3, 0x00000080, 0);
	if (this->Handle != INVALID_HANDLE_VALUE) {
		return true;
	}
	return false;
}

BOOL Kernel::Communications::AttachToProcess(
	int a_pid)
{
	if (!a_pid)
		return false;

	this->Pid = a_pid;

	return true;
}

BOOL Kernel::Communications::VirtualProtect(const std::uintptr_t address, const size_t size, const DWORD allocation_type)
{
	palloc_invoke data{ 0 };
	data->address = address;
	data->dwSize = size;
	data->flAllocationType = allocation_type;
	auto result = this->SendToKernel(&data, invoke_protect_virtual);
	return result;
}

const std::uintptr_t Kernel::Communications::GetImageBase(const char* module_name)
{
	base_invoke data{ 0 };
	data.pid = this->Pid;
	data.handle = 0;
	data.name = module_name;
	this->SendToKernel(&data, invoke_base);
	return data.handle;
}

bool Kernel::Communications::WriteVirtualAddress(const std::uintptr_t address, void* buffer, const std::size_t size)
{
	write_invoke data{ 0 };
	data.pid = this->Pid;
	data.address = address;
	data.buffer = buffer;
	data.size = size;
	auto result = this->SendToKernel(&data, invoke_write);
	return result;
}

BOOL Kernel::Communications::ReadVirtualAddress(const std::uintptr_t address, void* buffer, const std::size_t size)
{
	read_invoke data{ 0 };
	data.pid = this->Pid;
	data.dtb = this->dtb;
	data.address = address;
	data.buffer = buffer;
	data.size = size;

	auto result = this->SendToKernel(&data, invoke_read);
	return result;
}

BOOL Kernel::Communications::ReadKernelAddress(const uintptr_t address, void* buffer, const size_t size, const uint32_t memory_type)
{
	read_kernel_invoke data{ 0 };
	data.address = address;
	data.buffer = buffer;
	data.size = size;
	data.memory_type = memory_type;
	auto result = this->SendToKernel(&data, invoke_read_kernel);
	return result;
}

const std::uintptr_t Kernel::Communications::SetupCr3()
{
	dtb_invoke data{ 0 };
	data.pid = this->Pid;
	data.dtb = 0;
	auto result = this->SendToKernel(&data, invoke_cr3);
	return data.dtb;
}

const std::uintptr_t Kernel::Communications::GetProcessPeb()
{
	pidinvoke_peb data{ 0 };
	data.pid = this->Pid;
	data.peb = 0;
	auto result = this->SendToKernel(&data, invoke_peb);
	return data.peb;
}