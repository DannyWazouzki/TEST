﻿#pragma once
#include "GamePadSetup.h"
#include <random>
#include <Xinput.h>
#pragma comment(lib, "Xinput.lib")
void draw_bones(FVector2D* bones_screenPos, long count, ImColor color)
{
	long last_count = count - 1;
	for (long i = 0; i < last_count; ++i)
		draw_line(bones_screenPos[i].X, bones_screenPos[i].Y, bones_screenPos[i + 1].X, bones_screenPos[i + 1].Y, 1.8f, color);
}
void draw_bones(unsigned long i, FVector origin, ImColor color)
{
	FVector header_to_bladder[6], right_foot_to_bladder[5], left_foot_to_bladder[5], right_hand[5], left_hand[5];
	FVector2D screen_header_to_bladder[6], screen_right_foot_to_bladder[5], screen_left_foot_to_bladder[5], screen_right_hand[5], screen_left_hand[5]; screen_left_hand[5];

	if (Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_HEAD, &header_to_bladder[0]) &&
		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_NECK, &header_to_bladder[1]) &&
		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_CHEST, &header_to_bladder[2]) &&
		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_MID, &header_to_bladder[3]) &&
		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_TUMMY, &header_to_bladder[4]) &&
		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_PELVIS, &header_to_bladder[5]) &&

		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_RIGHT_FOOT_1, &right_foot_to_bladder[1]) &&
		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_RIGHT_FOOT_2, &right_foot_to_bladder[2]) &&
		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_RIGHT_FOOT_3, &right_foot_to_bladder[3]) &&
		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_RIGHT_FOOT_4, &right_foot_to_bladder[4]) &&

		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_LEFT_FOOT_1, &left_foot_to_bladder[1]) &&
		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_LEFT_FOOT_2, &left_foot_to_bladder[2]) &&
		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_LEFT_FOOT_3, &left_foot_to_bladder[3]) &&
		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_LEFT_FOOT_4, &left_foot_to_bladder[4]) &&

		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_LEFT_HAND_1, &right_hand[1]) &&
		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_LEFT_HAND_2, &right_hand[2]) &&
		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_LEFT_HAND_3, &right_hand[3]) &&
		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_LEFT_HAND_4, &right_hand[4]) &&

		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_RIGHT_HAND_1, &left_hand[1]) &&
		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_RIGHT_HAND_2, &left_hand[2]) &&
		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_RIGHT_HAND_3, &left_hand[3]) &&
		Engine::Bones::GetBone(i, BONE_INDEX::BONE_POS_RIGHT_HAND_4, &left_hand[4]))
	{
		right_foot_to_bladder[0] = header_to_bladder[5];
		left_foot_to_bladder[0] = header_to_bladder[5];
		right_hand[0] = header_to_bladder[3];
		left_hand[0] = header_to_bladder[3];


		if (!Engine::Bones::IsBoneValid(header_to_bladder, 6, origin) ||
			!Engine::Bones::IsBoneValid(right_foot_to_bladder, 5, origin) ||
			!Engine::Bones::IsBoneValid(left_foot_to_bladder, 5, origin) ||
			!Engine::Bones::IsBoneValid(right_hand, 5, origin) ||
			!Engine::Bones::IsBoneValid(left_hand, 5, origin))
		{
			return;
		}

		if (!Engine::Bones::BonesToScreen(header_to_bladder, screen_header_to_bladder, 6))
			return;

		if (!Engine::Bones::BonesToScreen(right_foot_to_bladder, screen_right_foot_to_bladder, 5))
			return;

		if (!Engine::Bones::BonesToScreen(left_foot_to_bladder, screen_left_foot_to_bladder, 5))
			return;

		if (!Engine::Bones::BonesToScreen(right_hand, screen_right_hand, 5))
			return;

		if (!Engine::Bones::BonesToScreen(left_hand, screen_left_hand, 5))
			return;



		draw_bones(screen_header_to_bladder, 6, color);
		draw_bones(screen_right_foot_to_bladder, 5, color);
		draw_bones(screen_left_foot_to_bladder, 5, color);
		draw_bones(screen_right_hand, 5, color);
		draw_bones(screen_left_hand, 5, color);

	}
}

void ControllerToMouse()
{
	if (!Settings::UseGamepad) return;

	XINPUT_STATE state;
	ZeroMemory(&state, sizeof(XINPUT_STATE));

	if (XInputGetState(0, &state) == ERROR_SUCCESS)
	{
		SHORT stickX = state.Gamepad.sThumbRX;
		SHORT stickY = state.Gamepad.sThumbRY;

		if (abs(stickX) > Settings::DeadZone || abs(stickY) > Settings::DeadZone)
		{
			int moveX = static_cast<int>(stickX * Settings::StickSensitivity);
			int moveY = static_cast<int>(-stickY * Settings::StickSensitivity);

			mouse_event(MOUSEEVENTF_MOVE, moveX, moveY, 0, 0);
		}
	}
}

void TestLoop()
{
    static bool EnemyInsideFov = false;
    EnemyInsideFov = false;

    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));
    XInputGetState(0, &state);

    if (Engine::Game::IsInGame())
    {
        DecryptRefDef->ref_def_nn = Memory->Read<RefDef_T>(DecryptRefDef->GetRefDef());
        int PlayerCount = Engine::Game::PlayerCount();
        Addresses::LocalPlayer = Engine::Player::GetLocalPlayer();
        if (!Memory->IsValidPointer(Addresses::LocalPlayer)) return;

        auto LocalIndex = Engine::Player::GetIndex(Addresses::LocalPlayer);
        auto LocalTeamIndex = Engine::Player::TeamIndex(Addresses::LocalPlayer);
        uint64_t client_info = decrypt_client_info();

        struct TargetInfo {
            int index = -1;
            float fovDistance = FLT_MAX;
            FVector2D screenPos{};
        } bestTarget;

        for (int i = 0; i < PlayerCount; ++i)
        {
            if (i == LocalIndex) continue;

            auto Player = Engine::Player::GetPlayer(i);
            if (!Player) continue;

            Scoreboard sb = Memory->Read<Scoreboard>(
                client_info + Offsets::scoreboard + (i * Offsets::scoreboard_size)
            );
            if (sb.status == 2) continue;

            NameEntry entry = Engine::Player::GetPlayerEntry(i);
            if (entry.health <= 0) continue;

            if (Engine::Player::TeamIndex(Player) == LocalTeamIndex) continue;
            if (!Engine::Player::IsValid(Player)) continue;

            bool IsVisible = Engine::Game::IsVisible(i);
            ImColor color = IsVisible
                ? ImColor(Settings::VisibleColor[0], Settings::VisibleColor[1], Settings::VisibleColor[2], Settings::VisibleColor[3])
                : ImColor(Settings::NotVisibleColor[0], Settings::NotVisibleColor[1], Settings::NotVisibleColor[2], Settings::NotVisibleColor[3]);

            FVector dpos = Engine::Player::GetPosition(Player);
            FVector Head_pos = dpos;
            Head_pos.Z += 58.0;

            FVector2D ScreenPos, headpos2d;
            if (!Engine::Game::WorldToScreen(dpos, ScreenPos)) continue;
            if (!Engine::Game::WorldToScreen(Head_pos, headpos2d)) continue;

            float PawnHeight = abs(headpos2d.Y - ScreenPos.Y);
            float PawnWidth = PawnHeight * 0.55f;
            float OffsetY = 10;
            float Distance = Engine::Player::GetPosition(Addresses::LocalPlayer).Distance(dpos) / 40;



            if (Settings::Box)
                draw_box(headpos2d.X - (PawnWidth / 2), headpos2d.Y, PawnWidth, PawnHeight, color, 1.0f);

            if (Settings::Snaplines)
                draw_line(DecryptRefDef->ref_def_nn.width / 2, DecryptRefDef->ref_def_nn.height, ScreenPos.X, ScreenPos.Y, 1.f, color);

            if (Settings::Ping)
            {
                char ping[64];
                sprintf_s(ping, _("[ %dms ]"), sb.networkPing);
                ImVec2 TextSize = ImGui::CalcTextSize(ping);
                ImVec2 pos = ImVec2(ScreenPos.X - TextSize.x / 2, ScreenPos.Y + OffsetY - TextSize.y / 2);
                DrawString(11, pos, color, false, true, ping);
                OffsetY += 15;
            }

            if (Settings::Nicknames)
            {
                auto PlayerName = Engine::Player::GetPlayerName(i);
                ImVec2 TextSize = ImGui::CalcTextSize(PlayerName);
                ImVec2 pos = ImVec2(ScreenPos.X - TextSize.x / 2, ScreenPos.Y + OffsetY - TextSize.y / 2);
                DrawString(11, pos, color, false, true, PlayerName);
                free(PlayerName);
                OffsetY += 15;
            }

            if (Settings::Health)
            {
                int health = std::clamp(entry.health, 0, 100);
                float barH = PawnHeight * (health / 100.f);
                float barW = PawnWidth / 12;
                float barX = headpos2d.X - (PawnWidth / 2) - barW - 4;
                ImDrawList* draw = ImGui::GetBackgroundDrawList();
                draw->AddRectFilled(ImVec2(barX, headpos2d.Y), ImVec2(barX + barW, headpos2d.Y + PawnHeight), ImColor(0, 0, 0, 150));
                draw->AddRectFilled(ImVec2(barX + 1, headpos2d.Y + 1 + (PawnHeight - barH)), ImVec2(barX + barW - 1, headpos2d.Y + PawnHeight - 1), ImColor::HSV((health / 100.f) * 0.3f, 1, 1));
            }
          

            if (Settings::Distance)
            {
                char dist[64];
                sprintf_s(dist, _("[ %.fm ]"), Distance);
                ImVec2 TextSize = ImGui::CalcTextSize(dist);
                ImVec2 pos = ImVec2(ScreenPos.X - TextSize.x / 2, ScreenPos.Y + OffsetY - TextSize.y / 2);
                DrawString(11, pos, color, false, true, dist);
                OffsetY += 15;
            }

            if (Settings::Skeleton)
                draw_bones(i, Engine::Player::GetPosition(Player), color);

            if (!Settings::VisibleCheck || IsVisible)
            {
                FVector current_bone;
                FVector2D bone_screen_pos;
                Engine::Bones::GetBone(i, Settings::Aimbone, &current_bone);
                if (!Engine::Game::WorldToScreen(current_bone, bone_screen_pos)) continue;

                float dx = bone_screen_pos.X - (HUD_Info::Width / 2);
                float dy = bone_screen_pos.Y - (HUD_Info::Height / 2);
                float fovDist = crt::sqrtf(dx * dx + dy * dy);

                if (fovDist <= Settings::FovCircle_Value)
                {
                    if (fovDist < bestTarget.fovDistance)
                    {
                        bestTarget.index = i;
                        bestTarget.fovDistance = fovDist;
                        bestTarget.screenPos = bone_screen_pos;
                    }
                    EnemyInsideFov = true;
                }
            }
        }

        if (bestTarget.index != -1)
        {
            float dx = bestTarget.screenPos.X - (HUD_Info::Width / 2.f);
            float dy = bestTarget.screenPos.Y - (HUD_Info::Height / 2.f);

            bool should_aimbot_fire = false;
            if (Hook->NtUserGetAsyncKeyState(Settings::Aimkey)) should_aimbot_fire = true;
            if (state.Gamepad.bLeftTrigger > 128) should_aimbot_fire = true;

            if (should_aimbot_fire)
            {
                dx /= Settings::Smoothness;
                dy /= Settings::Smoothness;

                mouse_event(MOUSEEVENTF_MOVE, 1, 0, 0, 0);
                mouse_event(MOUSEEVENTF_MOVE, -1, 0, 0, 0);
                mouse_event(MOUSEEVENTF_MOVE, static_cast<int>(dx), static_cast<int>(dy), 0, 0);
            }
        }

        ControllerToMouse();

        if (Settings::ShowFOVCircle)
        {
            ImVec2 center = ImVec2(HUD_Info::Width / 2.0f, HUD_Info::Height / 2.0f);
            float radius = Settings::FovCircle_Value;

            ImColor colorOutline = EnemyInsideFov ? ImColor(255, 0, 0, 200) : ImColor(255, 255, 255, 200);
            ImColor colorShadow = EnemyInsideFov ? ImColor(50, 0, 0, 150) : ImColor(0, 0, 0, 100);

            ImGui::GetBackgroundDrawList()->AddCircle(center, radius, colorShadow, 128, 2.5f);
            ImGui::GetBackgroundDrawList()->AddCircle(center, radius, colorOutline, 128, 1.5f);
        }

     
    }
}




inline VOID ProcessLoop()
{
    if (Settings::ShowFOVCircle)
    {
        ImVec2 center = ImVec2(HUD_Info::Width / 2.0f, HUD_Info::Height / 2.0f);
        float radius = Settings::FovCircle_Value;

        ImColor colorOutline = ImColor(
            Settings::fovCircleColor[0],
            Settings::fovCircleColor[1],
            Settings::fovCircleColor[2],
            Settings::fovCircleColor[3]
        );
        ImColor colorShadow = ImColor(0, 0, 0, 100); 

        ImGui::GetBackgroundDrawList()->AddCircle(center, radius, colorShadow, 128, 2.5f);
        ImGui::GetBackgroundDrawList()->AddCircle(center, radius, colorOutline, 128, 1.5f);
    }
	if (Settings::ShowCrosshair)
	{
		float lineLength = 6.0f;
		float gap = 3.0f;
		float thickness = 1.5f;
		ImColor color = ImColor(255, 255, 255, 255);

		float centerX = DecryptRefDef->ref_def_nn.width / 2;
		float centerY = DecryptRefDef->ref_def_nn.height / 2;
		ImVec2 center = ImVec2(centerX, centerY);
		ImDrawList* draw = ImGui::GetBackgroundDrawList();


		draw->AddLine(ImVec2(center.x, center.y - gap - lineLength), ImVec2(center.x, center.y - gap), color, thickness);
		draw->AddLine(ImVec2(center.x, center.y + gap), ImVec2(center.x, center.y + gap + lineLength), color, thickness);
		draw->AddLine(ImVec2(center.x - gap - lineLength, center.y), ImVec2(center.x - gap, center.y), color, thickness);
		draw->AddLine(ImVec2(center.x + gap, center.y), ImVec2(center.x + gap + lineLength, center.y), color, thickness);
	}
	TestLoop();
}