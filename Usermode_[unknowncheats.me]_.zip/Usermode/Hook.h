#pragma once

class Syscall {
public:
	BYTE NtUserSendInput_Bytes[30];
	BYTE NtUserGetAsyncKeyState_Bytes[30];

	BOOLEAN WINAPI Setup()
	{
		HMODULE user32 = LI_FN(LoadLibraryA).get()(_("user32.dll"));
		HMODULE kernel32 = LI_FN(LoadLibraryA).get()(_("Kernel32.dll"));
		HMODULE win32u = LI_FN(LoadLibraryA).get()(_("win32u.dll"));
		HMODULE dwmapi = LI_FN(LoadLibraryA).get()(_("dwmapi.dll"));
		LPVOID NtUserSendInput_Addr = LI_FN(GetProcAddress).safe()(LI_FN(GetModuleHandleW).safe()(_(L"win32u")), _("NtUserSendInput"));
		if (!NtUserSendInput_Addr)
		{
			NtUserSendInput_Addr = LI_FN(GetProcAddress).safe()(LI_FN(GetModuleHandleW).safe()(_(L"user32")), _("NtUserSendInput"));
			if (!NtUserSendInput_Addr)
			{
				NtUserSendInput_Addr = LI_FN(GetProcAddress).safe()(LI_FN(GetModuleHandleW).safe()(_(L"user32")), _("SendInput"));
				if (!NtUserSendInput_Addr)
					return FALSE;
			}
		}

		LPVOID NtUserGetAsyncKeyState_Addr = LI_FN(GetProcAddress).safe()(LI_FN(GetModuleHandleW).safe()(_(L"win32u")), _("NtUserGetAsyncKeyState"));
		if (!NtUserGetAsyncKeyState_Addr)
		{
			NtUserGetAsyncKeyState_Addr = LI_FN(GetProcAddress).safe()(LI_FN(GetModuleHandleW).safe()(_(L"user32")), _("NtUserGetAsyncKeyState"));
			if (!NtUserGetAsyncKeyState_Addr)
			{
				NtUserGetAsyncKeyState_Addr = LI_FN(GetProcAddress).safe()(LI_FN(GetModuleHandleW).safe()(_(L"user32")), _("GetAsyncKeyState"));
				if (!NtUserGetAsyncKeyState_Addr)
					return FALSE;
			}
		}
		memcpy(NtUserSendInput_Bytes, NtUserSendInput_Addr, 30);
		memcpy(NtUserGetAsyncKeyState_Bytes, NtUserGetAsyncKeyState_Addr, 30);
		return TRUE;
	}

	BOOLEAN WINAPI NtUserSendInput(UINT cInputs, LPINPUT pInputs, int cbSize)
	{
		LPVOID NtUserSendInput_Spoof = VirtualAlloc(0, 0x1000, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
		if (!NtUserSendInput_Spoof)
			return FALSE;
		memcpy(NtUserSendInput_Spoof, NtUserSendInput_Bytes, 30);
		NTSTATUS Result = reinterpret_cast<NTSTATUS(NTAPI*)(UINT, LPINPUT, int)>(NtUserSendInput_Spoof)(cInputs, pInputs, cbSize);
		ZeroMemory(NtUserSendInput_Spoof, 0x1000);
		VirtualFree(NtUserSendInput_Spoof, 0, MEM_RELEASE);
		return (Result > 0);
	}

	UINT WINAPI NtUserGetAsyncKeyState(UINT Key)
	{
		LPVOID NtUserGetAsyncKeyState_Spoof = VirtualAlloc(0, 0x1000, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
		if (!NtUserGetAsyncKeyState_Spoof)
			return FALSE;
		memcpy(NtUserGetAsyncKeyState_Spoof, NtUserGetAsyncKeyState_Bytes, 30);
		NTSTATUS Result = reinterpret_cast<NTSTATUS(NTAPI*)(UINT)>(NtUserGetAsyncKeyState_Spoof)(Key);
		ZeroMemory(NtUserGetAsyncKeyState_Spoof, 0x1000);
		VirtualFree(NtUserGetAsyncKeyState_Spoof, 0, MEM_RELEASE);
		return Result;
	}

	BOOLEAN WINAPI Move_Mouse(int X, int Y)
	{
		INPUT input;
		input.type = INPUT_MOUSE;
		input.mi.mouseData = 0;
		input.mi.time = 0;
		input.mi.dx = X;
		input.mi.dy = Y;
		input.mi.dwFlags = MOUSEEVENTF_MOVE | MOUSEEVENTF_VIRTUALDESK;
		return NtUserSendInput(1, &input, sizeof(input));
	}

	VOID SendLeftClick() {
		INPUT inputs[2] = {};
		inputs[0].type = INPUT_MOUSE;
		inputs[0].mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
		inputs[1].type = INPUT_MOUSE;
		inputs[1].mi.dwFlags = MOUSEEVENTF_LEFTUP;
		NtUserSendInput(2, inputs, sizeof(INPUT));
	}

	VOID MoveTo(float x, float y, int Width, int Height, int Smoothness, bool Humanize) {
		if (Humanize) {
			static float PrevDeltaX = 0.0f, PrevDeltaY = 0.0f;
			float ScreenCenterX = Width / 2.0f;
			float ScreenCenterY = Height / 2.0f;

			float DeltaX = x - ScreenCenterX;
			float DeltaY = y - ScreenCenterY;

			DeltaX = (PrevDeltaX * 0.8f) + (DeltaX * 0.2f);
			DeltaY = (PrevDeltaY * 0.8f) + (DeltaY * 0.2f);

			PrevDeltaX = DeltaX;
			PrevDeltaY = DeltaY;
			DeltaX /= Smoothness;
			DeltaY /= Smoothness;

			float MaxStep = 5.0f;
			DeltaX = std::clamp(DeltaX, -MaxStep, MaxStep);
			DeltaY = std::clamp(DeltaY, -MaxStep, MaxStep);

			Move_Mouse(DeltaX, DeltaY);
		}
		else
		{
			float ScreenCenterX = (Width / 2);
			float ScreenCenterY = (Height / 2);
			int Smooth = Smoothness;
			float TargetX = 0;
			float TargetY = 0;

			if (x != 0) {
				if (x > ScreenCenterX) {
					TargetX = -(ScreenCenterX - x);
					TargetX /= Smooth;
					if (TargetX + ScreenCenterX > ScreenCenterX * 2) TargetX = 0;
				}

				if (x < ScreenCenterX) {
					TargetX = x - ScreenCenterX;
					TargetX /= Smooth;
					if (TargetX + ScreenCenterX < 0) TargetX = 0;
				}
			}

			if (y != 0) {
				if (y > ScreenCenterY) {
					TargetY = -(ScreenCenterY - y);
					TargetY /= Smooth;
					if (TargetY + ScreenCenterY > ScreenCenterY * 2) TargetY = 0;
				}

				if (y < ScreenCenterY) {
					TargetY = y - ScreenCenterY;
					TargetY /= Smooth;
					if (TargetY + ScreenCenterY < 0) TargetY = 0;
				}
			}

			TargetX = std::clamp(TargetX, -ScreenCenterX, ScreenCenterX);
			TargetY = std::clamp(TargetY, -ScreenCenterY, ScreenCenterY);

			Move_Mouse(TargetX, TargetY);
		}
		return;
	}
}; static Syscall* Hook = new Syscall();