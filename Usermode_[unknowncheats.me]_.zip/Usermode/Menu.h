﻿#pragma once
#define IMGUI_DEFINE_MATH_OPERATORS
#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"
#include "imgui/imgui_impl_dx11.h"
#include "imgui/imgui_impl_win32.h"
float BigFontSize = 20.0f;
#include <iostream>
#include <dwmapi.h>
#include <d3d11.h>
#include <d3dx11.h>
#include <D3DX11tex.h>
#include <math.h>
#include <tchar.h>
#include <thread>
#include "Font.h"
#include "image.h"
#include "etc_element.h"
#pragma comment(lib, "dwmapi.lib")
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "D3DX11.lib")
ImFont* Regular_Font = nullptr;
ImFont* Regular_Font_1 = nullptr;
ImFont* Bold_Font = nullptr;
ImFont* Medium_Font = nullptr;
ImFont* Esp_Font = nullptr;
ID3D11RenderTargetView* g_mainRenderTargetView;
ID3D11Device* g_pd3dDevice;
ImFont* BigFont = nullptr;
inline ID3D11Device* d3d_device;
inline ID3D11DeviceContext* d3d_device_ctx;
inline IDXGISwapChain* d3d_swap_chain;
inline ID3D11RenderTargetView* d3d_render_target;
inline HWND window_handle;
D3DX11_IMAGE_LOAD_INFO info;
ID3DX11ThreadPump* pump{ nullptr };
static bool ShowMenu = 1;
HWND MyWnd = NULL;
static int previousPage = -1;
ID3D11DeviceContext* g_pd3dDeviceContext;
IDXGISwapChain* g_pSwapChain;

#define ALPHA ( ImGuiColorEditFlags_AlphaPreview | ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_InputRGB | ImGuiColorEditFlags_Float | ImGuiColorEditFlags_NoDragDrop | ImGuiColorEditFlags_PickerHueBar | ImGuiColorEditFlags_NoBorder )
void CustomStyleColor()
{
	ImGuiStyle& s = ImGui::GetStyle();

	s.Colors[ImGuiCol_WindowBg] = ImColor(12, 12, 16, 216);
	s.Colors[ImGuiCol_PopupBg] = ImColor(11, 12, 13, 255);
	s.Colors[ImGuiCol_ChildBg] = ImColor(11, 12, 13, 127);
	s.Colors[ImGuiCol_Border] = ImColor(52, 52, 52, 255);
	s.Colors[ImGuiCol_CheckMark] = ImColor(160, 160, 160);
	s.Colors[ImGuiCol_SliderGrab] = ImColor(100, 100, 100);
	s.Colors[ImGuiCol_SliderGrabActive] = ImColor(160, 160, 160);

	s.Colors[ImGuiCol_Button] = ImColor(40, 40, 40);
	s.Colors[ImGuiCol_ButtonHovered] = ImColor(60, 60, 60);
	s.Colors[ImGuiCol_ButtonActive] = ImColor(80, 80, 80);

	s.Colors[ImGuiCol_FrameBg] = ImColor(30, 30, 30);
	s.Colors[ImGuiCol_FrameBgHovered] = ImColor(50, 50, 50);
	s.Colors[ImGuiCol_FrameBgActive] = ImColor(70, 70, 70);

	s.ChildRounding = 6.f;
	s.WindowRounding = 12.f;
	s.WindowPadding = ImVec2(0, 0);
}
namespace image
{
	ID3D11ShaderResourceView* logo = nullptr;
	ID3D11ShaderResourceView* aimbot = nullptr;
	ID3D11ShaderResourceView* visuals = nullptr;
	ID3D11ShaderResourceView* misc = nullptr;
	ID3D11ShaderResourceView* skins = nullptr;
	ID3D11ShaderResourceView* scripts = nullptr;
	ID3D11ShaderResourceView* combo = nullptr;
	ID3D11ShaderResourceView* settings = nullptr;
}


void LoadStyle()
{
	ImGui::StyleColorsDark();
	ImGuiStyle* style = &ImGui::GetStyle();
	//style->Colors[ImGuiCol_WindowBg] = ImColor(0.16f, 0.16f, 0.16f, 1.00f);
	style->Colors[ImGuiCol_WindowBg] = ImColor(13, 13, 13);
	style->Colors[ImGuiCol_TitleBg] = ImColor(64, 64, 64, 255);
	style->Colors[ImGuiCol_TitleBgActive] = ImColor(64, 64, 64, 255);
	style->Colors[ImGuiCol_TitleBgCollapsed] = ImColor(64, 64, 64, 255);
	style->Colors[ImGuiCol_Border] = ImColor(25, 25, 25, 255);
	style->Colors[ImGuiCol_ChildBg] = ImColor(15, 15, 15, 255);
	style->Colors[ImGuiCol_FrameBgHovered] = ImColor(15, 15, 15, 255);
	style->Colors[ImGuiCol_FrameBgActive] = ImColor(15, 15, 15, 255);
	style->Colors[ImGuiCol_FrameBg] = ImColor(15, 15, 15, 255);
	style->Colors[ImGuiCol_PopupBg] = ImColor(15, 15, 15, 255);
	style->Colors[ImGuiCol_Header] = ImColor(64, 64, 64, 255);
	style->Colors[ImGuiCol_HeaderHovered] = ImColor(64, 64, 64, 255);
	style->Colors[ImGuiCol_HeaderActive] = ImColor(64, 64, 64, 255);
	style->Colors[ImGuiCol_Separator] = ImColor(25, 25, 25, 255);
	style->Colors[ImGuiCol_SeparatorActive] = ImColor(25, 25, 25, 255);
	style->Colors[ImGuiCol_SeparatorHovered] = ImColor(25, 25, 25, 255);
	style->Colors[ImGuiCol_Button] = ImColor(64, 64, 64, 255);
	style->Colors[ImGuiCol_ButtonActive] = ImColor(64, 64, 64, 255);
	style->Colors[ImGuiCol_ButtonHovered] = ImColor(64, 64, 64, 255);
	style->Colors[ImGuiCol_CheckMark] = ImColor(255, 0, 0, 255);
	style->Colors[ImGuiCol_SliderGrab] = ImColor(255, 0, 0, 255);
	style->Colors[ImGuiCol_SliderGrabActive] = ImColor(255, 0, 0, 255);

	/*style->WindowRounding = 0.0f;
	style->WindowBorderSize = 1.0f;
	style->ChildBorderSize = 1.0f;
	style->FrameBorderSize = 1.0f;
	style->ItemSpacing = ImVec2(0, 10);
	style->FramePadding = { 0, 0 };
	style->Alpha = 255;*/
	ImGui::GetStyle().Alpha = 255;
}


#include <filesystem>
#include <vector>
#include <string>
namespace fs = std::filesystem;

float m_fade;
#define GAMEPAD_LEFT_TRIGGER 0x1000
#define GAMEPAD_RIGHT_TRIGGER 0x2000

const char* bones[] = { "Head", "Neck", "Chest", "Pelvis" };

void render_menu()
{
	std::string text1 = _("");
	std::string text2 = _("dex ");
	std::string text3 = _("Overlay FPS: ") + std::to_string(static_cast<int>(ImGui::GetIO().Framerate));
	ImVec2 text1_size = ImGui::CalcTextSize(text1.c_str());
	ImVec2 text2_size = ImGui::CalcTextSize(text2.c_str());
	ImVec2 text3_size = ImGui::CalcTextSize(text3.c_str());

	float max_height = text1_size.y;
	if (text2_size.y > max_height) max_height = text2_size.y;
	if (text3_size.y > max_height) max_height = text3_size.y;

	float total_width = text1_size.x + text2_size.x + text3_size.x + 35.0f;
	float total_height = max_height + 10.0f;
	ImVec2 rect_pos(3, 3);
	ImVec2 rect_size(total_width, total_height);




	if (ShowMenu)
	{
		ImGuiContext& g = *GImGui;
		const ImGuiStyle& style = g.Style;
		CustomStyleColor();
		ImGui::GetStyle().ItemSpacing = ImVec2(0, 12);

		ImGui::SetNextWindowSize(ImVec2(750, 450));
		ImGui::Begin(_("dex.name"), nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoResize);
		{
			const auto& p = ImGui::GetWindowPos();
			const ImVec2& region = ImGui::GetContentRegionMax();
			ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(p.x, p.y), ImVec2(p.x + 175, p.y + region.y), ImColor(12, 12, 16, 148), 12.f, ImDrawFlags_RoundCornersLeft);
			ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(p.x + 175, p.y), ImVec2(p.x + region.x, p.y + 60), ImColor(12, 12, 16, 148), 12.f, ImDrawFlags_RoundCornersTopRight);

			static int page = 0;
			static float tab_alpha = 0.f;
			static float tab_add;
			static int active_tab = 0;

			tab_alpha = ImClamp(tab_alpha + (5.f * ImGui::GetIO().DeltaTime * (page == active_tab ? 1.f : -1.f)), 0.f, 1.f);
			tab_add = ImClamp(tab_add + (std::round(350.f) * ImGui::GetIO().DeltaTime * (page == active_tab ? 1.f : -1.f)), 0.f, 1.f);
			if (tab_alpha == 0.f && tab_add == 0.f) active_tab = page;

			ImGui::GetWindowDrawList()->AddText(Bold_Font, 22.f, ImVec2(p.x + 24, p.y + 17), ImColor(255, 255, 255), "External");

			ImGui::SetCursorPos(ImVec2(12, 72));
			ImGui::BeginGroup();
			{
				ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 12));
				if (ImGui::Tab("Aimbot", 0 == page, ImVec2(150, 35))) page = 0;
				if (ImGui::Tab("ESP", 1 == page, ImVec2(150, 35))) page = 1;
				if (ImGui::Tab("World", 2 == page, ImVec2(150, 35))) page = 2;
				if (ImGui::Tab("Exploits", 3 == page, ImVec2(150, 35))) page = 3;
				if (ImGui::Tab("Misc", 4 == page, ImVec2(150, 35))) page = 4;
				ImGui::PopStyleVar();
			}
			ImGui::EndGroup();

			if (page == 0) 
			{
				ImGui::SetCursorPos(ImVec2(175, 25));
				e_elements::begin_child(_("Aim Child"), ImVec2(580, 425));
				{
					ImGui::SetCursorPos(ImVec2(12, 48));
					ImGui::BeginChild("Aimbot", ImVec2(269, 350), true);
					{
						ImGui::Checkbox("Aimbot Enabled", &Settings::Aimbot);
						static char buttonLabel[64];

						if (Settings::Aimkey == ImGuiKey_None)
							strcpy_s(buttonLabel, "Press key for Aimbot");
						else
							sprintf_s(buttonLabel, "Aimbot Key: %s", ImGui::GetKeyName((ImGuiKey)Settings::Aimkey));

						if (Settings::waiting_for_key)
						{
							ImGui::Text("Press any key...");

							for (int key = ImGuiKey_NamedKey_BEGIN; key < ImGuiKey_NamedKey_END; ++key)
							{
								if (ImGui::IsKeyPressed((ImGuiKey)key))
								{
									Settings::Aimkey = key;
									Settings::waiting_for_key = false;
									sprintf_s(buttonLabel, "Aimbot Key: %s", ImGui::GetKeyName((ImGuiKey)key));
									break;
								}
							}
						}
						else
						{
							if (ImGui::Button(buttonLabel))
							{
								Settings::waiting_for_key = true;
							}
						}


						static const char* bones[] = { "Head", "Neck", "Chest", "Pelvis" };
						ImGui::Combo("Priority", &Settings::AimBone_Selector, bones, IM_ARRAYSIZE(bones));
						ImGui::Checkbox("Show FOV Circle", &Settings::ShowFOVCircle);
						ImGui::SliderInt("Fov Radius", &Settings::FovCircle_Value, 1, 1200);
						ImGui::Checkbox("Sticky Humanization", &Settings::Humanization);
						ImGui::Checkbox("AutoShoot", &Settings::AutoShoot);
						ImGui::Checkbox("Use Gamepad for Aimbot", &Settings::UseGamepad);

						if (Settings::UseGamepad)
						{
							ImGui::SliderFloat("Stick Sensitivity", &Settings::StickSensitivity, 0.01f, 1.0f, "%.3f");
							ImGui::SliderInt("Stick Deadzone", &Settings::DeadZone, 0, 20000);
						}
					}
					ImGui::EndChild();

					ImGui::SameLine(0, 12);

					ImGui::BeginChild("Aimbot Settings", ImVec2(269, 350), true);
					{
						ImGui::Checkbox("Enable Prediction", &Settings::PredictionEnabled);
						if (Settings::PredictionEnabled) {

							ImGui::SliderFloat("Projectile Speed", &Settings::ProjectileSpeed, 1.0f, 5000.0f, "%.1f");
							ImGui::SliderFloat("Gravity", &Settings::Gravity, -100.0f, 0.0f, "%.1f");
						}
						ImGui::Checkbox("Vertical Fix", &Settings::VerticalFix);
						ImGui::Checkbox("Visible Check", &Settings::VisibleCheck);
						ImGui::Checkbox("Use Smooth", &Settings::Enable);
						if (Settings::Enable) {
							ImGui::SliderInt("Smoothness", &Settings::Smoothness, 1, 10);
						}
						
					}
					ImGui::EndChild();
				}
				e_elements::end_child();
			}



			else if (page == 1)
			{
				ImGui::SetCursorPos(ImVec2(175, 25));
				e_elements::begin_child(_("ESP"), ImVec2(580, 425));
				{
					ImGui::SetCursorPos(ImVec2(12, 48));
					ImGui::BeginChild(_("Settings"), ImVec2(269, 325), false);
					{
						ImGui::Checkbox("Box", &Settings::Box);
						ImGui::Checkbox("Skeleton", &Settings::Skeleton);
						ImGui::Checkbox("Nicknames", &Settings::Nicknames);
						ImGui::Checkbox("Distance", &Settings::Distance);
						ImGui::Checkbox("Health", &Settings::Health);
						ImGui::Checkbox("Ping", &Settings::Ping);
						ImGui::Checkbox("Show Bot Tag", &Settings::ShowBotTag);
						ImGui::Checkbox("Snaplines", &Settings::Snaplines);
						ImGui::Checkbox("Enable VSync", &Settings::VSYC);
						
					}
					
					ImGui::EndChild();

					ImGui::SameLine(0, 12);

					ImGui::BeginChild(_("Settings ESP"), ImVec2(269, 325), false);
					{
						ImGui::Checkbox("Enable Streamproof", &Settings::StreamProof);
						ImGui::Checkbox("Enable Crosshair", &Settings::ShowCrosshair);
						ImGui::Checkbox("Enable Indicators", &Settings::Indicators);

					}
					ImGui::EndChild();
				}
				e_elements::end_child();
			}

			else if (page == 2)
			{
				ImGui::SetCursorPos(ImVec2(175, 25));
				e_elements::begin_child(_("World Child"), ImVec2(580, 425));
				{
					ImGui::SetCursorPos(ImVec2(12, 48));
					ImGui::BeginChild(_("Settings"), ImVec2(269, 325), false);
					{






					}
					ImGui::EndChild();

					ImGui::SameLine(0, 12);

					ImGui::BeginChild(_("World Visuals"), ImVec2(269, 325), false);
					{




					}
					ImGui::EndChild();
				}
				e_elements::end_child();
			}
			else if (page == 3)
			{
				ImGui::SetCursorPos(ImVec2(175, 25));
				e_elements::begin_child(_("Misc Child"), ImVec2(580, 425));
				{
					ImGui::SetCursorPos(ImVec2(12, 48));
					ImGui::BeginChild(_("Exploits (Risky)"), ImVec2(269, 325), false);
					{
						{
							
						}
						ImGui::EndChild();
						ImGui::End();
					}
					
					ImGui::EndChild();
				}
				e_elements::end_child();
			}

			else if (page == 4)
			{
				static char configName[64] = "default";
				static std::vector<std::string> availableConfigs;

				static bool justOpenedConfigPage = true;
				if (previousPage != 4) {
					justOpenedConfigPage = true;
					previousPage = 4;
				}

				ImGui::SetCursorPos(ImVec2(175, 25));
				e_elements::begin_child(_("Config"), ImVec2(580, 425));
				{
					ImGui::SetCursorPos(ImVec2(12, 48));
					ImGui::BeginChild(_("Save Config"), ImVec2(269, 325), false);
					{
						ImGui::SetCursorPosY(20);
						ImGui::Text("Save/Load Custom Config");

						ImGui::SetCursorPosY(50);
						if (justOpenedConfigPage) {
							ImGui::SetKeyboardFocusHere();
							justOpenedConfigPage = false;
						}
						ImGui::InputText("##ConfigName", configName, sizeof(configName), ImGuiInputTextFlags_EnterReturnsTrue);

						std::string fullPath = std::string("Configs/") + configName + ".txt";

						ImGui::SetCursorPosY(90);
						if (ImGui::Button("Save Config", ImVec2(240, 30))) {
							if (strlen(configName) > 0) {
								if (!fs::exists("Configs"))
									fs::create_directory("Configs");
								SaveConfig(fullPath);
							}
						}

						if (ImGui::Button("Load Config", ImVec2(240, 30))) {
							if (fs::exists(fullPath))
								LoadConfig(fullPath);
						}

						if (ImGui::Button("Refresh Config List", ImVec2(240, 30))) {
							availableConfigs.clear();

							if (!fs::exists("Configs"))
								fs::create_directory("Configs");

							for (const auto& entry : fs::directory_iterator("Configs")) {
								if (entry.path().extension() == ".txt")
									availableConfigs.push_back(entry.path().stem().string());
							}
						}
					}
					ImGui::EndChild();

					ImGui::SameLine(0, 12);

					ImGui::BeginChild(_("Available Configs"), ImVec2(269, 325), false);
					{
						ImGui::SetCursorPosY(20);
						ImGui::Text("Select Existing Config");

						for (const auto& cfg : availableConfigs)
						{
							if (ImGui::Selectable(cfg.c_str()))
								strcpy(configName, cfg.c_str());
						}
					}
					ImGui::EndChild();
				}
				e_elements::end_child();
				}


				ImGui::GetWindowDrawList()->AddText({ p.x + 10, p.y + 424 }, ImColor(255, 255, 255, 255), "Test");

		}
		ImGui::End();

	}
}

		
	


void DrawMenu()
{
	if (ShowMenu) {
		ImGui::PushFont(MenuFont);
		render_menu();
		ImGui::PopFont();
		if (Settings::AimBone_Selector == 0)
			Settings::Aimbone = BONE_INDEX::BONE_POS_HEAD;
		if (Settings::AimBone_Selector == 1)
			Settings::Aimbone = BONE_INDEX::BONE_POS_NECK;
		if (Settings::AimBone_Selector == 2)
			Settings::Aimbone = BONE_INDEX::BONE_POS_CHEST;
		if (Settings::AimBone_Selector == 3)
			Settings::Aimbone = BONE_INDEX::BONE_POS_PELVIS;
	}
}

void Shortcuts()
{
	static bool pressed = false;
	static bool pressedF2 = false;

	if (Hook->NtUserGetAsyncKeyState(Keys::Insert) & 0x8000)
		pressed = true;

	else if (!(Hook->NtUserGetAsyncKeyState(Keys::Insert) & 0x8000) && pressed) {
		ShowMenu = !ShowMenu;
		pressed = false;
	}

	if (Hook->NtUserGetAsyncKeyState(Keys::F2) & 0x8000)
		pressedF2 = true;

	else if (!(Hook->NtUserGetAsyncKeyState(Keys::F2) & 0x8000) && pressedF2) {
		Settings::Loot = !Settings::Loot;
		pressedF2 = false;
	}
}

void render()
{
	ImGui_ImplDX11_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();


	g_ControlBoundsList = new std::vector<UControl>();

	ProcessLoop();
	Shortcuts();
	DrawMenu(); 

	ImVec4 clear_color = ImVec4(0., 0., 0., 0.);
	ImGui::Render();

	const float clear_color_with_alpha[4] = {
		clear_color.x * clear_color.w,
		clear_color.y * clear_color.w,
		clear_color.z * clear_color.w,
		clear_color.w
	};

	g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, nullptr);
	g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, clear_color_with_alpha);
	ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

	if (Settings::StreamProof)
		SpoofCall->SetWindowDisplayAffinity(MyWnd, WDA_EXCLUDEFROMCAPTURE);
	else
		SpoofCall->SetWindowDisplayAffinity(MyWnd, WDA_NONE);

	g_pSwapChain->Present(Settings::VSYC ? 1 : 0, 0);
}
