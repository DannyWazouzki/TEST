#pragma once
__forceinline VOID draw_line(int x1, int y1, int x2, int y2, int thickness, ImColor clr) {
	ImGui::GetForegroundDrawList()->AddLine(ImVec2(x1, y1), ImVec2(x2, y2), clr, thickness);
}

void draw_box(float X, float Y, float W, float H, const ImU32& color, float tickness)
{
	ImGui::GetBackgroundDrawList()->AddRect(
		ImVec2(X, Y),
		ImVec2(X + W, Y + H),
		ImGui::GetColorU32(color),
		0.0f,
		0,
		tickness
	);
}

inline VOID draw_bounding_box(int x, int y, float w, float h, int thickness, ImColor color)
{
	ImGui::GetBackgroundDrawList()->AddRect(ImVec2(x, y), ImVec2(x + w, y + h), color, 0, 0, thickness);
}

__forceinline VOID draw_corner_box(int x, int y, int w, int h, int thickness, ImColor clr) {
	draw_line(x, y, x, y + (h / 3.5), thickness, clr);
	draw_line(x, y, x + (w / 3.5), y, thickness, clr);
	draw_line(x + w, y, x + w - (w / 3.5), y, thickness, clr);
	draw_line(x + w, y, x + w, y + (h / 3.5), thickness, clr);
	draw_line(x, y + h, x + (w / 3.5), y + h, thickness, clr);
	draw_line(x, y + h, x, y + h - (h / 3.5), thickness, clr);
	draw_line(x + w, y + h, x + w - (w / 3.5), y + h, thickness, clr);
	draw_line(x + w, y + h, x + w, y + h - (h / 3.5), thickness, clr);
}