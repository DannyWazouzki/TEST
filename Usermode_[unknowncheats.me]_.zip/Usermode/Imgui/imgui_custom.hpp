#pragma once
#define IMGUI_DEFINE_MATH_OPERATORS
#include "imgui.h"
#include "imgui_internal.h"
#include <string>

class custom
{
public:
	bool tab(const char* text, const char* icon, bool selected, ImFont* icon_font);
	void gradient_seperator();
	void begin_child(const char* name, ImVec2 size);
	void end_child();
};

inline custom* imgui_custom;