#include "imgui_custom.hpp"

bool custom::tab(const char* text, const char* icon, bool selected, ImFont* icon_font)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
    {
        return false;
    }

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(text);
    ImVec2 pos = window->DC.CursorPos;
    ImVec2 size = { ImGui::GetContentRegionAvail().x, 25 };
    const ImRect bb(pos, ImVec2(pos.x + size.x, pos.y + size.y));

    ImGui::ItemSize(size, 0);
    if (!ImGui::ItemAdd(bb, id))
    {
        return false;
    }

    bool hovered, held;
    bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held, NULL);

    if (selected)
    {
        ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(bb.Min.x, bb.Min.y), ImVec2(bb.Min.x + size.x, bb.Min.y + size.y), ImGui::GetColorU32(ImGuiCol_FrameBg));
        ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(bb.Min.x, bb.Min.y), ImVec2(bb.Min.x + 4, bb.Min.y + size.y), ImColor(255, 0, 0));
        ImGui::RenderFrameBorder(bb.Min, bb.Max);
    }

    ImVec2 textSize = ImGui::CalcTextSize(text);
    ImGui::PushFont(icon_font);
    ImGui::GetWindowDrawList()->AddText(ImVec2(bb.Min.x + 10, bb.Min.y + (size.y - textSize.y) / 2), selected || hovered ? ImColor(255, 255, 255, 255) : ImColor(155, 155, 155, 255), icon);
    ImGui::PopFont();
    ImGui::GetWindowDrawList()->AddText(ImVec2(bb.Min.x + 33, bb.Min.y + (size.y - textSize.y) / 2), selected || hovered ? ImColor(255, 255, 255, 255) : ImColor(155, 155, 155, 255), text);

    return pressed;
}

void custom::gradient_seperator()
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
    {
        return;
    }
    
    ImGuiContext& g = *GImGui;

    if (window->DC.CurrentColumns)
    {
        ImGui::PopClipRect();
    }

    float x1 = window->Pos.x;
    float x2 = window->Pos.x + window->Size.x;
    /*if (!window->DC.GroupOffset.empty())*/
        x1 += window->DC.Indent.x;

    const ImRect bb(ImVec2(x1, window->DC.CursorPos.y), ImVec2(x2, window->DC.CursorPos.y + 1.0f));
    ImGui::ItemSize(ImVec2(0.0f, 0.0f));
    if (!ImGui::ItemAdd(bb, 0))
    {
        if (window->DC.CurrentColumns)
        {
            ImGui::PushColumnClipRect(0);
        }

        return;
    }

    window->DrawList->AddRectFilledMultiColor(
        ImVec2(bb.Min.x + 2, bb.Min.y),
        ImVec2(bb.Max.x - 2, bb.Max.y),
        ImColor(255, 0, 0),
        ImColor(255, 0, 0),
        ImColor(255, 0, 0),
        ImColor(255, 0, 0)
    );

    if (window->DC.CurrentColumns)
    {
        ImGui::PushColumnClipRect(0);
        window->DC.CurrentColumns->LineMinY = window->DC.CursorPos.y;
    }
}

void custom::begin_child(const char* name, ImVec2 size)
{
    ImGuiContext& g = *GImGui;
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    ImVec2 pos = window->DC.CursorPos;

    ImGui::PushStyleColor(ImGuiCol_ChildBg, IM_COL32(0, 0, 0, 0));
    ImGui::BeginChild(std::string(name).append(".main").c_str(), size, true);

    ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(155, 155, 155, 255));
    float text_width = ImGui::CalcTextSize(name).x;
    float avail_width = ImGui::GetWindowSize().x;
    ImVec2 winpos = ImGui::GetWindowPos();
    ImVec2 winsize = ImGui::GetWindowSize();
    ImGui::SetCursorPosX((avail_width - text_width) / 2);
    ImGui::Text(name);
    ImGui::PopStyleColor();
    custom::gradient_seperator();
    ImGui::Dummy(ImVec2(0, 2.0f));
}

void custom::end_child()
{
    ImGui::EndChild();
    ImGui::PopStyleColor();
}