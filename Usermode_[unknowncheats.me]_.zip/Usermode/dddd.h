#pragma once
#include <Windows.h>
#include "Imgui/imgui.h"

namespace c {


    inline ImVec4 cyrcle_color_active = ImColor(0, 0, 139, 255);
    inline ImVec4 cyrcle_color_inactive = ImColor(58, 58, 58, 255);
    inline ImVec4 button_active = ImColor(0, 0, 139, 255);
    inline ImVec4 button_inactive = ImColor(58, 58, 58, 64);
    inline ImVec4 text_active = ImColor(255, 255, 255, 255);
    inline ImVec4 text_inactive = ImColor(128, 128, 128, 255);
    inline ImVec4 text_begin = ImColor(221, 221, 221);
    inline ImVec4 begin = ImColor(11, 12, 13, 127);
    inline ImVec4 colorpicker = ImColor(11, 12, 13, 255);
    inline ImVec4 colorpicker1 = ImColor(17, 17, 17, 255);
}
