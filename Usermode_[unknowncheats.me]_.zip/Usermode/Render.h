﻿#pragma once
#include "Icons.h"

void CreateTextureFromMemory(
	ID3D11Device* device,
	ID3D11DeviceContext* context,
	const void* imageData,
	size_t imageDataSize,
	UINT width,
	UINT height,
	DXGI_FORMAT format,
	ID3D11ShaderResourceView** textureView
) {
	D3D11_TEXTURE2D_DESC textureDesc = {};
	textureDesc.Width = width;
	textureDesc.Height = height;
	textureDesc.MipLevels = 1;
	textureDesc.ArraySize = 1;
	textureDesc.Format = format;
	textureDesc.SampleDesc.Count = 1;
	textureDesc.Usage = D3D11_USAGE_DEFAULT;
	textureDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
	D3D11_SUBRESOURCE_DATA initData = {};
	initData.pSysMem = imageData;
	initData.SysMemPitch = static_cast<UINT>(width * 4);
	ID3D11Texture2D* texture = nullptr;
	HRESULT hr = device->CreateTexture2D(&textureDesc, &initData, &texture);
	if (FAILED(hr)) {
		return;
	}
	D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
	srvDesc.Format = format;
	srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
	srvDesc.Texture2D.MipLevels = 1;

	hr = device->CreateShaderResourceView(texture, &srvDesc, textureView);
	texture->Release();
	if (FAILED(hr)) {
		return;
	}
}

namespace Overlay {
	class COverlay {
	public:

		BOOL DirectXSetup() {
			DXGI_SWAP_CHAIN_DESC swap_chain_description;
			ZeroMemory(&swap_chain_description, sizeof(swap_chain_description));
			swap_chain_description.BufferCount = 2;
			swap_chain_description.BufferDesc.Width = 0;
			swap_chain_description.BufferDesc.Height = 0;
			swap_chain_description.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
			swap_chain_description.BufferDesc.RefreshRate.Numerator = 60;
			swap_chain_description.BufferDesc.RefreshRate.Denominator = 1;
			swap_chain_description.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
			swap_chain_description.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
			swap_chain_description.OutputWindow = MyWnd;
			swap_chain_description.SampleDesc.Count = 1;
			swap_chain_description.SampleDesc.Quality = 0;
			swap_chain_description.Windowed = 1;
			swap_chain_description.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
			DWM_BLURBEHIND bb = { 0 };
			bb.dwFlags = DWM_BB_ENABLE;
			bb.fEnable = TRUE;
			bb.hRgnBlur = NULL;
			DwmEnableBlurBehindWindow(MyWnd, &bb);

			D3D_FEATURE_LEVEL d3d_feature_lvl;

			const D3D_FEATURE_LEVEL d3d_feature_array[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0, };

			D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, 0, d3d_feature_array, 2, D3D11_SDK_VERSION, &swap_chain_description, &g_pSwapChain, &g_pd3dDevice, &d3d_feature_lvl, &g_pd3dDeviceContext);

			ID3D11Texture2D* pBackBuffer;
			D3DX11_IMAGE_LOAD_INFO info;
			ID3DX11ThreadPump* pump{ nullptr };

			g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));

			g_pd3dDevice->CreateRenderTargetView(pBackBuffer, NULL, &g_mainRenderTargetView);

			pBackBuffer->Release();

			IMGUI_CHECKVERSION();
			ImGui::CreateContext();
			ImGuiIO& io = ImGui::GetIO(); (void)io;
			io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
			io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;

			ImGui_ImplWin32_Init(MyWnd);
			ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

			ImFontConfig font_config;
			font_config.OversampleH = 1;
			font_config.OversampleV = 1;
			font_config.PixelSnapH = 1;

			static const ImWchar ranges[] =
			{
				0x0020, 0x00FF,
				0x0400, 0x044F,
				0,
			};

			MenuFont = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\arial.ttf", 14.0f);
			ESPFont = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\arial.ttf", 14.0f);
			BigFont = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\arial.ttf", BigFontSize);
			GaGui::CustomControls::icons = io.Fonts->AddFontFromMemoryTTF(&iconshxd, sizeof iconshxd, 20, NULL, io.Fonts->GetGlyphRangesCyrillic());

			ZeroMemory(&info, sizeof(D3DX11_IMAGE_LOAD_INFO));
			info.Usage = D3D11_USAGE_DEFAULT;
			info.BindFlags = D3D11_BIND_SHADER_RESOURCE;
			info.CpuAccessFlags = 0;
			info.Format = DXGI_FORMAT_FROM_FILE;
			info.MipLevels = D3DX11_DEFAULT;

			ImGui_ImplWin32_Init(MyWnd);

			ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

			g_pd3dDevice->Release();

			return true;
		}

		BOOL SetupWindow()
		{
			WNDCLASSEXA wcex = {
			sizeof(WNDCLASSEXA),
			0,
			DefWindowProcA,
			0,
			0,
			nullptr,
			LoadIcon(nullptr, IDI_APPLICATION),
			LoadCursor(nullptr, IDC_ARROW),
			nullptr,
			nullptr,
			("Microsoft Compatibility Telemetry"),
			LoadIcon(nullptr, IDI_APPLICATION)
			}; RegisterClassExA(&wcex);

			MyWnd = SpoofCall->CreateWindowExA(NULL, ("Microsoft Compatibility Telemetry"), (" "), WS_POPUP, 0, 0, HUD_Info::Width, HUD_Info::Height, NULL, NULL, wcex.hInstance, NULL);
			if (!MyWnd)
				return false;
			SpoofCall->SetWindowLongA(MyWnd, GWL_EXSTYLE, WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_LAYERED);

			MARGINS margin = { -5 };
			SpoofCall->DwmExtendFrameIntoClientArea(MyWnd, &margin);
			SpoofCall->ShowWindow(MyWnd, SW_SHOW);
			SpoofCall->SetWindowPos(MyWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
			SpoofCall->SetLayeredWindowAttributes(MyWnd, RGB(0, 0, 0), 255, LWA_ALPHA);
			SpoofCall->UpdateWindow(MyWnd);
			/*while (!MyWnd) {
				MyWnd = SetUp::HiJackwinverWindow();
				Sleep(10);
			}
			MARGINS margin = { -5 };
			SpoofCall->DwmExtendFrameIntoClientArea(MyWnd, &margin);
			SetMenu(MyWnd, NULL);
			SpoofCall->SetWindowLongA(MyWnd, GWL_STYLE, WS_VISIBLE);
			SpoofCall->SetWindowLongA(MyWnd, GWL_EXSTYLE, WS_EX_LAYERED | WS_EX_TRANSPARENT);
			SpoofCall->ShowWindow(MyWnd, SW_SHOW);
			SpoofCall->UpdateWindow(MyWnd);
			SpoofCall->SetWindowLongA(MyWnd, GWL_EXSTYLE, SpoofCall->GetWindowLongA(MyWnd, GWL_EXSTYLE) | WS_EX_LAYERED | WS_EX_TRANSPARENT);
			SetWindowLong(MyWnd, GWL_EXSTYLE, GetWindowLong(MyWnd, GWL_EXSTYLE) | WS_EX_NOREDIRECTIONBITMAP);
			SpoofCall->SetWindowDisplayAffinity(MyWnd, WDA_EXCLUDEFROMCAPTURE);*/
			return true;
		}

		BOOL MainLoop() {
			static IDXGISwapChain* pSwapChain;
			IDXGISwapChain* pSwaChain = nullptr;
			static RECT rect_og;
			MSG msg = { NULL };
			ZeroMemory(&msg, sizeof(MSG));

			static bool prev_down = false;

			while (msg.message != WM_QUIT)
			{
				SpoofCall->UpdateWindow(MyWnd);
				SpoofCall->ShowWindow(MyWnd, SW_SHOW);

				if (SpoofCall->PeekMessageA(&msg, MyWnd, 0, 0, PM_REMOVE))
				{
					SpoofCall->TranslateMessage(&msg);
					SpoofCall->DispatchMessageA(&msg);
				}

				ImGuiIO& io = ImGui::GetIO();
				io.ImeWindowHandle = MyWnd;
				io.DeltaTime = 1.0f / 60.0f;

				POINT p_cursor;
				SpoofCall->GetCursorPosA(&p_cursor);
				io.MousePos.x = static_cast<float>(p_cursor.x);
				io.MousePos.y = static_cast<float>(p_cursor.y);

				bool curr_down = (Hook->NtUserGetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
				io.MouseDown[0] = curr_down;

				io.MouseClicked[0] = (!prev_down && curr_down);
				if (io.MouseClicked[0]) {
					io.MouseClickedPos[0].x = io.MousePos.x;
					io.MouseClickedPos[0].y = io.MousePos.y;
				}
				prev_down = curr_down;

				render();
			}

			ImGui_ImplDX11_Shutdown();
			ImGui_ImplWin32_Shutdown();
			ImGui::DestroyContext();

			DestroyWindow(MyWnd);
			return true;
		}


		BOOL Setup()
		{
			//std::cout << "[DEBUG] -> SetupWindow()" << std::endl;
			SetupWindow();
			//std::cout << "[DEBUG] -> SetupWindow() done" << std::endl;

			//std::cout << "[DEBUG] -> DirectXSetup()" << std::endl;
			DirectXSetup();
			//std::cout << "[DEBUG] -> DirectXSetup() done" << std::endl;

			//std::cout << "[DEBUG] -> LoadStyle()" << std::endl;
			LoadStyle();
			//std::cout << "[DEBUG] -> LoadStyle() done" << std::endl;

			//std::cout << "[+] MainLoop " << std::endl;
			MainLoop();
			//std::cout << "[+] MainLoop Go " << std::endl;

			return true;
		}
	};

} inline Overlay::COverlay* Rendering = new Overlay::COverlay();