#ifndef DRIVER_HPP
#define DRIVER_HPP
#define device_name "\\\\.\\{StarTechRepair}"

constexpr auto mm_copy_memory_physical = 0x1;
constexpr auto mm_copy_memory_virtual = 0x2;

struct IO_STATUS_BLOCK {
	union {
		NTSTATUS Status;
		PVOID Pointer;
	};
	ULONG_PTR Information;
};

using PIO_STATUS_BLOCK = IO_STATUS_BLOCK*;
using PIO_APC_ROUTINE = void(NTAPI*)(
	PVOID,
	PIO_STATUS_BLOCK,
	std::uint32_t);

extern "C" __int64 direct_device_control(
	HANDLE FileHandle,
	HANDLE Event,
	PIO_APC_ROUTINE ApcRoutine,
	PVOID ApcContext,
	PIO_STATUS_BLOCK IoStatusBlock,
	std::uint32_t IoControlCode,
	PVOID InputBuffer,
	std::uint32_t InputBufferLength,
	PVOID OutputBuffer,
	std::uint32_t OutputBufferLength);

namespace Kernel
{
	class Communications
	{

		typedef enum _requests
		{
			invoke_start,
			invoke_base,
			invoke_read,
			invoke_write,
			invoke_success,
			invoke_unique,
			invoke_translate,
			invoke_read_kernel,
			invoke_cr3,
			invoke_peb,
			invoke_protect_virtual

		}requests, * prequests;

		typedef struct _read_invoke {
			uint32_t pid;
			uintptr_t address;
			uintptr_t dtb;
			void* buffer;
			size_t size;
		} read_invoke, * pread_invoke;

		typedef struct _write_invoke {
			uint32_t pid;
			uintptr_t address;
			void* buffer;
			size_t size;
		} write_invoke, * pwrite_invoke;

		typedef struct _base_invoke {
			uint32_t pid;
			uintptr_t handle;
			const char* name;
			size_t size;
		} base_invoke, * pbase_invoke;

		typedef struct _allocate_invoke {
			uintptr_t address;
			SIZE_T dwSize;
			DWORD flAllocationType;
		} allocate_invoke, * palloc_invoke;

		typedef struct _read_kernel_invoke {
			uintptr_t address;
			void* buffer;
			size_t size;
			uint32_t memory_type;
		} read_kernel_invoke, * pread_kernel_invoke;

		typedef struct _translate_invoke {
			uintptr_t virtual_address;
			uintptr_t directory_base;
			void* physical_address;
		} translate_invoke, * ptranslate_invoke;

		typedef struct _dtb_invoke {
			uint32_t pid;
			uintptr_t dtb;
		} dtb_invoke, * pdtb_invoke;

		typedef struct _invoke_peb
		{
			uint32_t pid;
			uintptr_t peb;
		}pidinvoke_peb, * pinvoke_peb;

		typedef struct _invoke_data
		{
			uint32_t unique;
			requests code;
			void* data;
		}invoke_data, * pinvoke_data;

		std::int32_t Pid = 0;
		void* Handle = 0;

	public:

		std::uintptr_t image_base = 0;
		std::uintptr_t dtb = 0;

		[[nodiscard]] BOOL SendToKernel(void* data, requests code);
		[[nodiscard]] BOOL Setup();
		[[nodiscard]] BOOL AttachToProcess(int a_pid);
		[[nodiscard]] BOOL VirtualProtect(const std::uintptr_t address, const size_t size, const DWORD allocation_type);
		[[nodiscard]] const std::uint32_t GetPIDForProcess(const std::wstring& proc_name);
		[[nodiscard]] const std::uintptr_t SetupCr3();
		[[nodiscard]] const std::uintptr_t GetImageBase(const char* module_name);
		[[nodiscord]] const std::uintptr_t GetProcessPeb();

		[[nodiscard]] BOOL ReadKernelAddress(const uintptr_t address, void* buffer, const size_t size, const uint32_t memory_type);
		[[nodiscard]] BOOL ReadVirtualAddress(const uintptr_t address, void* buffer, const size_t size);
		[[nodiscard]] bool WriteVirtualAddress(const std::uintptr_t address, void* buffer, const std::size_t size);

		template <typename T>
		[[nodiscard]] bool Write(const uintptr_t address, T value)
		{
			return WriteVirtualAddress(address, &value, sizeof(T));
		}

		template <typename T>
		[[nodiscard]] T Read(const uintptr_t address)
		{
			T response{};
			ReadVirtualAddress(address, &response, sizeof(T));
			return response;
		}

		template <typename T>
		[[nodiscard]] BOOL ReadPhysicalAddress(const uintptr_t address, T buffer, size_t size)
		{
			return ReadVirtualAddress(address, buffer, size);
		}

		static bool IsValidPointer(const uint64_t adress)
		{
			if (adress <= 0x400000 || adress == 0xCCCCCCCCCCCCCCCC || reinterpret_cast<void*>(adress) == nullptr || adress >
				0x7FFFFFFFFFFFFFFF) {
				return false;
			}
			return true;
		}

	};
}

static Kernel::Communications* Memory = new Kernel::Communications();

#endif // ! DRIVER_HPP