﻿#pragma once
#include "input_controls.h"

namespace Addresses {
	static uintptr_t LocalPlayer = 0;

	static uintptr_t base = 0;
	static uintptr_t Peb = 0;
}

namespace HUD_Info
{
	static int Width = GetSystemMetrics(SM_CXSCREEN);
	static int Height = GetSystemMetrics(SM_CYSCREEN);
}

#define GAMEPAD_LEFT_TRIGGER  0x1000
#define GAMEPAD_RIGHT_TRIGGER 0x2000

namespace Settings
{


	inline bool RadarBackgroundTransparent = false;  
	inline float RadarBackgroundColor[4] = { 0.2f, 0.2f, 0.2f, 0.8f }; 
	inline float RadarEnemyVisibleColor[4] = { 1.0f, 0.0f, 0.0f, 1.0f };
	inline float RadarEnemyHiddenColor[4] = { 1.0f, 1.0f, 0.0f, 1.0f }; 
    static float VisibleColor[4] = { 1.0f, 0.0f, 0.0f, 1.0f }; 
	static float NotVisibleColor[4] = { 1.0f, 1.0f, 0.0f, 1.0f }; 
	static float fovCircleColor[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
	inline bool vsync = true;
	inline bool show_fps = false;
	inline bool gay_mode = false;
	inline bool PredictionEnabled = true;
	inline float ProjectileSpeed = 2402.f;
	inline float Gravity = 5.f;
	inline bool VerticalFix = true;
	inline bool ShowBotTag = false;
	bool AimbotPrediction = true;
	bool CompassESP = true;
	bool HumanizedAim = true;
	float BulletSpeed = 1500.0f;
	inline float StickSensitivity = 0.05f;
	inline bool ShowCompass = true;
	inline int DeadZone = 5000;
	inline bool UseGamepad = true;
	inline int GamepadButton = GAMEPAD_RIGHT_TRIGGER;
	static bool Enable = 1;
	static int LockedTargetIndex = -1;
	inline bool UseControllerAimKey = false;
	inline bool AimbotToggle = true;
	inline int ControllerAimButton = 0;
	inline bool UseControllerInput = false;
	static bool Aimbot = 1;
	static bool AutoShoot = 1;
	static bool Memory = 0;
	static bool waiting_for_key = false;

	static bool Silent = 0;
	static bool Humanization = 0;
	static bool Targetline = 0;
	static int FovCircle_Value = 130;
	static int Smoothness = 5;
	static int AimBone_Selector = 1;
	static int Aimbone = 8;
	static int Aimkey = VK_RBUTTON;
	static int MaxAimbotDistance = 100;

	static bool Box = 1;
	static bool Skeleton = 1;
	static bool Nicknames = 0;
	static bool Ping = 0;

	static bool Operator = 0;
	static bool Health = 0;
	static bool Shield = 0;
	static bool Weapon = 0;
	static bool Snaplines = 1;
	static bool Distance = 1;
	static bool Glow = 0;
	static bool GlowVisibleOnly = 0;
	static int GlowIntensity = 0;
	static int MaxEspDistance = 300;

	static bool Loot = 1;
	static bool Deathbox = 0;
	static bool Containers = 0;
	static bool Ziplines = 0;
	static bool Vehicles = 0;
	static bool LootGlow = 0;
	static bool DeathboxGlow = 0;
	static bool Debug = 0;
	static int MaxWorldDistance = 10;

	static bool NoRecoil = 0;

	inline bool Radar = 1;
	inline float RadarSize = 340.0f;
	inline float RadarRange = 100.0f;
	inline float RadarAlpha = 0.6f;
	inline float RadarPointSize = 6.5f;
	inline float RadarZoom = 0.5f;
	inline ImVec2 RadarPosition = ImVec2(25, 20);
	static bool FOVArrows = 0;
	static float ArrowRadius = 300;
	inline bool EnemyInsideFov = true;

	static bool ShowFOVCircle = 0;
	static bool ShowCrosshair = 1;
	static bool ShowSpectators = 1;
	static bool Indicators = 1;
	static bool IgnoreDowned = 0;
	static bool VisibleCheck = 0;
	static bool StreamProof = 0;
	static bool VSYC = 0;
}

int counter = 0;
const char* ControllerAimButton[] = { "LT", "RT", "LB", "RB", "A", "X" };

const char* Bones_Array[] = { ("Head"), ("Neck"), ("Chest"), ("Pelvis") };

namespace Keys
{
	static int LeftMouseButton = 0x01;
	static int RightMouseButton = 0x02;
	static int LSpace = 0x10;
	static int Control = 0x11;
	static int Space = 0x20;
	static int Backspace = 0x08;
	static int Tab = 0x09;
	static int CapsLock = 0x14;
	static int Return = 0x0D;
	static int Insert = 0x2D;
	static int Delete = 0x2E;
	static int F1 = 0x70;
	static int F2 = 0x71;
	static int F3 = 0x72;
	static int F4 = 0x73;
	static int F5 = 0x74;
	static int F6 = 0x75;
	static int F7 = 0x76;
	static int F8 = 0x77;
	static int F9 = 0x78;
	static int F10 = 0x79;
	static int F11 = 0x7A;
	static int F12 = 0x7B;
}

namespace Bones {
	static bool Head = 0;
	static bool Neck = 1;
	static bool Chest = 0;
}
#include <fstream>     
#include <sstream>    
#include <string>    
#include <iostream>  

inline void SaveConfig(const std::string& filename = "config.txt")
{
	std::ofstream file(filename);
	if (!file.is_open()) return;

#define SAVE(v) file << Settings::v << "\n"
#define SAVE_COLOR(arr) for (int i = 0; i < 4; ++i) file << Settings::arr[i] << " "; file << "\n"

	SAVE(ShowCompass);
	SAVE(FovCircle_Value);
	SAVE(Smoothness);
	SAVE(AimBone_Selector);
	SAVE(Aimbone);
	SAVE(Aimkey);
	SAVE(MaxAimbotDistance);
	SAVE(StickSensitivity);
	SAVE(DeadZone);
	SAVE(GamepadButton);
	SAVE(Enable);
	SAVE(Aimbot);
	SAVE(AutoShoot);
	SAVE(Memory);
	SAVE(Silent);
	SAVE(Humanization);
	SAVE(Targetline);
	SAVE(Box);
	SAVE(Skeleton);
	SAVE(Nicknames);
	SAVE(Ping);
	SAVE(Operator);
	SAVE(Health);
	SAVE(Shield);
	SAVE(Weapon);
	SAVE(Snaplines);
	SAVE(Distance);
	SAVE(Glow);
	SAVE(GlowVisibleOnly);
	SAVE(GlowIntensity);
	SAVE(MaxEspDistance);
	SAVE(Loot);
	SAVE(Deathbox);
	SAVE(Containers);
	SAVE(Ziplines);
	SAVE(Vehicles);
	SAVE(LootGlow);
	SAVE(DeathboxGlow);
	SAVE(Debug);
	SAVE(MaxWorldDistance);
	SAVE(NoRecoil);
	SAVE(Radar);
	SAVE(RadarSize);
	SAVE(RadarRange);
	SAVE(RadarAlpha);
	SAVE(RadarPointSize);
	SAVE(RadarZoom);
	file << Settings::RadarPosition.x << " " << Settings::RadarPosition.y << "\n";
	SAVE(FOVArrows);
	SAVE(ArrowRadius);
	SAVE(ShowFOVCircle);
	SAVE(ShowCrosshair);
	SAVE(ShowSpectators);
	SAVE(Indicators);
	SAVE(IgnoreDowned);
	SAVE(VisibleCheck);
	SAVE(StreamProof);
	SAVE(VSYC);
	SAVE(UseControllerInput);
	SAVE(UseControllerAimKey);
	SAVE(ControllerAimButton);
	SAVE(AimbotToggle);
	SAVE(CompassESP);
	SAVE(AimbotPrediction);
	SAVE(HumanizedAim);
	SAVE(BulletSpeed);
	SAVE(PredictionEnabled);
	SAVE(ProjectileSpeed);
	SAVE(Gravity);
	SAVE(VerticalFix);
	SAVE(ShowBotTag);
	SAVE_COLOR(VisibleColor);
	SAVE_COLOR(NotVisibleColor);
	SAVE_COLOR(fovCircleColor);
	SAVE_COLOR(RadarBackgroundColor);
	SAVE_COLOR(RadarEnemyVisibleColor);
	SAVE_COLOR(RadarEnemyHiddenColor);
	SAVE(RadarBackgroundTransparent);
	SAVE(vsync);
	SAVE(show_fps);
	SAVE(gay_mode);

#undef SAVE
#undef SAVE_COLOR

	file.close();
}


inline void LoadConfig(const std::string& filename = "config.txt")
{
	std::ifstream file(filename);
	if (!file.is_open()) return;

#define LOAD(v) file >> Settings::v
#define LOAD_COLOR(arr) for (int i = 0; i < 4; ++i) file >> Settings::arr[i]

	LOAD(ShowCompass);
	LOAD(FovCircle_Value);
	LOAD(Smoothness);
	LOAD(AimBone_Selector);
	LOAD(Aimbone);
	LOAD(Aimkey);
	LOAD(MaxAimbotDistance);
	LOAD(StickSensitivity);
	LOAD(DeadZone);
	LOAD(GamepadButton);
	LOAD(Enable);
	LOAD(Aimbot);
	LOAD(AutoShoot);
	LOAD(Memory);
	LOAD(Silent);
	LOAD(Humanization);
	LOAD(Targetline);
	LOAD(Box);
	LOAD(Skeleton);
	LOAD(Nicknames);
	LOAD(Ping);
	LOAD(Operator);
	LOAD(Health);
	LOAD(Shield);
	LOAD(Weapon);
	LOAD(Snaplines);
	LOAD(Distance);
	LOAD(Glow);
	LOAD(GlowVisibleOnly);
	LOAD(GlowIntensity);
	LOAD(MaxEspDistance);
	LOAD(Loot);
	LOAD(Deathbox);
	LOAD(Containers);
	LOAD(Ziplines);
	LOAD(Vehicles);
	LOAD(LootGlow);
	LOAD(DeathboxGlow);
	LOAD(Debug);
	LOAD(MaxWorldDistance);
	LOAD(NoRecoil);
	LOAD(Radar);
	LOAD(RadarSize);
	LOAD(RadarRange);
	LOAD(RadarAlpha);
	LOAD(RadarPointSize);
	LOAD(RadarZoom);
	file >> Settings::RadarPosition.x >> Settings::RadarPosition.y;
	LOAD(FOVArrows);
	LOAD(ArrowRadius);
	LOAD(ShowFOVCircle);
	LOAD(ShowCrosshair);
	LOAD(ShowSpectators);
	LOAD(Indicators);
	LOAD(IgnoreDowned);
	LOAD(VisibleCheck);
	LOAD(StreamProof);
	LOAD(VSYC);
	LOAD(UseControllerInput);
	LOAD(UseControllerAimKey);
	LOAD(ControllerAimButton);
	LOAD(AimbotToggle);
	LOAD(CompassESP);
	LOAD(AimbotPrediction);
	LOAD(HumanizedAim);
	LOAD(BulletSpeed);
	LOAD(PredictionEnabled);
	LOAD(ProjectileSpeed);
	LOAD(Gravity);
	LOAD(VerticalFix);
	LOAD(ShowBotTag);
	LOAD_COLOR(VisibleColor);
	LOAD_COLOR(NotVisibleColor);
	LOAD_COLOR(fovCircleColor);
	LOAD_COLOR(RadarBackgroundColor);
	LOAD_COLOR(RadarEnemyVisibleColor);
	LOAD_COLOR(RadarEnemyHiddenColor);
	LOAD(RadarBackgroundTransparent);
	LOAD(vsync);
	LOAD(show_fps);
	LOAD(gay_mode);

#undef LOAD
#undef LOAD_COLOR

	file.close();
}

extern unsigned char RobotoData[168260];
extern unsigned char FontBold[31416];
ImFont* MenuFont;
ImFont* ESPFont;