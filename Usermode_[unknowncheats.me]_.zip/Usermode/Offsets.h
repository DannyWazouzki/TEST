﻿#pragma once

namespace Offsets
{
    OFF ref_def_ptr = 0xC9C4128;
    OFF name_array = 0xCB33848;
    OFF name_array_pos = 0x3038;
    OFF scoreboard = 0x12400;
    OFF scoreboard_size = 0x78;
    OFF name_size = 0xC8;
    OFF loot_ptr = 0xE1E0B40;
    OFF loot_pos = 0x170;
    OFF camera_base = 0xC670B10;
    OFF camera_pos = 0x204;
    OFF local_index = 0x96128;
    OFF local_index_pos = 0x364;
    OFF game_mode = 0xB3485F8;
    OFF weapon_definitions = 0xC880A50;
    OFF distribute = 0x105F2458;
    _DWORD visible_bit = 0x181D4;
    OFF recoil = 0xDAD3C;

    namespace Player
    {
        OFF size = 0x2440;
        OFF stance = 0x299;
        OFF valid = 0x21A0;
        OFF pos = 0x2078;
        OFF team = 0x1AB1;
       
    };
    namespace Bone
    {
        OFF bone_base = 0x1674A0;
        OFF size = 0x1B0;
        OFF offset = 0xD8;
    };
   
    namespace Entity
    {
        OFF local_entity = 0x67888;
    };
}

struct RefDef_T {

    int32_t x;
    int32_t y;
    int32_t width;
    int32_t height;
    FVector2D tan_half_fov;
    char pad1[8];  // 8-byte padding
    char pad2[4];  // 4-byte padding
    FVector axis[3];
};
class RefDef_Class {

public:
    struct key {
        int32_t ref0;
        int32_t ref1;
        int32_t ref2;
    };

    auto GetRefDef() -> uintptr_t
    {
        key encrypted = Memory->Read<key>(Addresses::base + Offsets::ref_def_ptr);
        DWORD lowerref = encrypted.ref0 ^ (encrypted.ref2 ^ (uint64_t)(Addresses::base + Offsets::ref_def_ptr)) * ((encrypted.ref2 ^ (uint64_t)(Addresses::base + Offsets::ref_def_ptr)) + 2);
        DWORD upperref = encrypted.ref1 ^ (encrypted.ref2 ^ (uint64_t)(Addresses::base + Offsets::ref_def_ptr + 0x4)) * ((encrypted.ref2 ^ (uint64_t)(Addresses::base + Offsets::ref_def_ptr + 0x4)) + 2); \
            return (uint64_t)upperref << 32 | lowerref;
    }
    RefDef_T ref_def_nn;
};
static RefDef_Class* DecryptRefDef = new RefDef_Class();

inline uintptr_t decrypt_client_info()
{
    const uint64_t mb = Addresses::base;
    uint64_t rax = mb, rbx = mb, rcx = mb, rdx = mb, rdi = mb, rsi = mb, r8 = mb, r9 = mb, r10 = mb, r11 = mb, r12 = mb, r13 = mb, r14 = mb, r15 = mb;
    rdx = Memory->Read<uintptr_t>(Addresses::base + 0xC9BD578);
    if (!rdx)
        return rdx;
    rcx = Addresses::Peb;              //mov rcx, gs:[rax]
    rdx += 0xFFFFFFFFFFFF9357;              //add rdx, 0xFFFFFFFFFFFF9357
    rax = Addresses::base;             //lea rax, [0xFFFFFFFFF9CABA86]
    rcx -= rax;             //sub rcx, rax
    rcx += rdx;             //add rcx, rdx
    rax = rcx;              //mov rax, rcx
    rax >>= 0x1D;           //shr rax, 0x1D
    rcx ^= rax;             //xor rcx, rax
    rdx = rcx;              //mov rdx, rcx
    rax = 0;                //and rax, 0xFFFFFFFFC0000000
    rdx >>= 0x3A;           //shr rdx, 0x3A
    rax = _rotl64(rax, 0x10);               //rol rax, 0x10
    rdx ^= rcx;             //xor rdx, rcx
    rax ^= Memory->Read<uintptr_t>(Addresses::base + 0xB157A5C);                 //xor rax, [0x0000000004E034A6]
    rax = _byteswap_uint64(rax);            //bswap rax
    rdx *= Memory->Read<uintptr_t>(rax + 0x15);               //imul rdx, [rax+0x15]
    rax = 0xD67810518E7F25DD;               //mov rax, 0xD67810518E7F25DD
    rdx *= rax;             //imul rdx, rax
    rax = rdx;              //mov rax, rdx
    rax >>= 0x5;            //shr rax, 0x05
    rdx ^= rax;             //xor rdx, rax
    rax = rdx;              //mov rax, rdx
    rax >>= 0xA;            //shr rax, 0x0A
    rdx ^= rax;             //xor rdx, rax
    rax = rdx;              //mov rax, rdx
    rax >>= 0x14;           //shr rax, 0x14
    rdx ^= rax;             //xor rdx, rax
    rax = rdx;              //mov rax, rdx
    rax >>= 0x28;           //shr rax, 0x28
    rdx ^= rax;             //xor rdx, rax
    return rdx;
}
inline uintptr_t decrypt_client_base(uintptr_t client_info)
{
    const uint64_t mb = Addresses::base;
    uint64_t rax = mb, rbx = mb, rcx = mb, rdx = mb, rdi = mb, rsi = mb, r8 = mb, r9 = mb, r10 = mb, r11 = mb, r12 = mb, r13 = mb, r14 = mb, r15 = mb;
    r8 = Memory->Read<uintptr_t>(client_info + 0x1d8a58);
    if (!r8)
        return r8;
    rbx = ~Addresses::Peb;              //mov rbx, gs:[rax]
    rax = rbx;              //mov rax, rbx
    rax = _rotl64(rax, 0x34);               //rol rax, 0x34
    rax &= 0xF;
    switch (rax) {
    case 0:
    {
        r10 = Memory->Read<uintptr_t>(Addresses::base + 0xB157AC5);          //mov r10, [0x0000000008214737]
        r13 = Addresses::base + 0x16CBED5E;                //lea r13, [0x0000000013D7B9AD]
        rcx = Addresses::base + 0x33D36DEA;                //lea rcx, [0x0000000030DF39DD]
        r8 ^= rbx;              //xor r8, rbx
        r8 ^= rcx;              //xor r8, rcx
        rax = rbx;              //mov rax, rbx
        rax *= r13;             //imul rax, r13
        r8 -= rax;              //sub r8, rax
        rax = 0x2F44AFC8DA410289;               //mov rax, 0x2F44AFC8DA410289
        r8 *= rax;              //imul r8, rax
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r10;             //xor rax, r10
        rax = ~rax;             //not rax
        r8 *= Memory->Read<uintptr_t>(rax + 0x7);                 //imul r8, [rax+0x07]
        rax = 0x31EA6C7327F2F48F;               //mov rax, 0x31EA6C7327F2F48F
        r8 *= rax;              //imul r8, rax
        rax = rbx;              //mov rax, rbx
        rax = ~rax;             //not rax
        uintptr_t RSP_0xFFFFFFFFFFFFFFE0;
        RSP_0xFFFFFFFFFFFFFFE0 = Addresses::base + 0xDD05;                 //lea rax, [0xFFFFFFFFFD0CA970] : RBP+0xFFFFFFFFFFFFFFE0
        rax ^= RSP_0xFFFFFFFFFFFFFFE0;          //xor rax, [rbp-0x20]
        r8 -= rax;              //sub r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0xF;            //shr rax, 0x0F
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x1E;           //shr rax, 0x1E
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x3C;           //shr rax, 0x3C
        r8 ^= rax;              //xor r8, rax
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFFD0BCA27]
        r8 -= rax;              //sub r8, rax
        return r8;
    }
    case 1:
    {
        r9 = Memory->Read<uintptr_t>(Addresses::base + 0xB157AC5);           //mov r9, [0x000000000821426D]
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFFD0BC37C]
        rax += 0x4C577047;              //add rax, 0x4C577047
        rax += rbx;             //add rax, rbx
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x16;           //shr rax, 0x16
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x2C;           //shr rax, 0x2C
        r8 ^= rax;              //xor r8, rax
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFFD0BC480]
        r8 ^= rax;              //xor r8, rax
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFFD0BC546]
        rax += 0x673BCC74;              //add rax, 0x673BCC74
        rax += rbx;             //add rax, rbx
        r8 ^= rax;              //xor r8, rax
        rax = 0x14CEC15D15237845;               //mov rax, 0x14CEC15D15237845
        r8 *= rax;              //imul r8, rax
        rax = 0xC6C8F26557A42C57;               //mov rax, 0xC6C8F26557A42C57
        r8 *= rax;              //imul r8, rax
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r9;              //xor rax, r9
        rax = ~rax;             //not rax
        r8 *= Memory->Read<uintptr_t>(rax + 0x7);                 //imul r8, [rax+0x07]
        return r8;
    }
    case 2:
    {
        r9 = Memory->Read<uintptr_t>(Addresses::base + 0xB157AC5);           //mov r9, [0x0000000008213E0F]
        rax = r8;               //mov rax, r8
        rax >>= 0xC;            //shr rax, 0x0C
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x18;           //shr rax, 0x18
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x30;           //shr rax, 0x30
        r8 ^= rax;              //xor r8, rax
        r8 -= rbx;              //sub r8, rbx
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r9;              //xor rax, r9
        rax = ~rax;             //not rax
        r8 *= Memory->Read<uintptr_t>(rax + 0x7);                 //imul r8, [rax+0x07]
        rax = Addresses::base + 0x40BA9587;                //lea rax, [0x000000003DC6577F]
        r8 += rbx;              //add r8, rbx
        r8 += rax;              //add r8, rax
        rax = 0xB820512AEEAE20F1;               //mov rax, 0xB820512AEEAE20F1
        r8 *= rax;              //imul r8, rax
        rax = 0x5B4702F448FEE148;               //mov rax, 0x5B4702F448FEE148
        r8 ^= rax;              //xor r8, rax
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFFD0BC1D0]
        r8 += rax;              //add r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x12;           //shr rax, 0x12
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x24;           //shr rax, 0x24
        r8 ^= rax;              //xor r8, rax
        return r8;
    }
    case 3:
    {
        r10 = Memory->Read<uintptr_t>(Addresses::base + 0xB157AC5);          //mov r10, [0x00000000082138E0]
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFFD0BBB3F]
        r8 -= rax;              //sub r8, rax
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFFD0BB9C1]
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x13;           //shr rax, 0x13
        r8 ^= rax;              //xor r8, rax
        rcx = 0;                //and rcx, 0xFFFFFFFFC0000000
        rcx = _rotl64(rcx, 0x10);               //rol rcx, 0x10
        rax = r8;               //mov rax, r8
        rcx ^= r10;             //xor rcx, r10
        rax >>= 0x26;           //shr rax, 0x26
        rcx = ~rcx;             //not rcx
        r8 ^= rax;              //xor r8, rax
        r8 *= Memory->Read<uintptr_t>(rcx + 0x7);                 //imul r8, [rcx+0x07]
        rax = rbx;              //mov rax, rbx
        rax = ~rax;             //not rax
        uintptr_t RSP_0xFFFFFFFFFFFFFFC0;
        RSP_0xFFFFFFFFFFFFFFC0 = Addresses::base + 0x639AA956;             //lea rax, [0x0000000060A66727] : RBP+0xFFFFFFFFFFFFFFC0
        rax += RSP_0xFFFFFFFFFFFFFFC0;          //add rax, [rbp-0x40]
        r8 ^= rax;              //xor r8, rax
        rax = 0xEF7AA6541B0960DD;               //mov rax, 0xEF7AA6541B0960DD
        r8 ^= rax;              //xor r8, rax
        rax = 0xAC44478E4E7E319F;               //mov rax, 0xAC44478E4E7E319F
        r8 *= rax;              //imul r8, rax
        rax = 0x69DF0E377EDBC9BB;               //mov rax, 0x69DF0E377EDBC9BB
        r8 ^= rax;              //xor r8, rax
        return r8;
    }
    case 4:
    {
        r9 = Memory->Read<uintptr_t>(Addresses::base + 0xB157AC5);           //mov r9, [0x0000000008213477]
        rax = 0x6B6B6FEB24A18CBC;               //mov rax, 0x6B6B6FEB24A18CBC
        r8 ^= rax;              //xor r8, rax
        rax = 0xE26425F12DE4CEB;                //mov rax, 0xE26425F12DE4CEB
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x15;           //shr rax, 0x15
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x2A;           //shr rax, 0x2A
        r8 ^= rax;              //xor r8, rax
        r8 += rbx;              //add r8, rbx
        rax = 0xC6BD746DB1DF1B31;               //mov rax, 0xC6BD746DB1DF1B31
        r8 *= rax;              //imul r8, rax
        r8 -= Addresses::base;             //sub r8, [rbp-0x08] -- didn't find trace -> use Addresses::base
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r9;              //xor rax, r9
        rax = ~rax;             //not rax
        r8 *= Memory->Read<uintptr_t>(rax + 0x7);                 //imul r8, [rax+0x07]
        rax = r8;               //mov rax, r8
        rax >>= 0x1;            //shr rax, 0x01
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x2;            //shr rax, 0x02
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x4;            //shr rax, 0x04
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x8;            //shr rax, 0x08
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x10;           //shr rax, 0x10
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x20;           //shr rax, 0x20
        r8 ^= rax;              //xor r8, rax
        return r8;
    }
    case 5:
    {
        r10 = Memory->Read<uintptr_t>(Addresses::base + 0xB157AC5);          //mov r10, [0x0000000008212D88]
        rcx = 0;                //and rcx, 0xFFFFFFFFC0000000
        rax = rbx * 0xFFFFFFFFFFFFFFFE;                 //imul rax, rbx, 0xFFFFFFFFFFFFFFFE
        rcx = _rotl64(rcx, 0x10);               //rol rcx, 0x10
        r8 += rax;              //add r8, rax
        rcx ^= r10;             //xor rcx, r10
        rax = Addresses::base + 0x5F737FAA;                //lea rax, [0x000000005C7F2FEF]
        rcx = ~rcx;             //not rcx
        r8 += rax;              //add r8, rax
        r8 *= Memory->Read<uintptr_t>(rcx + 0x7);                 //imul r8, [rcx+0x07]
        rax = r8;               //mov rax, r8
        rax >>= 0x19;           //shr rax, 0x19
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x32;           //shr rax, 0x32
        r8 ^= rax;              //xor r8, rax
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFFD0BAED1]
        rax += 0x6987CC3C;              //add rax, 0x6987CC3C
        rax += rbx;             //add rax, rbx
        r8 += rax;              //add r8, rax
        rax = 0xBEC2B746A9461603;               //mov rax, 0xBEC2B746A9461603
        r8 *= rax;              //imul r8, rax
        rax = 0x7D25D991052F24B5;               //mov rax, 0x7D25D991052F24B5
        r8 += rax;              //add r8, rax
        rax = 0x6B9AD86F193C7172;               //mov rax, 0x6B9AD86F193C7172
        r8 += rax;              //add r8, rax
        return r8;
    }
    case 6:
    {
        r10 = Memory->Read<uintptr_t>(Addresses::base + 0xB157AC5);          //mov r10, [0x0000000008212935]
        rcx = Addresses::base + 0x50AF1F4F;                //lea rcx, [0x000000004DBACD3E]
        r8 += rbx;              //add r8, rbx
        rax = rbx;              //mov rax, rbx
        rax ^= rcx;             //xor rax, rcx
        r8 -= rax;              //sub r8, rax
        rax = 0xFA37AFACEF63040B;               //mov rax, 0xFA37AFACEF63040B
        r8 ^= rax;              //xor r8, rax
        rax = 0xE15A50F0F0B4D5D9;               //mov rax, 0xE15A50F0F0B4D5D9
        r8 *= rax;              //imul r8, rax
        rcx = 0;                //and rcx, 0xFFFFFFFFC0000000
        rax = Addresses::base + 0xEE8B;            //lea rax, [0xFFFFFFFFFD0C98EE]
        rcx = _rotl64(rcx, 0x10);               //rol rcx, 0x10
        rax -= rbx;             //sub rax, rbx
        r8 ^= rax;              //xor r8, rax
        rcx ^= r10;             //xor rcx, r10
        rcx = ~rcx;             //not rcx
        r8 *= Memory->Read<uintptr_t>(rcx + 0x7);                 //imul r8, [rcx+0x07]
        rax = 0x61E687AD8B6807D4;               //mov rax, 0x61E687AD8B6807D4
        r8 += rax;              //add r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x15;           //shr rax, 0x15
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x2A;           //shr rax, 0x2A
        r8 ^= rax;              //xor r8, rax
        return r8;
    }
    case 7:
    {
        r10 = Memory->Read<uintptr_t>(Addresses::base + 0xB157AC5);          //mov r10, [0x0000000008212433]
        r13 = Addresses::base + 0xBEE4;            //lea r13, [0xFFFFFFFFFD0C683A]
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFFD0BA60A]
        r8 ^= rax;              //xor r8, rax
        rax = 0x8DB3E6B3BD449D8;                //mov rax, 0x8DB3E6B3BD449D8
        r8 += rax;              //add r8, rax
        rax = 0x7CFD8CC5318E532F;               //mov rax, 0x7CFD8CC5318E532F
        r8 *= rax;              //imul r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x7;            //shr rax, 0x07
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0xE;            //shr rax, 0x0E
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x1C;           //shr rax, 0x1C
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x38;           //shr rax, 0x38
        r8 ^= rax;              //xor r8, rax
        rcx = 0;                //and rcx, 0xFFFFFFFFC0000000
        rcx = _rotl64(rcx, 0x10);               //rol rcx, 0x10
        rax = 0x6DE6E637B4DB68F1;               //mov rax, 0x6DE6E637B4DB68F1
        rcx ^= r10;             //xor rcx, r10
        rcx = ~rcx;             //not rcx
        r8 *= Memory->Read<uintptr_t>(rcx + 0x7);                 //imul r8, [rcx+0x07]
        r8 *= rax;              //imul r8, rax
        rax = rbx;              //mov rax, rbx
        rax -= r13;             //sub rax, r13
        r8 ^= rax;              //xor r8, rax
        r8 -= rbx;              //sub r8, rbx
        return r8;
    }
    case 8:
    {
        r9 = Memory->Read<uintptr_t>(Addresses::base + 0xB157AC5);           //mov r9, [0x0000000008212001]
        rax = r8;               //mov rax, r8
        rax >>= 0x1E;           //shr rax, 0x1E
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x3C;           //shr rax, 0x3C
        r8 ^= rax;              //xor r8, rax
        rax = 0xD16E8EE163C9A6B;                //mov rax, 0xD16E8EE163C9A6B
        r8 *= rax;              //imul r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0xE;            //shr rax, 0x0E
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x1C;           //shr rax, 0x1C
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x38;           //shr rax, 0x38
        r8 ^= rax;              //xor r8, rax
        rax = 0xA9C58221B90E7C46;               //mov rax, 0xA9C58221B90E7C46
        r8 ^= rax;              //xor r8, rax
        rax = 0x55F6ED3AB42B87A0;               //mov rax, 0x55F6ED3AB42B87A0
        r8 -= rax;              //sub r8, rax
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r9;              //xor rax, r9
        rax = ~rax;             //not rax
        r8 *= Memory->Read<uintptr_t>(rax + 0x7);                 //imul r8, [rax+0x07]
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFFD0BA076]
        r8 += rax;              //add r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x14;           //shr rax, 0x14
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x28;           //shr rax, 0x28
        r8 ^= rax;              //xor r8, rax
        return r8;
    }
    case 9:
    {
        r10 = Memory->Read<uintptr_t>(Addresses::base + 0xB157AC5);          //mov r10, [0x0000000008211963]
        rcx = rbx;              //mov rcx, rbx
        rax = Addresses::base + 0xFCE2;            //lea rax, [0xFFFFFFFFFD0C99D7]
        rcx *= rax;             //imul rcx, rax
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFFD0B9CEA]
        rcx -= rax;             //sub rcx, rax
        rax = rbx;              //mov rax, rbx
        r8 += rcx;              //add r8, rcx
        rax = ~rax;             //not rax
        r8 ^= rax;              //xor r8, rax
        rcx = Addresses::base + 0x6EC75C18;                //lea rcx, [0x000000006BD2F8EC]
        r8 ^= rcx;              //xor r8, rcx
        rax = r8;               //mov rax, r8
        rax >>= 0x7;            //shr rax, 0x07
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0xE;            //shr rax, 0x0E
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x1C;           //shr rax, 0x1C
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x38;           //shr rax, 0x38
        r8 ^= rax;              //xor r8, rax
        r13 = 0xB691FFD9C9D61B2E;               //mov r13, 0xB691FFD9C9D61B2E
        r8 += r13;              //add r8, r13
        r13 = 0x89C1B16D1EAC4B85;               //mov r13, 0x89C1B16D1EAC4B85
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        r8 ^= r13;              //xor r8, r13
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r10;             //xor rax, r10
        rax = ~rax;             //not rax
        r8 *= Memory->Read<uintptr_t>(rax + 0x7);                 //imul r8, [rax+0x07]
        rax = 0x272542A0099256AB;               //mov rax, 0x272542A0099256AB
        r8 *= rax;              //imul r8, rax
        return r8;
    }
    case 10:
    {
        r10 = Memory->Read<uintptr_t>(Addresses::base + 0xB157AC5);          //mov r10, [0x0000000008211450]
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFFD0B9824]
        rax += 0x240D8AB0;              //add rax, 0x240D8AB0
        rax += rbx;             //add rax, rbx
        r8 ^= rax;              //xor r8, rax
        rcx = rbx;              //mov rcx, rbx
        rax = Addresses::base + 0x3B21;            //lea rax, [0xFFFFFFFFFD0BD0EA]
        rcx *= rax;             //imul rcx, rax
        rax = rbx;              //mov rax, rbx
        rcx += r8;              //add rcx, r8
        rax = ~rax;             //not rax
        r8 = Addresses::base + 0x24E689C1;                 //lea r8, [0x0000000021F21F76]
        rax += r8;              //add rax, r8
        r8 = rcx;               //mov r8, rcx
        r8 ^= rax;              //xor r8, rax
        rax = 0x489A1BC87CDCD670;               //mov rax, 0x489A1BC87CDCD670
        r8 ^= rax;              //xor r8, rax
        rax = 0xA00242052F60AE53;               //mov rax, 0xA00242052F60AE53
        r8 ^= rax;              //xor r8, rax
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r10;             //xor rax, r10
        rax = ~rax;             //not rax
        r8 *= Memory->Read<uintptr_t>(rax + 0x7);                 //imul r8, [rax+0x07]
        rax = 0xBDB64B81FECB6E7D;               //mov rax, 0xBDB64B81FECB6E7D
        r8 *= rax;              //imul r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x28;           //shr rax, 0x28
        r8 ^= rax;              //xor r8, rax
        return r8;
    }
    case 11:
    {
        r10 = Memory->Read<uintptr_t>(Addresses::base + 0xB157AC5);          //mov r10, [0x0000000008210F6C]
        rax = r8;               //mov rax, r8
        rax >>= 0x15;           //shr rax, 0x15
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x2A;           //shr rax, 0x2A
        r8 ^= rax;              //xor r8, rax
        rax = 0xD3A53D9499733245;               //mov rax, 0xD3A53D9499733245
        r8 *= rax;              //imul r8, rax
        rax = 0x72C2AC821062ABD1;               //mov rax, 0x72C2AC821062ABD1
        r8 ^= rax;              //xor r8, rax
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFFD0B8F98]
        r8 -= rax;              //sub r8, rax
        r8 += 0xFFFFFFFFFFFF4954;               //add r8, 0xFFFFFFFFFFFF4954
        r8 += rbx;              //add r8, rbx
        rax = r8;               //mov rax, r8
        rax >>= 0x1;            //shr rax, 0x01
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x2;            //shr rax, 0x02
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x4;            //shr rax, 0x04
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x8;            //shr rax, 0x08
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x10;           //shr rax, 0x10
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x20;           //shr rax, 0x20
        r8 ^= rax;              //xor r8, rax
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFFD0B932B]
        r8 ^= rax;              //xor r8, rax
        rax = rbx;              //mov rax, rbx
        uintptr_t RSP_0xFFFFFFFFFFFFFF90;
        RSP_0xFFFFFFFFFFFFFF90 = Addresses::base + 0x5B0222F4;             //lea rax, [0x00000000580DB73D] : RBP+0xFFFFFFFFFFFFFF90
        rax *= RSP_0xFFFFFFFFFFFFFF90;          //imul rax, [rbp-0x70]
        r8 += rax;              //add r8, rax
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r10;             //xor rax, r10
        rax = ~rax;             //not rax
        r8 *= Memory->Read<uintptr_t>(rax + 0x7);                 //imul r8, [rax+0x07]
        return r8;
    }
    case 12:
    {
        r11 = Memory->Read<uintptr_t>(Addresses::base + 0xB157AC5);          //mov r11, [0x00000000082109F7]
        rdx = Addresses::base + 0x852;             //lea rdx, [0xFFFFFFFFFD0B972E]
        rax = 0xF7D4FABCE6FC022;                //mov rax, 0xF7D4FABCE6FC022
        r8 += rax;              //add r8, rax
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r11;             //xor rax, r11
        rax = ~rax;             //not rax
        r8 *= Memory->Read<uintptr_t>(rax + 0x7);                 //imul r8, [rax+0x07]
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFFD0B8CD4]
        r8 ^= rax;              //xor r8, rax
        r8 -= rax;              //sub r8, rax
        rax = 0x5C9D9DBA026E85B7;               //mov rax, 0x5C9D9DBA026E85B7
        r8 *= rax;              //imul r8, rax
        rax = r8;               //mov rax, r8
        rcx = rbx;              //mov rcx, rbx
        rax >>= 0x21;           //shr rax, 0x21
        rcx = ~rcx;             //not rcx
        rcx *= rdx;             //imul rcx, rdx
        rcx ^= rax;             //xor rcx, rax
        r8 ^= rcx;              //xor r8, rcx
        r8 += rbx;              //add r8, rbx
        return r8;
    }
    case 13:
    {
        r10 = Memory->Read<uintptr_t>(Addresses::base + 0xB157AC5);          //mov r10, [0x0000000008210637]
        r13 = Addresses::base + 0x12585A59;                //lea r13, [0x000000000F63E5B8]
        rax = rbx;              //mov rax, rbx
        rax = ~rax;             //not rax
        rax ^= r13;             //xor rax, r13
        r8 += rax;              //add r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x8;            //shr rax, 0x08
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x10;           //shr rax, 0x10
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x20;           //shr rax, 0x20
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x11;           //shr rax, 0x11
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x22;           //shr rax, 0x22
        r8 ^= rax;              //xor r8, rax
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r10;             //xor rax, r10
        rax = ~rax;             //not rax
        r8 *= Memory->Read<uintptr_t>(rax + 0x7);                 //imul r8, [rax+0x07]
        rax = 0xA4979265BBC7E3D5;               //mov rax, 0xA4979265BBC7E3D5
        r8 *= rax;              //imul r8, rax
        rax = rbx;              //mov rax, rbx
        rax = ~rax;             //not rax
        rax -= Addresses::base;            //sub rax, [rbp-0x08] -- didn't find trace -> use Addresses::base
        rax -= 0x756FAD6E;              //sub rax, 0x756FAD6E
        r8 ^= rax;              //xor r8, rax
        rax = Addresses::base + 0x78217335;                //lea rax, [0x00000000752CFCB7]
        r8 += rbx;              //add r8, rbx
        r8 += rax;              //add r8, rax
        rax = 0xC20F4E2AD24BC517;               //mov rax, 0xC20F4E2AD24BC517
        r8 ^= rax;              //xor r8, rax
        return r8;
    }
    case 14:
    {
        r9 = Memory->Read<uintptr_t>(Addresses::base + 0xB157AC5);           //mov r9, [0x00000000082100CE]
        rax = r8;               //mov rax, r8
        rax >>= 0x16;           //shr rax, 0x16
        r8 ^= rax;              //xor r8, rax
        rax = r8;               //mov rax, r8
        rax >>= 0x2C;           //shr rax, 0x2C
        r8 ^= rax;              //xor r8, rax
        rax = 0xAF96B7C88EDF2B75;               //mov rax, 0xAF96B7C88EDF2B75
        r8 *= rax;              //imul r8, rax
        r8 ^= rbx;              //xor r8, rbx
        r8 += rbx;              //add r8, rbx
        uintptr_t RSP_0xFFFFFFFFFFFFFFB8;
        RSP_0xFFFFFFFFFFFFFFB8 = Addresses::base + 0x3CF1;                 //lea rax, [0xFFFFFFFFFD0BC260] : RBP+0xFFFFFFFFFFFFFFB8
        r8 += RSP_0xFFFFFFFFFFFFFFB8;           //add r8, [rbp-0x48]
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r9;              //xor rax, r9
        rax = ~rax;             //not rax
        r8 *= Memory->Read<uintptr_t>(rax + 0x7);                 //imul r8, [rax+0x07]
        rax = 0x7B695E53D3CD7B7F;               //mov rax, 0x7B695E53D3CD7B7F
        r8 *= rax;              //imul r8, rax
        rax = 0x56A40B352BF2FDB7;               //mov rax, 0x56A40B352BF2FDB7
        r8 -= rax;              //sub r8, rax
        rax = Addresses::base + 0x32FFEB8B;                //lea rax, [0x00000000300B7088]
        rax = ~rax;             //not rax
        rax *= rbx;             //imul rax, rbx
        r8 += rax;              //add r8, rax
        return r8;
    }
    case 15:
    {
        r10 = Memory->Read<uintptr_t>(Addresses::base + 0xB157AC5);          //mov r10, [0x000000000820FB77]
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFFD0B7E79]
        r8 -= rax;              //sub r8, rax
        r8 += rbx;              //add r8, rbx
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r10;             //xor rax, r10
        rax = ~rax;             //not rax
        r8 *= Memory->Read<uintptr_t>(rax + 0x7);                 //imul r8, [rax+0x07]
        rax = r8;               //mov rax, r8
        rax >>= 0x17;           //shr rax, 0x17
        r8 ^= rax;              //xor r8, rax
        rcx = r8;               //mov rcx, r8
        rcx >>= 0x2E;           //shr rcx, 0x2E
        r8 ^= rcx;              //xor r8, rcx
        rax = Addresses::base + 0x23AC2B6F;                //lea rax, [0x0000000020B7A8E2]
        rax = ~rax;             //not rax
        rax ^= rbx;             //xor rax, rbx
        r8 -= rax;              //sub r8, rax
        rax = 0xAE9091426078C4DF;               //mov rax, 0xAE9091426078C4DF
        r8 *= rax;              //imul r8, rax
        rax = 0x2E839B5F3DB76D2B;               //mov rax, 0x2E839B5F3DB76D2B
        r8 += rax;              //add r8, rax
        rax = 0x632E9341FBDD9A7C;               //mov rax, 0x632E9341FBDD9A7C
        r8 -= rax;              //sub r8, rax
        return r8;
    }
    }
}
inline uintptr_t decrypt_bone_base()
{
    const uint64_t mb = Addresses::base;
    uint64_t rax = mb, rbx = mb, rcx = mb, rdx = mb, rdi = mb, rsi = mb, r8 = mb, r9 = mb, r10 = mb, r11 = mb, r12 = mb, r13 = mb, r14 = mb, r15 = mb;
    rdx = Memory->Read<uintptr_t>(Addresses::base + 0x1171EDF8);
    if (!rdx)
        return rdx;
    r8 = Addresses::Peb;               //mov r8, gs:[rax]
    rax = r8;               //mov rax, r8
    rax <<= 0x22;           //shl rax, 0x22
    rax = _byteswap_uint64(rax);            //bswap rax
    rax &= 0xF;
    switch (rax) {
    case 0:
    {
        r10 = Memory->Read<uintptr_t>(Addresses::base + 0xB157B99);          //mov r10, [0x0000000003029E26]
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r10;             //xor rax, r10
        rax = _byteswap_uint64(rax);            //bswap rax
        rdx *= Memory->Read<uintptr_t>(rax + 0x11);               //imul rdx, [rax+0x11]
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFF7ED1FBA]
        rdx -= rax;             //sub rdx, rax
        rax = 0xC98EF2FFB1E013D2;               //mov rax, 0xC98EF2FFB1E013D2
        rdx += 0xFFFFFFFFFFFFC795;              //add rdx, 0xFFFFFFFFFFFFC795
        rdx += r8;              //add rdx, r8
        rdx ^= rax;             //xor rdx, rax
        rdx ^= r8;              //xor rdx, r8
        rax = 0x1AE0F1058D3590F1;               //mov rax, 0x1AE0F1058D3590F1
        rdx *= rax;             //imul rdx, rax
        rax = 0x1EAC0325CBA779BC;               //mov rax, 0x1EAC0325CBA779BC
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x1F;           //shr rax, 0x1F
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x3E;           //shr rax, 0x3E
        rdx ^= rax;             //xor rdx, rax
        rdx ^= r8;              //xor rdx, r8
        return rdx;
    }
    case 1:
    {
        rbx = Memory->Read<uintptr_t>(Addresses::base + 0xB157B99);          //mov rbx, [0x0000000003029958]
        rax = 0x311E3C7DD1297B69;               //mov rax, 0x311E3C7DD1297B69
        rdx *= rax;             //imul rdx, rax
        rcx = r8;               //mov rcx, r8
        rcx = ~rcx;             //not rcx
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= rbx;             //xor rax, rbx
        rax = _byteswap_uint64(rax);            //bswap rax
        rdx *= Memory->Read<uintptr_t>(rax + 0x11);               //imul rdx, [rax+0x11]
        rax = Addresses::base + 0x437D3D7F;                //lea rax, [0x000000003B6A598F]
        rax = ~rax;             //not rax
        rcx += rax;             //add rcx, rax
        rdx ^= rcx;             //xor rdx, rcx
        rax = rdx;              //mov rax, rdx
        rax >>= 0x28;           //shr rax, 0x28
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x13;           //shr rax, 0x13
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x26;           //shr rax, 0x26
        rdx ^= rax;             //xor rdx, rax
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFF7ED1BDA]
        rax += 0x3B261317;              //add rax, 0x3B261317
        rax += r8;              //add rax, r8
        rdx += rax;             //add rdx, rax
        rax = 0x85B82AEE944DCF96;               //mov rax, 0x85B82AEE944DCF96
        rdx ^= rax;             //xor rdx, rax
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFF7ED1CDB]
        rdx += rax;             //add rdx, rax
        return rdx;
    }
    case 2:
    {
        r10 = Memory->Read<uintptr_t>(Addresses::base + 0xB157B99);          //mov r10, [0x00000000030294AE]
        rax = rdx;              //mov rax, rdx
        rax >>= 0x25;           //shr rax, 0x25
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0xC;            //shr rax, 0x0C
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x18;           //shr rax, 0x18
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x30;           //shr rax, 0x30
        rdx ^= rax;             //xor rdx, rax
        rdx += r8;              //add rdx, r8
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r10;             //xor rax, r10
        rax = _byteswap_uint64(rax);            //bswap rax
        rdx *= Memory->Read<uintptr_t>(rax + 0x11);               //imul rdx, [rax+0x11]
        rdx ^= r8;              //xor rdx, r8
        rax = 0x6B65DF2C3A88AE69;               //mov rax, 0x6B65DF2C3A88AE69
        rdx -= rax;             //sub rdx, rax
        rax = 0xA4B331303E4E7A67;               //mov rax, 0xA4B331303E4E7A67
        rdx *= rax;             //imul rdx, rax
        rax = 0x6A137DDDFCE4C0D7;               //mov rax, 0x6A137DDDFCE4C0D7
        rdx -= rax;             //sub rdx, rax
        return rdx;
    }
    case 3:
    {
        r10 = Memory->Read<uintptr_t>(Addresses::base + 0xB157B99);          //mov r10, [0x0000000003029077]
        rbx = Addresses::base + 0x1314A155;                //lea rbx, [0x000000000B01B61B]
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r10;             //xor rax, r10
        rax = _byteswap_uint64(rax);            //bswap rax
        rdx *= Memory->Read<uintptr_t>(rax + 0x11);               //imul rdx, [rax+0x11]
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFF7ED13EA]
        rdx -= rax;             //sub rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x1F;           //shr rax, 0x1F
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x3E;           //shr rax, 0x3E
        rdx ^= rax;             //xor rdx, rax
        rdx ^= r8;              //xor rdx, r8
        rax = rbx;              //mov rax, rbx
        rax -= r8;              //sub rax, r8
        rdx ^= rax;             //xor rdx, rax
        rax = 0xD5A4D08183955257;               //mov rax, 0xD5A4D08183955257
        rdx *= rax;             //imul rdx, rax
        rax = 0x8DC8AE43913090FA;               //mov rax, 0x8DC8AE43913090FA
        rdx ^= rax;             //xor rdx, rax
        return rdx;
    }
    case 4:
    {
        rbx = Memory->Read<uintptr_t>(Addresses::base + 0xB157B99);          //mov rbx, [0x0000000003028D80]
        rax = 0xF7A45523CB2EF07F;               //mov rax, 0xF7A45523CB2EF07F
        rdx ^= rax;             //xor rdx, rax
        rdx -= r8;              //sub rdx, r8
        rdx -= r8;              //sub rdx, r8
        rdx -= r8;              //sub rdx, r8
        rax = rdx;              //mov rax, rdx
        rax >>= 0x14;           //shr rax, 0x14
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x28;           //shr rax, 0x28
        rdx ^= rax;             //xor rdx, rax
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= rbx;             //xor rax, rbx
        rax = _byteswap_uint64(rax);            //bswap rax
        rdx *= Memory->Read<uintptr_t>(rax + 0x11);               //imul rdx, [rax+0x11]
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFF7ED0E47]
        rax += 0x8F29;          //add rax, 0x8F29
        rax += r8;              //add rax, r8
        rdx ^= rax;             //xor rdx, rax
        rax = 0xD43375ADC5407E51;               //mov rax, 0xD43375ADC5407E51
        rdx *= rax;             //imul rdx, rax
        return rdx;
    }
    case 5:
    {
        r10 = Memory->Read<uintptr_t>(Addresses::base + 0xB157B99);          //mov r10, [0x00000000030288F6]
        r15 = Addresses::base + 0x12426297;                //lea r15, [0x000000000A2F6FD5]
        rax = 0x7C5DF0A12057BE6;                //mov rax, 0x7C5DF0A12057BE6
        rdx -= rax;             //sub rdx, rax
        rax = 0x83F8FC0408B5D1AB;               //mov rax, 0x83F8FC0408B5D1AB
        rdx ^= rax;             //xor rdx, rax
        rax = Addresses::base + 0x158DE932;                //lea rax, [0x000000000D7AF4E0]
        rax = ~rax;             //not rax
        rax *= r8;              //imul rax, r8
        rdx += rax;             //add rdx, rax
        rax = r8;               //mov rax, r8
        rax *= r15;             //imul rax, r15
        rdx ^= rax;             //xor rdx, rax
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFF7ED0B01]
        rax += 0x5541;          //add rax, 0x5541
        rax += r8;              //add rax, r8
        rdx += rax;             //add rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x5;            //shr rax, 0x05
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0xA;            //shr rax, 0x0A
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x14;           //shr rax, 0x14
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x28;           //shr rax, 0x28
        rdx ^= rax;             //xor rdx, rax
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r10;             //xor rax, r10
        rax = _byteswap_uint64(rax);            //bswap rax
        rdx *= Memory->Read<uintptr_t>(rax + 0x11);               //imul rdx, [rax+0x11]
        rax = 0x3F31D045C89ED8C5;               //mov rax, 0x3F31D045C89ED8C5
        rdx *= rax;             //imul rdx, rax
        return rdx;
    }
    case 6:
    {
        rbx = Memory->Read<uintptr_t>(Addresses::base + 0xB157B99);          //mov rbx, [0x0000000003028385]
        r15 = Addresses::base + 0x6DA9DAD4;                //lea r15, [0x000000006596E2A8]
        rax = rdx;              //mov rax, rdx
        rax >>= 0x6;            //shr rax, 0x06
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0xC;            //shr rax, 0x0C
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x18;           //shr rax, 0x18
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x30;           //shr rax, 0x30
        rdx ^= rax;             //xor rdx, rax
        rax = 0x7564570D161CA18D;               //mov rax, 0x7564570D161CA18D
        rdx *= rax;             //imul rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x26;           //shr rax, 0x26
        rdx ^= rax;             //xor rdx, rax
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFF7ED0578]
        rax += 0x144205B7;              //add rax, 0x144205B7
        rax += r8;              //add rax, r8
        rdx ^= rax;             //xor rdx, rax
        rax = 0x80C6B6FC948F6729;               //mov rax, 0x80C6B6FC948F6729
        rdx *= rax;             //imul rdx, rax
        rax = 0x31DF20582505A415;               //mov rax, 0x31DF20582505A415
        rdx += rax;             //add rdx, rax
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= rbx;             //xor rax, rbx
        rax = _byteswap_uint64(rax);            //bswap rax
        rdx *= Memory->Read<uintptr_t>(rax + 0x11);               //imul rdx, [rax+0x11]
        rdx += r15;             //add rdx, r15
        rcx = r8;               //mov rcx, r8
        rcx = ~rcx;             //not rcx
        rdx += rcx;             //add rdx, rcx
        return rdx;
    }
    case 7:
    {
        rbx = Memory->Read<uintptr_t>(Addresses::base + 0xB157B99);          //mov rbx, [0x0000000003027FA1]
        r12 = Addresses::base + 0x4354;            //lea r12, [0xFFFFFFFFF7ED4749]
        rdx ^= r8;              //xor rdx, r8
        rax = rdx;              //mov rax, rdx
        rax >>= 0xD;            //shr rax, 0x0D
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x1A;           //shr rax, 0x1A
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x34;           //shr rax, 0x34
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x7;            //shr rax, 0x07
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0xE;            //shr rax, 0x0E
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x1C;           //shr rax, 0x1C
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x38;           //shr rax, 0x38
        rdx ^= rax;             //xor rdx, rax
        rax = 0xCCB3012D7BB7524F;               //mov rax, 0xCCB3012D7BB7524F
        rdx *= rax;             //imul rdx, rax
        rax = 0x11516F5E5F563F90;               //mov rax, 0x11516F5E5F563F90
        rdx -= rax;             //sub rdx, rax
        rax = r8;               //mov rax, r8
        rax = ~rax;             //not rax
        rcx = 0;                //and rcx, 0xFFFFFFFFC0000000
        rcx = _rotl64(rcx, 0x10);               //rol rcx, 0x10
        rax *= r12;             //imul rax, r12
        rcx ^= rbx;             //xor rcx, rbx
        rcx = _byteswap_uint64(rcx);            //bswap rcx
        rdx += rax;             //add rdx, rax
        rdx *= Memory->Read<uintptr_t>(rcx + 0x11);               //imul rdx, [rcx+0x11]
        return rdx;
    }
    case 8:
    {
        rbx = Memory->Read<uintptr_t>(Addresses::base + 0xB157B99);          //mov rbx, [0x0000000003027B12]
        r15 = Addresses::base + 0x7D814959;                //lea r15, [0x00000000756E48BA]
        rdx -= r8;              //sub rdx, r8
        rax = 0xEDC13D6B57B6E285;               //mov rax, 0xEDC13D6B57B6E285
        rdx *= rax;             //imul rdx, rax
        rax = r8;               //mov rax, r8
        rax ^= r15;             //xor rax, r15
        rax += r8;              //add rax, r8
        rdx += rax;             //add rdx, rax
        rcx = 0;                //and rcx, 0xFFFFFFFFC0000000
        rcx = _rotl64(rcx, 0x10);               //rol rcx, 0x10
        rcx ^= rbx;             //xor rcx, rbx
        rcx = _byteswap_uint64(rcx);            //bswap rcx
        rdx *= Memory->Read<uintptr_t>(rcx + 0x11);               //imul rdx, [rcx+0x11]
        rax = rdx;              //mov rax, rdx
        rax >>= 0x21;           //shr rax, 0x21
        rdx ^= rax;             //xor rdx, rax
        rdx += r8;              //add rdx, r8
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFF7ECFE12]
        rdx ^= rax;             //xor rdx, rax
        return rdx;
    }
    case 9:
    {
        r10 = Memory->Read<uintptr_t>(Addresses::base + 0xB157B99);          //mov r10, [0x00000000030277E0]
        rax = rdx;              //mov rax, rdx
        rax >>= 0xB;            //shr rax, 0x0B
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x16;           //shr rax, 0x16
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x2C;           //shr rax, 0x2C
        rdx ^= rax;             //xor rdx, rax
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFF7ECF815]
        rdx ^= rax;             //xor rdx, rax
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r10;             //xor rax, r10
        rax = _byteswap_uint64(rax);            //bswap rax
        rdx *= Memory->Read<uintptr_t>(rax + 0x11);               //imul rdx, [rax+0x11]
        rax = rdx;              //mov rax, rdx
        rax >>= 0xB;            //shr rax, 0x0B
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x16;           //shr rax, 0x16
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x2C;           //shr rax, 0x2C
        rdx ^= rax;             //xor rdx, rax
        rax = 0x53198E81F809E193;               //mov rax, 0x53198E81F809E193
        rax -= r8;              //sub rax, r8
        rax -= Addresses::base;            //sub rax, [rsp+0x60] -- didn't find trace -> use Addresses::base
        rdx += rax;             //add rdx, rax
        rax = 0x5E76F88978AFE528;               //mov rax, 0x5E76F88978AFE528
        rdx += rax;             //add rdx, rax
        rax = 0x33557C5CEFBE234B;               //mov rax, 0x33557C5CEFBE234B
        rdx *= rax;             //imul rdx, rax
        return rdx;
    }
    case 10:
    {
        rbx = Memory->Read<uintptr_t>(Addresses::base + 0xB157B99);          //mov rbx, [0x00000000030272DF]
        r13 = Addresses::base + 0x9688;            //lea r13, [0xFFFFFFFFF7ED8DBB]
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFF7ECF5D8]
        rdx -= rax;             //sub rdx, rax
        rcx = rdx;              //mov rcx, rdx
        rcx >>= 0x27;           //shr rcx, 0x27
        rcx ^= rdx;             //xor rcx, rdx
        rdx = r8;               //mov rdx, r8
        rdx *= r13;             //imul rdx, r13
        rdx += rcx;             //add rdx, rcx
        rax = rdx;              //mov rax, rdx
        rax >>= 0x13;           //shr rax, 0x13
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x26;           //shr rax, 0x26
        rdx ^= rax;             //xor rdx, rax
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= rbx;             //xor rax, rbx
        rax = _byteswap_uint64(rax);            //bswap rax
        rdx *= Memory->Read<uintptr_t>(rax + 0x11);               //imul rdx, [rax+0x11]
        rax = 0x3331EF2FFF7DD801;               //mov rax, 0x3331EF2FFF7DD801
        rdx *= rax;             //imul rdx, rax
        rax = 0x2130706D6228E017;               //mov rax, 0x2130706D6228E017
        rdx ^= rax;             //xor rdx, rax
        return rdx;
    }
    case 11:
    {
        rbx = Memory->Read<uintptr_t>(Addresses::base + 0xB157B99);          //mov rbx, [0x0000000003026E20]
        r13 = Addresses::base + 0x7C2A0085;                //lea r13, [0x000000007416F2F9]
        rcx = 0;                //and rcx, 0xFFFFFFFFC0000000
        rax = Addresses::base + 0x1E13DCA3;                //lea rax, [0x000000001600CB7A]
        rax = ~rax;             //not rax
        rcx = _rotl64(rcx, 0x10);               //rol rcx, 0x10
        rax += r8;              //add rax, r8
        rcx ^= rbx;             //xor rcx, rbx
        rdx += rax;             //add rdx, rax
        rcx = _byteswap_uint64(rcx);            //bswap rcx
        rdx *= Memory->Read<uintptr_t>(rcx + 0x11);               //imul rdx, [rcx+0x11]
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFF7ECEEA9]
        rax += 0x9D9E;          //add rax, 0x9D9E
        rax += r8;              //add rax, r8
        rdx += rax;             //add rdx, rax
        rax = r8;               //mov rax, r8
        rax -= Addresses::base;            //sub rax, [rsp+0x60] -- didn't find trace -> use Addresses::base
        rdx += rax;             //add rdx, rax
        rax = 0x10CE41F37EB30D3D;               //mov rax, 0x10CE41F37EB30D3D
        rdx *= rax;             //imul rdx, rax
        rax = 0x3078E9571E8D51B0;               //mov rax, 0x3078E9571E8D51B0
        rdx -= rax;             //sub rdx, rax
        rax = 0x13796DAAB7614CCB;               //mov rax, 0x13796DAAB7614CCB
        rdx += rax;             //add rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x11;           //shr rax, 0x11
        rdx ^= rax;             //xor rdx, rax
        rcx = r13;              //mov rcx, r13
        rcx = ~rcx;             //not rcx
        rcx *= r8;              //imul rcx, r8
        rax = rdx;              //mov rax, rdx
        rax >>= 0x22;           //shr rax, 0x22
        rcx ^= rax;             //xor rcx, rax
        rdx ^= rcx;             //xor rdx, rcx
        return rdx;
    }
    case 12:
    {
        r10 = Memory->Read<uintptr_t>(Addresses::base + 0xB157B99);          //mov r10, [0x00000000030269E2]
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= r10;             //xor rax, r10
        rax = _byteswap_uint64(rax);            //bswap rax
        rdx *= Memory->Read<uintptr_t>(rax + 0x11);               //imul rdx, [rax+0x11]
        rdx -= r8;              //sub rdx, r8
        rax = 0x509EB372CDB3AEF3;               //mov rax, 0x509EB372CDB3AEF3
        rdx *= rax;             //imul rdx, rax
        rax = 0x3978478545AD0B0E;               //mov rax, 0x3978478545AD0B0E
        rdx += rax;             //add rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x11;           //shr rax, 0x11
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x22;           //shr rax, 0x22
        rdx ^= rax;             //xor rdx, rax
        rax = 0xF1F3C3AA4D6D1089;               //mov rax, 0xF1F3C3AA4D6D1089
        rdx *= rax;             //imul rdx, rax
        return rdx;
    }
    case 13:
    {
        rbx = Memory->Read<uintptr_t>(Addresses::base + 0xB157B99);          //mov rbx, [0x0000000003026566]
        r13 = Addresses::base + 0x7FFA;            //lea r13, [0xFFFFFFFFF7ED69B4]
        rax = rdx;              //mov rax, rdx
        rax >>= 0xE;            //shr rax, 0x0E
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x1C;           //shr rax, 0x1C
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rcx = 0;                //and rcx, 0xFFFFFFFFC0000000
        rax >>= 0x38;           //shr rax, 0x38
        rcx = _rotl64(rcx, 0x10);               //rol rcx, 0x10
        rdx ^= rax;             //xor rdx, rax
        rcx ^= rbx;             //xor rcx, rbx
        rdx += r8;              //add rdx, r8
        rcx = _byteswap_uint64(rcx);            //bswap rcx
        rdx *= Memory->Read<uintptr_t>(rcx + 0x11);               //imul rdx, [rcx+0x11]
        rax = 0xEA5C4AF83EEC98D;                //mov rax, 0xEA5C4AF83EEC98D
        rdx += rax;             //add rdx, rax
        rax = r13;              //mov rax, r13
        rax = ~rax;             //not rax
        rax ^= r8;              //xor rax, r8
        rdx ^= rax;             //xor rdx, rax
        rax = 0x58CCD785809FBA65;               //mov rax, 0x58CCD785809FBA65
        rdx *= rax;             //imul rdx, rax
        rax = 0xCB1252FFDD097729;               //mov rax, 0xCB1252FFDD097729
        rdx *= rax;             //imul rdx, rax
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFF7ECE5A8]
        rax += 0x1CFB;          //add rax, 0x1CFB
        rax += r8;              //add rax, r8
        rdx += rax;             //add rdx, rax
        return rdx;
    }
    case 14:
    {
        rbx = Memory->Read<uintptr_t>(Addresses::base + 0xB157B99);          //mov rbx, [0x0000000003025FDE]
        rax = rdx;              //mov rax, rdx
        rax >>= 0x1C;           //shr rax, 0x1C
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x38;           //shr rax, 0x38
        rax ^= rdx;             //xor rax, rdx
        rdx = Addresses::base;             //lea rdx, [0xFFFFFFFFF7ECE103]
        rax -= rdx;             //sub rax, rdx
        rdx = r8 + 0xffffffffd3bc8867;          //lea rdx, [r8-0x2C437799]
        rdx += rax;             //add rdx, rax
        rax = 0;                //and rax, 0xFFFFFFFFC0000000
        rax = _rotl64(rax, 0x10);               //rol rax, 0x10
        rax ^= rbx;             //xor rax, rbx
        rax = _byteswap_uint64(rax);            //bswap rax
        rdx *= Memory->Read<uintptr_t>(rax + 0x11);               //imul rdx, [rax+0x11]
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFF7ECE015]
        rdx -= rax;             //sub rdx, rax
        rax = 0x311461FA31B150C8;               //mov rax, 0x311461FA31B150C8
        rdx ^= rax;             //xor rdx, rax
        rax = 0x3D057F65AC2E944D;               //mov rax, 0x3D057F65AC2E944D
        rdx += rax;             //add rdx, rax
        rax = 0x3EA61F392134306F;               //mov rax, 0x3EA61F392134306F
        rdx *= rax;             //imul rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x16;           //shr rax, 0x16
        rdx ^= rax;             //xor rdx, rax
        rax = rdx;              //mov rax, rdx
        rax >>= 0x2C;           //shr rax, 0x2C
        rdx ^= rax;             //xor rdx, rax
        return rdx;
    }
    case 15:
    {
        rbx = Memory->Read<uintptr_t>(Addresses::base + 0xB157B99);          //mov rbx, [0x0000000003025B78]
        rax = rdx;              //mov rax, rdx
        rax >>= 0x25;           //shr rax, 0x25
        rdx ^= rax;             //xor rdx, rax
        rdx -= r8;              //sub rdx, r8
        rcx = 0;                //and rcx, 0xFFFFFFFFC0000000
        rcx = _rotl64(rcx, 0x10);               //rol rcx, 0x10
        rcx ^= rbx;             //xor rcx, rbx
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFF7ECDD78]
        rax += 0x953;           //add rax, 0x953
        rax += r8;              //add rax, r8
        rcx = _byteswap_uint64(rcx);            //bswap rcx
        rdx ^= rax;             //xor rdx, rax
        rdx *= Memory->Read<uintptr_t>(rcx + 0x11);               //imul rdx, [rcx+0x11]
        rax = 0xEDC186E4F45D82CF;               //mov rax, 0xEDC186E4F45D82CF
        rdx *= rax;             //imul rdx, rax
        rdx -= r8;              //sub rdx, r8
        rax = Addresses::base;             //lea rax, [0xFFFFFFFFF7ECDC82]
        rdx -= rax;             //sub rdx, rax
        rax = 0x579691DADE4159FD;               //mov rax, 0x579691DADE4159FD
        rdx *= rax;             //imul rdx, rax
        rax = 0x20B206512FA8AEE;                //mov rax, 0x20B206512FA8AEE
        rdx -= rax;             //sub rdx, rax
        rax = 0x804CFF40F9D9BEBF;               //mov rax, 0x804CFF40F9D9BEBF
        rdx *= rax;             //imul rdx, rax
        return rdx;
    }
    }
}
inline uint16_t get_bone_index(uint32_t bone_index)
{
    const uint64_t mb = Addresses::base;
    uint64_t rax = mb, rbx = mb, rcx = mb, rdx = mb, rdi = mb, rsi = mb, r8 = mb, r9 = mb, r10 = mb, r11 = mb, r12 = mb, r13 = mb, r14 = mb, r15 = mb;
    rbx = bone_index;
    rcx = rbx * 0x13C8;
    rax = 0xD8CE01BF28E39A45;               //mov rax, 0xD8CE01BF28E39A45
    rbx = Addresses::base;             //lea rbx, [0xFFFFFFFFFD0B17DE]
    rax = _umul128(rax, rcx, (uintptr_t*)&rdx);             //mul rcx
    r10 = 0xB225E47EA96E19B5;               //mov r10, 0xB225E47EA96E19B5
    rdx >>= 0xD;            //shr rdx, 0x0D
    rax = rdx * 0x25C9;             //imul rax, rdx, 0x25C9
    rcx -= rax;             //sub rcx, rax
    rax = 0xCEA41D97BF6494DF;               //mov rax, 0xCEA41D97BF6494DF
    r8 = rcx * 0x25C9;              //imul r8, rcx, 0x25C9
    rax = _umul128(rax, r8, (uintptr_t*)&rdx);              //mul r8
    rax = r8;               //mov rax, r8
    rax -= rdx;             //sub rax, rdx
    rax >>= 0x1;            //shr rax, 0x01
    rax += rdx;             //add rax, rdx
    rax >>= 0xE;            //shr rax, 0x0E
    rax = rax * 0x46D4;             //imul rax, rax, 0x46D4
    r8 -= rax;              //sub r8, rax
    rax = 0x526226F064679F75;               //mov rax, 0x526226F064679F75
    rax = _umul128(rax, r8, (uintptr_t*)&rdx);              //mul r8
    rax = 0xD79435E50D79435F;               //mov rax, 0xD79435E50D79435F
    rdx >>= 0x9;            //shr rdx, 0x09
    rcx = rdx * 0x637;              //imul rcx, rdx, 0x637
    rax = _umul128(rax, r8, (uintptr_t*)&rdx);              //mul r8
    rdx >>= 0x4;            //shr rdx, 0x04
    rcx += rdx;             //add rcx, rdx
    rax = rcx * 0x26;               //imul rax, rcx, 0x26
    rcx = r8 + r8 * 4;              //lea rcx, [r8+r8*4]
    rcx <<= 0x3;            //shl rcx, 0x03
    rcx -= rax;             //sub rcx, rax
    rax = Memory->Read<uint16_t>(rcx + rbx * 1 + 0xA4B2FD0);          //movzx eax, word ptr [rcx+rbx*1+0xA4B2FD0]
    r8 = rax * 0x13C8;              //imul r8, rax, 0x13C8
    rax = r10;              //mov rax, r10
    rax = _umul128(rax, r8, (uintptr_t*)&rdx);              //mul r8
    rcx = r8;               //mov rcx, r8
    rax = r10;              //mov rax, r10
    rcx -= rdx;             //sub rcx, rdx
    rcx >>= 0x1;            //shr rcx, 0x01
    rcx += rdx;             //add rcx, rdx
    rcx >>= 0xD;            //shr rcx, 0x0D
    rcx = rcx * 0x25BD;             //imul rcx, rcx, 0x25BD
    r8 -= rcx;              //sub r8, rcx
    r9 = r8 * 0x319C;               //imul r9, r8, 0x319C
    rax = _umul128(rax, r9, (uintptr_t*)&rdx);              //mul r9
    rax = r9;               //mov rax, r9
    rax -= rdx;             //sub rax, rdx
    rax >>= 0x1;            //shr rax, 0x01
    rax += rdx;             //add rax, rdx
    rax >>= 0xD;            //shr rax, 0x0D
    rax = rax * 0x25BD;             //imul rax, rax, 0x25BD
    r9 -= rax;              //sub r9, rax
    rax = 0x842108421084211;                //mov rax, 0x842108421084211
    rax = _umul128(rax, r9, (uintptr_t*)&rdx);              //mul r9
    rax = r9;               //mov rax, r9
    rax -= rdx;             //sub rax, rdx
    rax >>= 0x1;            //shr rax, 0x01
    rax += rdx;             //add rax, rdx
    rax >>= 0xA;            //shr rax, 0x0A
    rcx = rax * 0x7C0;              //imul rcx, rax, 0x7C0
    rax = 0xE38E38E38E38E38F;               //mov rax, 0xE38E38E38E38E38F
    rax = _umul128(rax, r9, (uintptr_t*)&rdx);              //mul r9
    rdx >>= 0x3;            //shr rdx, 0x03
    rcx += rdx;             //add rcx, rdx
    rax = rcx + rcx * 8;            //lea rax, [rcx+rcx*8]
    rax += rax;             //add rax, rax
    rcx = r9 + r9 * 4;              //lea rcx, [r9+r9*4]
    rcx <<= 0x2;            //shl rcx, 0x02
    rcx -= rax;             //sub rcx, rax
    rsi = Memory->Read<uint16_t>(rcx + rbx * 1 + 0xA4C1C00);          //movsx esi, word ptr [rcx+rbx*1+0xA4C1C00]
    return rsi;
}