#pragma once
#include <Windows.h>
#include "skStr.h"


namespace Driver
{
    bool DriverCheck();
	bool IsDriverRunning(SC_HANDLE serviceHandle);

	void InitMemoryDriver();
}

bool Driver::DriverCheck()
{
    SC_HANDLE scmHandle = OpenSCManager(nullptr, nullptr, SC_MANAGER_ALL_ACCESS);
    if (!scmHandle) {
        return false;
    }

    LPCWSTR driverServiceName = skCrypt(L"name");

    SC_HANDLE serviceHandle = OpenService(scmHandle, driverServiceName, SERVICE_QUERY_STATUS);
    if (!serviceHandle) {
        CloseServiceHandle(scmHandle);
        return false;
    }

    if (IsDriverRunning(serviceHandle)) {
        return true;
    }
    else {
        return false;
    }

    // Cleanup the service handles
    CloseServiceHandle(serviceHandle);
    CloseServiceHandle(scmHandle);

}

bool Driver::IsDriverRunning(SC_HANDLE serviceHandle)
{
    SERVICE_STATUS_PROCESS ssp = {};
    DWORD bytesNeeded = 0;

    if (!QueryServiceStatusEx(
        serviceHandle,
        SC_STATUS_PROCESS_INFO,
        reinterpret_cast<LPBYTE>(&ssp),
        sizeof(ssp),
        &bytesNeeded))
    {
        std::cerr << "QueryServiceStatusEx failed, error: " << GetLastError() << "\n";
        return false;
    }
    return (ssp.dwCurrentState == SERVICE_RUNNING);
}