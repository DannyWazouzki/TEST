﻿#include "Includes.h"
#include <fstream>

INT main()
{
    LI_FN(SetConsoleTitleA).safe()(_("bo6.External"));

    system("cls");
    DWORD ProcID = GetProcessIdA(L"cod.exe");
    while (!IsProcessRunning(ProcID))
    {
        system("cls");
        std::cout << "[+] Watching Game." << std::endl;
        Sleep(500);
        system("cls");
        std::cout << "[+] Watching Game.." << std::endl;
        Sleep(500);
        system("cls");
        std::cout << "[+] Watching Game..." << std::endl;
        Sleep(500);
        system("cls");
        std::cout << "[+] Watching Game...." << std::endl;
        Sleep(500);

        ProcID = GetProcessIdA(L"cod.exe");
    }

    system("cls");
    std::cout << "[+] Initializing Components" << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(1));
    system("cls");
    std::cout << "[+] Initializing Components Success !" << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(1));

#if !DeveloperMode
    HWND consoleWindow = GetConsoleWindow();
    ShowWindow(consoleWindow, SW_HIDE);
#endif

    SpoofCall->Setup();
    SpoofCall->ResizeConsole(565, 655);

    PrintWithTimestamp(_("Waiting for communications..\n"));

    if (!Memory->Setup())
    {
        Beep(500, 500);
        LI_FN(MessageBoxA).safe()(0, _("driver error please restart device and try again"), _("Error"), MB_OK | MB_ICONERROR);
        exit(1);
    }

    auto pid = Memory->GetPIDForProcess(_(L"cod.exe"));
    if (!pid) {
        Beep(500, 500);
        LI_FN(MessageBoxA).safe()(0, _("driver error please restart device and try again"), _("Process Not Found"), MB_OK | MB_ICONERROR);
        exit(1);
    }

    if (!Memory->AttachToProcess(pid)) {
        Beep(500, 500);
        LI_FN(MessageBoxA).safe()(0, _("driver error please restart device and try again"), _("Failed To Attach To Process"), MB_OK | MB_ICONERROR);
        exit(1);
    }

    Addresses::base = Memory->GetImageBase(nullptr);
    if (!Addresses::base) {
        Beep(500, 500);
        LI_FN(MessageBoxA).safe()(0, _("driver error please restart device and try again"), _("Failed To Get Image"), MB_OK | MB_ICONERROR);
        exit(1);
    }

    Addresses::Peb = Memory->GetProcessPeb();
    if (!Addresses::Peb) {
        Beep(500, 500);
        LI_FN(MessageBoxA).safe()(0, _("driver error please restart device and try again"), _("Failed To Get PEB"), MB_OK | MB_ICONERROR);
        exit(1);
    }

    Memory->SetupCr3();

    PrintWithTimestamp(_("Communicated to client successfully\n\n"));

    PrintWithTimestamp(_("Image Base: "));
    std::cout << Addresses::base << std::endl;
    PrintWithTimestamp(_("Peb: "));
    std::cout << Addresses::Peb << std::endl;
    PrintWithTimestamp(_("Directory: "));
    std::cout << Memory->SetupCr3() << std::endl;

    PrintWithTimestamp(_("Hook verification: success"));

    Hook->Setup();
    Rendering->Setup();

    while (true)
    {
        DWORD pid = GetProcessIdA(L"cod.exe");
        if (!IsProcessRunning(pid)) {
            PrintWithTimestamp(_("Game closed, exiting hack...\n"));
            Sleep(1000);
            ExitProcess(0);
        }
        Sleep(1000);
    }

    return 0;
}
