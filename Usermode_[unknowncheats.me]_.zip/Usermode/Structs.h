﻿#pragma once
#include <vector>
#include <algorithm>
#include <cmath>

#define M_PI 3.14159265358979323846264338327950288419716939937510
#define M_PI_2 1.57079632679489661923f
#define Assert(_exp) ((void)0)

class FVector2D
{
public:
    FVector2D() : X(0.f), Y(0.f) {}
    FVector2D(float _X, float _Y) : X(_X), Y(_Y) {}
    ~FVector2D() {}

    float X;
    float Y;

    operator bool() { return bool(this->X && this->Y); }

    __forceinline FVector2D operator+(const FVector2D& V) const {
        return FVector2D(X + V.X, Y + V.Y);
    }

    __forceinline FVector2D operator+(float A) const {
        return FVector2D(X + A, Y + A);
    }

    __forceinline FVector2D operator-(const FVector2D& v) const {
        return FVector2D(X - v.X, Y - v.Y);
    }

    __forceinline FVector2D& operator-=(const FVector2D& v) {
        X -= v.X;
        Y -= v.Y;
        return *this;
    }

    inline FVector2D flip() const {
        return { Y, X };
    }

    bool IsZeroVector() const {
        return X == 0 && Y == 0;
    }
};

class FVector
{
public:
    FVector() : X(0.f), Y(0.f), Z(0.f) {}
    FVector(float _x, float _y, float _z) : X(_x), Y(_y), Z(_z) {}
    ~FVector() {}

    float X;
    float Y;
    float Z;

    FVector Add(const FVector& other) const {
        return FVector(X + other.X, Y + other.Y, Z + other.Z);
    }

    inline float Dot(const FVector& v) const {
        return X * v.X + Y * v.Y + Z * v.Z;
    }

    inline float Distance(const FVector& v) const {
        return std::sqrt(std::pow(v.X - X, 2.0f) + std::pow(v.Y - Y, 2.0f) + std::pow(v.Z - Z, 2.0f));
    }

    inline double Length() const {
        return std::sqrt(X * X + Y * Y + Z * Z);
    }

    inline bool Empty() const {
        return !X && !Y && !Z;
    }

    inline void Normalize() {
        while (X > 89.0f) X -= 180.f;
        while (X < -89.0f) X += 180.f;
        while (Y > 180.f) Y -= 360.f;
        while (Y < -180.f) Y += 360.f;
    }

    inline FVector GetNormalized() const {
        float length = sqrtf(X * X + Y * Y + Z * Z);
        if (length == 0.0f)
            return { 0, 0, 0 };
        return { X / length, Y / length, Z / length };
    }

    bool IsValid() const {
        return !(std::isnan(X) || std::isinf(X) || std::isnan(Y) || std::isinf(Y) || std::isnan(Z) || std::isinf(Z));
    }

    inline float DistTo(const FVector& ape) const {
        return (*this - ape).Length();
    }

    inline FVector operator+(const FVector& v) const {
        return FVector(X + v.X, Y + v.Y, Z + v.Z);
    }

    inline FVector& operator+=(const FVector& other) {
        X += other.X;
        Y += other.Y;
        Z += other.Z;
        return *this;
    }

    inline FVector operator-(const FVector& v) const {
        return FVector(X - v.X, Y - v.Y, Z - v.Z);
    }

    inline FVector operator/(float ape) const {
        return { X / ape, Y / ape, Z / ape };
    }

    inline FVector& operator-=(const FVector& v) {
        X -= v.X;
        Y -= v.Y;
        Z -= v.Z;
        return *this;
    }

    inline void Clamp() {
        if (Y > 180.0f) Y = 180.0f;
        else if (Y < -180.0f) Y = -180.0f;

        if (X > 89.0f) X = 89.0f;
        else if (X < -89.0f) X = -89.0f;

        Z = 0;
    }

    inline FVector CalcAngle(const FVector& src, const FVector& dst) const {
        FVector delta = src - dst;
        double hyp = std::sqrt(delta.X * delta.X + delta.Y * delta.Y);
        FVector angle;
        angle.X = static_cast<float>(std::atan(delta.Z / hyp) * 57.295779513082f);
        angle.Y = static_cast<float>(std::atan(delta.Y / delta.X) * 57.295779513082f);
        if (delta.X >= 0.0) angle.Y += 180.0f;
        return angle;
    }

    inline FVector operator*(float flNum) const {
        return FVector(X * flNum, Y * flNum, Z * flNum);
    }

    inline double Size() const {
        return Length();
    }
};

struct Matrix4x4 {
    float M[4][4];
};

inline FVector TransformVector(const FVector& Vec, const Matrix4x4& Matrix) {
    FVector result;
    result.X = Vec.X * Matrix.M[0][0] + Vec.Y * Matrix.M[1][0] + Vec.Z * Matrix.M[2][0] + Matrix.M[3][0];
    result.Y = Vec.X * Matrix.M[0][1] + Vec.Y * Matrix.M[1][1] + Vec.Z * Matrix.M[2][1] + Matrix.M[3][1];
    result.Z = Vec.X * Matrix.M[0][2] + Vec.Y * Matrix.M[1][2] + Vec.Z * Matrix.M[2][2] + Matrix.M[3][2];
    return result;
}

inline float GetGtcDistance(const FVector2D& v1, const FVector2D& v2) {
    float dx = v2.X - v1.X;
    float dy = v2.Y - v1.Y;
    return std::sqrt(dx * dx + dy * dy);
}
